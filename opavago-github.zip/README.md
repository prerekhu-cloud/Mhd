# OpavaGO

Mapa a jízdní řády MHD Opava, regionálních linek a vlaků (2D/3D, vyhledávání spojení, odjezdy, Bedekr, Garáž).

## Co je ve složce

| Soubor / složka | Obsah |
|---|---|
| `index.html` | krátká kostra aplikace (~64 kB) – načítá všechno ostatní |
| `config.js` | **nastavení** (adresa proxy pro živé polohy) – jediný soubor, který upravujete |
| `data/` | data: zastávky, linky, jízdní řády a vyhledávání (`mhd-data.js`), trasy GPX, regionální linky |
| `js/` | kód aplikace (pořadí je dané v `index.html`) |
| `css/` | vzhled |
| `img/` | obrázky (logo, vozidla, ikony) |
| `worker/` | proxy pro živé polohy a zpoždění (Cloudflare Worker) |

Žádný soubor nemá víc než 15 MB (největší ~1 MB).

## 1. Zveřejnění na GitHub Pages

1. Na GitHubu vytvořte repozitář (např. `opavago`) a nahrajte do něj **celý obsah této složky** (Add file → Upload files – přetáhněte všechny soubory i složky).
2. Settings → Pages → *Build and deployment* → Source: **Deploy from a branch**, Branch: `main`, složka `/ (root)` → Save.
3. Za minutu je aplikace na `https://<vaše-jméno>.github.io/opavago/`.

Aplikace jde otevřít i z disku (dvojklik na `index.html`), pokud jsou složky `data/`, `js/`, `css/`, `img/` vedle něj.

## 2. Živé polohy a zpoždění (volitelné)

Polohy vozidel se mění každých pár sekund, proto nemohou být uložené jako soubor v GitHubu.
Aplikace je čte z veřejné mapy ODIS; prohlížeč ji ale přímo číst nesmí (CORS), proto je ve složce `worker/` malá proxy,
kterou zdarma provozuje Cloudflare a nasazuje ji **přímo z vašeho GitHub repozitáře**:

1. Účet na <https://dash.cloudflare.com> (zdarma) → **Workers & Pages** → **Create** → **Import a repository** → vyberte repozitář `opavago`.
2. *Root directory*: `worker` (zbytek nechte, `wrangler.toml` už je připravený) → **Deploy**.
3. Dostanete adresu typu `https://opavago-odis.<účet>.workers.dev/` – otevřete ji, měl by se ukázat JSON s `transmitters`.
4. Adresu vložte do `config.js`:
   ```js
   window.OPAVAGO_CONFIG = { liveUrl: 'https://opavago-odis.<účet>.workers.dev/' };
   ```
   a soubor nahrajte na GitHub. Živé polohy se pak zapnou samy (vypnout jde tlačítkem s anténou dole vlevo).

Volitelně v `worker/wrangler.toml` nastavte `ALLOWED_ORIGIN = "https://<vaše-jméno>.github.io"`, aby proxy sloužila jen vaší stránce.
Proxy drží odpověď 10 s v mezipaměti – ODIS tak dostane nejvýš ~6 dotazů za minutu bez ohledu na počet uživatelů.

## Aktualizace

Novou verzi nahrajte stejně – přepište soubory v repozitáři. Pokud se po nahrání ukazuje stará verze, obnovte stránku (Ctrl+F5).
