/**
 * OpavaGO – proxy pro živé polohy a zpoždění vozidel ODIS (Cloudflare Worker).
 *
 * Prohlížeč nesmí veřejnou mapu ODIS (mpvnet.cz/odis/map) číst přímo (chybí CORS),
 * proto ji čte tento malý server a aplikaci vrací jen to, co potřebuje:
 *   { updated: <čas v ms>, transmitters: [ {cn, x, y, ico, ds, cr, cat, t}, … ] }
 * - jen autobusy a trolejbusy (bez vlaků) v okolí Opavy,
 * - odpověď se 10 s drží v mezipaměti, takže ODIS dostane nejvýš ~6 dotazů za minutu,
 *   ať aplikaci používá kolik lidí chce.
 */
const ODIS_URL = 'https://mpvnet.cz/odis/map/mapData';
/* Opavsko: od Vítkova po Hlučín a Kravaře */
const AREA = { w: 17.55, s: 49.72, e: 18.35, n: 50.12 };
const CACHE_SECONDS = 10;

export default {
  async fetch(request, env, ctx) {
    const cors = {
      'Access-Control-Allow-Origin': env.ALLOWED_ORIGIN || '*',
      'Access-Control-Allow-Methods': 'GET, OPTIONS',
      'Vary': 'Origin',
    };
    if (request.method === 'OPTIONS') return new Response(null, { headers: cors });
    if (request.method !== 'GET') return new Response('Jen GET', { status: 405, headers: cors });

    const cache = caches.default;
    const key = new Request('https://opavago.cache/odis');
    const hit = await cache.match(key);
    if (hit) return withHeaders(hit, cors);

    let data;
    try {
      const up = await fetch(ODIS_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json; charset=utf-8',
          'Origin': 'https://mpvnet.cz',
          'Referer': 'https://mpvnet.cz/odis/map',
          'User-Agent': 'OpavaGO (jizdni rady MHD Opava)',
        },
        body: JSON.stringify({ ...AREA, zoom: 13, showStops: false, mapFilterId: null }),
        signal: AbortSignal.timeout(8000),
      });
      if (!up.ok) return json({ error: 'ODIS odpověděl ' + up.status }, 502, cors);
      data = await up.json();
    } catch (e) {
      return json({ error: 'ODIS nedostupný: ' + (e && e.message || e) }, 504, cors);
    }

    const transmitters = (data.transmitters || [])
      .filter((t) => t && t.cat !== 1 && (!t.t || t.t === 'H') && Number.isFinite(t.x) && Number.isFinite(t.y))
      .map(({ cn, x, y, ico, ds, cr, cat, t }) => ({ cn: String(cn || '').split('|').slice(0, 12).join('|'), x, y, ico, ds, cr, cat, t }));

    const res = json({ updated: Date.now(), transmitters }, 200, { ...cors, 'Cache-Control': 'public, max-age=' + CACHE_SECONDS });
    ctx.waitUntil(cache.put(key, res.clone()));
    return res;
  },
};

function json(body, status, headers) {
  return new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json; charset=utf-8', ...headers } });
}
function withHeaders(res, headers) {
  const r = new Response(res.body, res);
  for (const [k, v] of Object.entries(headers)) r.headers.set(k, v);
  return r;
}
