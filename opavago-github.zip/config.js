/* OpavaGO – nastavení. Upravte jen tento soubor. */
window.OPAVAGO_CONFIG = {
  /* Adresa proxy pro živé polohy a zpoždění (Cloudflare Worker ze složky worker/).
     Příklad: 'https://opavago-odis.vase-jmeno.workers.dev/'  – prázdné = zkusit přímo mapu ODIS. */
  liveUrl: ''
};
