
(function(){

        // Databáze památek
        const placesData = [
            {
                id: 'hlaska',
                title: 'Hláska (Městská věž)',
                shortDesc: 'Symbol města Opavy tyčící se na Horním náměstí, v budově dnes sídlí magistrát.',
                location: 'Horní náměstí, Opava',
                access: 'Interiéry podle otevírací doby, exteriér celoročně',
                type: 'Architektura / Radnice',
                trivia: 'Věž je vysoká 60 metrů a na jejím vrcholu se nachází měděná makovice, která skrývá pamětní listiny a dobové mince pro budoucí generace.',
                description: `
                    <p>Hláska je bezesporu nejznámějším symbolem a dominantou statutárního města Opavy. Nachází se v samém srdci města na Horním náměstí. Původně na jejím místě stávala dřevěná obchodní křižovatka, kde se křížily důležité obchodní cesty.</p>
                    <p class="mt-4">Dnešní podobu získala budova po mnoha přestavbách, přičemž výrazným prvkem je renesanční věž z počátku 17. století. Samotná budova (radnice) je postavena ve stylu novorenesance.</p>
                    <p class="mt-4">V přízemí dnes naleznete turistické informační centrum a oblíbené kavárny. Během roku se zde pořádají městské slavnosti a vánoční trhy, které dávají náměstí nezapomenutelnou atmosféru.</p>
                `,
                thumbnail: 'https://commons.wikimedia.org/wiki/Special:FilePath/Town_hall_in_Opava_%281%29.jpg?width=500',
                heroImg: 'https://commons.wikimedia.org/wiki/Special:FilePath/Town_hall_in_Opava_%281%29.jpg?width=1400',
                gallery: [
                    'https://commons.wikimedia.org/wiki/Special:FilePath/Town_hall_in_Opava_%2810%29.jpg?width=900',
                    'https://commons.wikimedia.org/wiki/Special:FilePath/Radnice_Hl%C3%A1ska_na_Horn%C3%ADm_n%C3%A1m%C4%9Bst%C3%AD.jpg?width=900',
                    'https://commons.wikimedia.org/wiki/Special:FilePath/Troppau-Rathaus-1.jpg?width=900'
                ]
            },
            {
                id: 'hradec',
                title: 'Zámek Hradec nad Moravicí',
                shortDesc: 'Pohádkový komplex Červeného a Bílého zámku, kde pobýval mj. L. van Beethoven.',
                location: 'Hradec nad Moravicí',
                access: 'Duben - Říjen (park celoročně)',
                type: 'Zámek / Historie',
                trivia: 'Při svém pobytu na zámku se zde Ludwig van Beethoven rozzlobil na knížete Lichnovského a prý mu řekl slavnou větu: "Knížat bylo a bude tisíce, Beethoven je jen jeden!"',
                description: `
                    <p>Státní zámek Hradec nad Moravicí patří k nejatraktivnějším památkám nejen Opavska, ale celé České republiky. Komplex se skládá z elegantního empírového Bílého zámku a novogotického Červeného zámku s přilehlou Bílou věží.</p>
                    <p class="mt-4">Zámek je obklopen rozlehlým anglickým parkem, který přechází do volné přírody a je ideálním místem pro dlouhé procházky s vyhlídkami do údolí řeky Moravice.</p>
                    <p class="mt-4">V minulosti byl zámek významným kulturním centrem. Mimo Beethovena zámek navštívil například i slavný houslista Niccolò Paganini nebo skladatel Franz Liszt.</p>
                `,
                thumbnail: 'https://commons.wikimedia.org/wiki/Special:FilePath/Z%C3%A1mek_Hradec_nad_Moravic%C3%AD%3B_%C4%8Cerven%C3%BD_z%C3%A1mek.JPG?width=500',
                heroImg: 'https://commons.wikimedia.org/wiki/Special:FilePath/Z%C3%A1mek_Hradec_nad_Moravic%C3%AD%3B_%C4%8Cerven%C3%BD_z%C3%A1mek.JPG?width=1400',
                gallery: [
                    'https://commons.wikimedia.org/wiki/Special:FilePath/Hradec_nad_Moravici_Zamek_-_vezicka.JPG?width=900',
                    'https://commons.wikimedia.org/wiki/Special:FilePath/Hradec_nad_Moravici_Zamek_-_nadvori_a_vez.JPG?width=900',
                    'https://commons.wikimedia.org/wiki/Special:FilePath/Z%C3%A1mek_a_okol%C3%AD_Hradce_nad_Moravic%C3%AD_z_pta%C4%8D%C3%AD_perspektivy.jpg?width=900'
                ]
            },
            {
                id: 'muzeum',
                title: 'Slezské zemské muzeum',
                shortDesc: 'Nejstarší veřejné muzeum v ČR. Nádherná historická výstavní budova plná exponátů.',
                location: 'Sady U Muzea, Opava',
                access: 'Úterý - Neděle',
                type: 'Muzeum / Kultura',
                trivia: 'Bylo založeno již v roce 1814. Během 2. světové války byla historická budova těžce poškozena při bombardování, naštěstí většina sbírek byla ukryta.',
                description: `
                    <p>Slezské zemské muzeum v Opavě si drží primát jako nejstarší muzeum na území České republiky. Hlavní atrakcí pro návštěvníky je Historická výstavní budova, která je zmenšenou kopií vídeňského muzea umění.</p>
                    <p class="mt-4">V nádherných a bohatě zdobených prostorech naleznete rozsáhlou expozici nazvanou "Příroda a historie Slezska". K vidění jsou stovky preparovaných zvířat, historické zbraně, platidla, kroje a umělecká díla spjatá s tímto regionem.</p>
                    <p class="mt-4">K muzeu dnes patří několik dalších areálů, včetně Památníku II. světové války v Hrabyni nebo Arboreta Nový Dvůr.</p>
                `,
                thumbnail: 'https://commons.wikimedia.org/wiki/Special:FilePath/Opava%2C_Slezsk%C3%A9_zemsk%C3%A9_muzeum_%281%29.jpg?width=500',
                heroImg: 'https://commons.wikimedia.org/wiki/Special:FilePath/Opava%2C_Slezsk%C3%A9_zemsk%C3%A9_muzeum_%281%29.jpg?width=1400',
                gallery: [
                    'https://commons.wikimedia.org/wiki/Special:FilePath/Opava%2C_Slezsk%C3%A9_zemsk%C3%A9_muzeum_%28pohled_od_v%C3%BDchodu%29.jpg?width=900',
                    'https://commons.wikimedia.org/wiki/Special:FilePath/Opava%2C_Silesian_Museum_1.jpg?width=900',
                    'https://commons.wikimedia.org/wiki/Special:FilePath/Opawa.Muzeum_%C5%9Al%C4%85skie.JPG?width=900'
                ]
            },
            {
                id: 'konkatedrala',
                title: 'Konkatedrála Nanebevzetí P. Marie',
                shortDesc: 'Majestátní gotická perla z červených cihel, jejíž věž ční nad celou Opavou.',
                location: 'Rybí trh, Opava',
                access: 'Při bohoslužbách, v určené časy prohlídek',
                type: 'Církevní památka',
                trivia: 'Zajímavostí je, že její stavba z pálených cihel (tzv. režného zdiva) je v našich končinách méně obvyklá a ukazuje na vliv slezské a severoněmecké cihelné gotiky.',
                description: `
                    <p>Tento monumentální trojlodní chrám s mohutnou jižní věží (vysokou 102 metrů, čímž patří k nejvyšším věžím v ČR) je nejvýznamnější církevní stavbou v Opavě.</p>
                    <p class="mt-4">Stavba z charakteristického režného cihlového zdiva pochází převážně ze 14. století. Konkatedrálou se chrám stal v roce 1996 při vzniku ostravsko-opavské diecéze – papež Jan Pavel II. ji povýšil na druhý biskupský kostel.</p>
                    <p class="mt-4">Interiér nabízí krásné barokní oltáře a nezaměnitelnou majestátní atmosféru typickou pro vrcholnou gotiku.</p>
                `,
                thumbnail: 'https://commons.wikimedia.org/wiki/Special:FilePath/Opava%2C_konkatedr%C3%A1la_Nanebevzet%C3%AD_Panny_Marie.JPG?width=500',
                heroImg: 'https://commons.wikimedia.org/wiki/Special:FilePath/Opava%2C_konkatedr%C3%A1la_Nanebevzet%C3%AD_Panny_Marie.JPG?width=1400',
                gallery: [
                    'https://commons.wikimedia.org/wiki/Special:FilePath/Opava%2C_Konkatedr%C3%A1la_nanebevzet%C3%AD_Panny_Marie%2C_bo%C4%8Dn%C3%AD_strana.jpg?width=900',
                    'https://commons.wikimedia.org/wiki/Special:FilePath/Opava%2C_Konkatedr%C3%A1la_nanebevzet%C3%AD_Panny_Marie%2C_v_noci.jpg?width=900',
                    'https://commons.wikimedia.org/wiki/Special:FilePath/Opava%2C_konkatedr%C3%A1la%2C_hlavn%C3%AD_vstup..JPG?width=900'
                ]
            },
            {
                id: 'radun',
                title: 'Zámek Raduň',
                shortDesc: 'Romantický klasicistní a empírový zámek odrážející se na hladině rybníka.',
                location: 'Raduň u Opavy',
                access: 'Duben - Říjen',
                type: 'Zámek / Historie',
                trivia: 'Původně stála na místě středověká tvrz. Během 20. století tu dokonce sídlila škola a školka, než byl zámek v 80. letech nákladně zrekonstruován.',
                description: `
                    <p>Jen několik kilometrů od Opavy se nachází tento kouzelný zámek. Výrazná empírová stavba zářící do okolí světlou barvou tvoří s přilehlým rybníkem a lesoparkem jedinečnou romantickou scenérii.</p>
                    <p class="mt-4">Návštěvníci si mohou prohlédnout autenticky zařízené reprezentační i soukromé pokoje šlechtické rodiny Blücherů z Wahlstattu, bohatou knihovnu a sbírku historického nábytku.</p>
                    <p class="mt-4">K zámku neodmyslitelně patří také zrekonstruovaná zámecká oranžérie s bylinkovou zahrádkou, do které je vstup možný přes zámecký park.</p>
                `,
                thumbnail: 'https://commons.wikimedia.org/wiki/Special:FilePath/Radu%C5%88_-_Castle_01.JPG?width=500',
                heroImg: 'https://commons.wikimedia.org/wiki/Special:FilePath/Radu%C5%88_-_Castle_01.JPG?width=1400',
                gallery: [
                    'https://commons.wikimedia.org/wiki/Special:FilePath/Kostel_Nejsv%C4%9Bt%C4%9Bj%C5%A1%C3%AD_Trojice%2C_Radu%C5%88_%2812%29.JPG?width=900',
                    'https://commons.wikimedia.org/wiki/Special:FilePath/Kostel_Nejsv%C4%9Bt%C4%9Bj%C5%A1%C3%AD_Trojice%2C_Radu%C5%88_%2810%29.JPG?width=900',
                    'https://commons.wikimedia.org/wiki/Special:FilePath/Radu%C5%88_-_Castle_01.JPG?width=900'
                ]
            },
            {
                id: 'hrabyne',
                title: 'Památník II. světové války v Hrabyni',
                shortDesc: 'Monumentální architektonický objekt věnovaný těžkým bojům ostravsko-opavské operace.',
                location: 'Hrabyně',
                access: 'Březen - Listopad',
                type: 'Památník / Muzeum',
                trivia: 'Památník tvoří dvě obrovské klínové stavby, které se tyčí do nebe. Mají symbolizovat rozevřená hlaveň děla nebo rozlámanou svastiku.',
                description: `
                    <p>Na vrcholu kopce u obce Hrabyně dominuje do daleka viditelný monument, připomínající hrůzy druhé světové války a konkrétně mimořádně krvavé boje tzv. Ostravsko-opavské operace na jaře 1945.</p>
                    <p class="mt-4">Uvnitř památníku se nachází poutavá moderní expozice „Doba zmaru a naděje“. Ukazuje nejen výzbroj a taktiku obou bojujících stran, ale soustředí se i na těžké osudy civilního obyvatelstva ve válečné době.</p>
                    <p class="mt-4">V okolí památníku je rozsáhlý venkovní areál se symbolickým hřbitovem a expozicí historické vojenské techniky.</p>
                `,
                thumbnail: 'https://commons.wikimedia.org/wiki/Special:FilePath/N%C3%A1rodn%C3%AD_pam%C3%A1tn%C3%ADk_II._sv%C4%9Btov%C3%A9_v%C3%A1lky_%28001%29.jpg?width=500',
                heroImg: 'https://commons.wikimedia.org/wiki/Special:FilePath/N%C3%A1rodn%C3%AD_pam%C3%A1tn%C3%ADk_II._sv%C4%9Btov%C3%A9_v%C3%A1lky_%28001%29.jpg?width=1400',
                gallery: [
                    'https://commons.wikimedia.org/wiki/Special:FilePath/N%C3%A1rodn%C3%AD_pam%C3%A1tn%C3%ADk_II._sv%C4%9Btov%C3%A9_v%C3%A1lky_%28002%29.jpg?width=900',
                    'https://commons.wikimedia.org/wiki/Special:FilePath/N%C3%A1rodn%C3%AD_pam%C3%A1tn%C3%ADk_II._sv%C4%9Btov%C3%A9_v%C3%A1lky_%28001%29.jpg?width=900',
                    'https://commons.wikimedia.org/wiki/Special:FilePath/N%C3%A1rodn%C3%AD_pam%C3%A1tn%C3%ADk_II._sv%C4%9Btov%C3%A9_v%C3%A1lky_%28002%29.jpg?width=900'
                ]
            },
            {
                id: 'arboretum',
                title: 'Arboretum Nový Dvůr',
                shortDesc: 'Botanická zahrada s bohatou sbírkou dřevin z celého světa, rozkládající se kolem menšího zámku.',
                location: 'Stěbořice - Nový Dvůr',
                access: 'Celoročně (dle otevírací doby)',
                type: 'Příroda / Park',
                trivia: 'Součástí arboreta je obrovský skleník s tropickými a subtropickými rostlinami a úžasná expozice motýlů.',
                description: `
                    <p>Arboretum Nový Dvůr patří mezi dendrologicky nejcennější parky ve Slezsku. Nachází se v obci Stěbořice, jen pár kilometrů od Opavy. Bylo založeno v 50. letech 20. století na základech staršího zámeckého parku.</p>
                    <p class="mt-4">Na ploše 23 hektarů zde roste více než 7000 druhů rostlin, dřevin a bylin ze všech koutů světa. K nejoblíbenějším částem patří rozsáhlý skleník s exotickou flórou a expozice živých motýlů.</p>
                    <p class="mt-4">Celoročně zde kvetou různé druhy rostlin, takže každá návštěva nabízí jiný a vždy úchvatný barevný zážitek. Dominantou areálu je malý novorenesanční zámeček.</p>
                `,
                thumbnail: 'https://commons.wikimedia.org/wiki/Special:FilePath/Arboretum_Nov%C3%BD_Dv%C5%AFr_-_z%C3%A1me%C4%8Dek.jpg?width=500',
                heroImg: 'https://commons.wikimedia.org/wiki/Special:FilePath/Arboretum_Nov%C3%BD_Dv%C5%AFr_-_are%C3%A1l.jpg?width=1400',
                gallery: [
                    'https://commons.wikimedia.org/wiki/Special:FilePath/Arboretum_Nov%C3%BD_Dv%C5%AFr_-_are%C3%A1l_2.jpg?width=900',
                    'https://commons.wikimedia.org/wiki/Special:FilePath/Arboretum_Nov%C3%BD_Dv%C5%AFr_-_sklen%C3%ADkov%C3%A1_expozice.jpg?width=900',
                    'https://commons.wikimedia.org/wiki/Special:FilePath/Nov%C3%BD_Dv%C5%AFr_%28St%C4%9Bbo%C5%99ice%29%2C_arboretum%2C_sklen%C3%ADk%2C_wolemie_vzne%C5%A1en%C3%A1.jpg?width=900'
                ]
            },
            {
                id: 'divadlo',
                title: 'Slezské divadlo Opava',
                shortDesc: 'Významná kulturní instituce s nádhernou historickou budovou v centru Opavy.',
                location: 'Horní náměstí, Opava',
                access: 'Během představení a na vyžádání',
                type: 'Kultura / Architektura',
                trivia: 'Fasáda budovy byla za socialismu zcela "očištěna" od historických prvků do hladka. Při rekonstrukci počátkem 90. let jí byla naštěstí navrácena její původní neorenesanční podoba.',
                description: `
                    <p>Slezské divadlo Opava, sídlící na Horním náměstí vedle Hlásky, je kulturním srdcem města. Jeho budova je jednou z nejvýraznějších architektonických dominant centra.</p>
                    <p class="mt-4">Divadlo uvádí široký repertoár, od činohry až po operu a balet. Historie divadelnictví v Opavě sahá hluboko do minulosti a samotná budova zažila mnohé přestavby.</p>
                    <p class="mt-4">Dnešní podoba interiéru i exteriéru je výsledkem citlivé rekonstrukce, která budově vrátila její prvorepublikový lesk a noblesu.</p>
                `,
                thumbnail: 'https://commons.wikimedia.org/wiki/Special:FilePath/Opava_-_Slezsk%C3%A9_Divadlo_01.jpg?width=500',
                heroImg: 'https://commons.wikimedia.org/wiki/Special:FilePath/Opava_-_Slezsk%C3%A9_Divadlo_01.jpg?width=1400',
                gallery: [
                    'https://commons.wikimedia.org/wiki/Special:FilePath/Slezsk%C3%A9_divadlo_a_radnice_Hl%C3%A1ska%2C_Opava_-_panoramio.jpg?width=900',
                    'https://commons.wikimedia.org/wiki/Special:FilePath/Centrum_m%C4%9Bsta_u_divadla.jpg?width=900',
                    'https://commons.wikimedia.org/wiki/Special:FilePath/Opava_-_Slezsk%C3%A9_Divadlo_01.jpg?width=900'
                ]
            },
            {
                id: 'kravare',
                title: 'Zámek Kravaře',
                shortDesc: 'Krásný barokní zámek spjatý s rodem Eichendorffů, obklopený rozlehlým anglickým parkem.',
                location: 'Zámecká, Kravaře',
                access: 'Celoročně (dle otevírací doby)',
                type: 'Zámek / Historie',
                trivia: 'Zámek po zničujícím požáru ve 20. století prošel rozsáhlou a velmi nákladnou rekonstrukcí, aby se vrátil do své dřívější krásy.',
                description: `
                    <p>Barokní perla Hlučínska – zámek Kravaře – je jedním z nejkrásnějších šlechtických sídel v regionu. Dlouho zde sídlil významný rod Eichendorffů.</p>
                    <p class="mt-4">V interiérech zámku mohou návštěvníci obdivovat bohatou štukovou výzdobu a seznámit se se životem na zámku i s osudy slezských šlechtických rodů.</p>
                    <p class="mt-4">Zámek obklopuje rozlehlý anglický park o rozloze více než 20 hektarů, kterým protéká řeka Opava. Park je částečně využíván jako profesionální 18jamkové golfové hřiště.</p>
                `,
                thumbnail: 'https://commons.wikimedia.org/wiki/Special:FilePath/Z%C3%A1mek_Krava%C5%99e.JPG?width=500',
                heroImg: 'https://commons.wikimedia.org/wiki/Special:FilePath/Z%C3%A1mek_s_parkem_Krava%C5%99e.JPG?width=1400',
                gallery: [
                    'https://commons.wikimedia.org/wiki/Special:FilePath/Z%C3%A1mek_Krava%C5%99e.JPG?width=900',
                    'https://commons.wikimedia.org/wiki/Special:FilePath/Schloss_Deutsch_Krawarn.jpg?width=900',
                    'https://commons.wikimedia.org/wiki/Special:FilePath/Z%C3%A1mek_s_parkem_Krava%C5%99e.JPG?width=900'
                ]
            },
            {
                id: 'darkovicky',
                title: 'Areál opevnění Darkovičky',
                shortDesc: 'Unikátní komplex československého těžkého opevnění z 30. let 20. století.',
                location: 'Hlučín - Darkovičky',
                access: 'Duben - Říjen',
                type: 'Vojenská památka',
                trivia: 'Pěchotní srub MO-S 59 "Orlice" patří k nejlépe zrekonstruovaným objektům v ČR a obsahuje plně funkční vnitřní vybavení včetně zbraní.',
                description: `
                    <p>Areál československého opevnění v Hlučíně-Darkovičkách je evropským unikátem. Jedná se o komplex betonových bunkrů budovaných ve 30. letech 20. století jako obrana proti nacistickému Německu.</p>
                    <p class="mt-4">Areál tvoří pět různých pevnostních objektů. Hlavním lákadlem je špičkově zrekonstruovaný pěchotní srub "Orlice", kde si návštěvníci mohou prohlédnout originální výzbroj, generátory i ubytovací prostory posádky.</p>
                    <p class="mt-4">Pravidelně se zde konají velké ukázky vojenské historie s použitím historické techniky a uniforem.</p>
                `,
                thumbnail: 'https://commons.wikimedia.org/wiki/Special:FilePath/Are%C3%A1l_%C4%8Deskoslovensk%C3%A9ho_opevn%C4%9Bn%C3%AD_-_Hlu%C4%8D%C3%ADn-Darkovi%C4%8Dky_01.jpg?width=500',
                heroImg: 'https://commons.wikimedia.org/wiki/Special:FilePath/Are%C3%A1l_%C4%8Deskoslovensk%C3%A9ho_opevn%C4%9Bn%C3%AD_-_Hlu%C4%8D%C3%ADn-Darkovi%C4%8Dky_02.jpg?width=1400',
                gallery: [
                    'https://commons.wikimedia.org/wiki/Special:FilePath/Are%C3%A1l_%C4%8Deskoslovensk%C3%A9ho_opevn%C4%9Bn%C3%AD_-_Hlu%C4%8D%C3%ADn-Darkovi%C4%8Dky_03.jpg?width=900',
                    'https://commons.wikimedia.org/wiki/Special:FilePath/Are%C3%A1l_%C4%8Deskoslovensk%C3%A9ho_opevn%C4%9Bn%C3%AD_-_Hlu%C4%8D%C3%ADn-Darkovi%C4%8Dky_04.jpg?width=900',
                    'https://commons.wikimedia.org/wiki/Special:FilePath/Are%C3%A1l_%C4%8Deskoslovensk%C3%A9ho_opevn%C4%9Bn%C3%AD_-_Hlu%C4%8D%C3%ADn-Darkovi%C4%8Dky_05.jpg?width=900'
                ]
            },
            {
                id: 'breda',
                title: 'Obchodní dům Breda',
                shortDesc: 'Bývalý největší obchodní dům v Československu, architektonický skvost od Leopolda Bauera.',
                location: 'Náměstí Republiky, Opava',
                access: 'Zatím pouze exteriér (probíhá rekonstrukce)',
                type: 'Architektura',
                trivia: 'Breda & Weinstein byl ve 20. a 30. letech 20. století symbolem luxusu a nákupů na úrovni amerických "department stores".',
                description: `
                    <p>Obchodní dům Breda & Weinstein v Opavě je architektonický skvost z roku 1928-1929, postavený podle návrhu věhlasného architekta Leopolda Bauera. Ve své době šlo o největší a nejmodernější obchodní dům v Československu.</p>
                    <p class="mt-4">Budova vyniká svou funkcionalisticko-expresionistickou fasádou, obrovskými prosklenými okny a mohutnou středovou dvoranou zakončenou skleněnou kupolí.</p>
                    <p class="mt-4">Přestože budova dlouhé roky chátrala, v současné době probíhá díky snaze města a občanských spolků její záchrana a velká rekonstrukce, která by měla tomuto klenotu vrátit zpět jeho život.</p>
                `,
                thumbnail: 'https://commons.wikimedia.org/wiki/Special:FilePath/Opava%2C_obchodn%C3%AD_d%C5%AFm_Breda_%281%29.jpg?width=500',
                heroImg: 'https://commons.wikimedia.org/wiki/Special:FilePath/Obchodn%C3%AD_d%C5%AFm_Breda_prosinec_2021.jpg?width=1400',
                gallery: [
                    'https://commons.wikimedia.org/wiki/Special:FilePath/Opava_-_b%C3%BDval%C3%BD_obchodn%C3%AD_d%C5%AFm_Breda.jpg?width=900',
                    'https://commons.wikimedia.org/wiki/Special:FilePath/Obchodn%C3%AD_d%C5%AFm_Breda_prosinec_2021.jpg?width=900',
                    'https://commons.wikimedia.org/wiki/Special:FilePath/Opava%2C_obchodn%C3%AD_d%C5%AFm_Breda_%281%29.jpg?width=900'
                ]
            },
            {
                id: 'sibenice',
                title: 'Rozhledna Šibenice',
                shortDesc: 'Moderní rozhledna u Stěbořic postavená na místě nedokončeného vojenského bunkru.',
                location: 'Stěbořice',
                access: 'Celoročně volně přístupná',
                type: 'Rozhledna / Architektura',
                trivia: 'Design rozhledny vychází z podoby obrovského dělostřeleckého srubu, který zde měl podle předválečných plánů stát na obranu republiky.',
                description: `
                    <p>Rozhledna Šibenice, otevřená v roce 2019, stojí na stejnojmenném kopci nedaleko obce Stěbořice. Není to jen tak ledajaká vyhlídková věž – svým betonově-dřevěným tvarem připomíná předválečný bunkr.</p>
                    <p class="mt-4">Architektonický koncept navazuje na linii československého opevnění. V podzemí se dokonce nacházejí základy nikdy nedostavěného skutečného těžkého dělostřeleckého srubu z roku 1938.</p>
                    <p class="mt-4">Z vrcholu rozhledny, vysoké zhruba 13 metrů, se nabízí fantastický panoramatický výhled na celou opavskou nížinu, za dobré viditelnosti až k vrcholkům Jeseníků a Beskyd.</p>
                `,
                thumbnail: 'https://commons.wikimedia.org/wiki/Special:FilePath/St%C4%9Bbo%C5%99ice%2C_Jamnice%2C_rozhledna_%C5%A0ibenice_%282019-08-14%3B_09%29.jpg?width=500',
                heroImg: 'https://commons.wikimedia.org/wiki/Special:FilePath/St%C4%9Bbo%C5%99ice%2C_Jamnice%2C_rozhledna_%C5%A0ibenice_%282019-08-14%3B_09%29.jpg?width=1400',
                gallery: [
                    'https://commons.wikimedia.org/wiki/Special:FilePath/St%C4%9Bbo%C5%99ice%2C_Jamnice%2C_rozhledna_%C5%A0ibenice_%282019-08-14%3B_09%29.jpg?width=900',
                    'https://commons.wikimedia.org/wiki/Special:FilePath/St%C4%9Bbo%C5%99ice%2C_Jamnice%2C_rozhledna_%C5%A0ibenice_%282019-08-14%3B_09%29.jpg?width=900',
                    'https://commons.wikimedia.org/wiki/Special:FilePath/St%C4%9Bbo%C5%99ice%2C_Jamnice%2C_rozhledna_%C5%A0ibenice_%282019-08-14%3B_09%29.jpg?width=900'
                ]
            },
            {
                id: 'sv-hedvika',
                title: 'Kostel sv. Hedviky',
                shortDesc: 'Moderní monumentální stavba s jedinečnou architekturou, zasvěcená patronce Slezska.',
                location: 'Opava',
                access: 'Při bohoslužbách',
                type: 'Církevní památka',
                trivia: 'Stavba kostela začala před 2. světovou válkou, ale věž byla kvůli válce a komunistickému režimu dokončena až o celých 60 let později.',
                description: `
                    <p>Kostel svaté Hedviky Slezské je jednou z nejmladších, ale nejzajímavějších církevních staveb v Opavě. Vyniká svou funkcionalistickou, puristickou architekturou z pálených cihel.</p>
                    <p class="mt-4">Jde o památník padlým v první světové válce, navržený architektem Leopoldem Bauerem. Základní kámen byl položen v roce 1933, ovšem bouřlivé události 20. století jeho dostavbu několikrát přerušily.</p>
                    <p class="mt-4">Konečné podoby a dostavby majestátní zvonice se kostel dočkal až na konci 90. let. Zvony tak poprvé zazněly na počest návštěvy papeže Jana Pavla II. v roce 1993.</p>
                `,
                thumbnail: 'https://commons.wikimedia.org/wiki/Special:FilePath/Opava%2C_kostel_svat%C3%A9_Hedviky_%281%29.jpg?width=500',
                heroImg: 'https://commons.wikimedia.org/wiki/Special:FilePath/V%C4%9B%C5%BE_kostela..JPG?width=1400',
                gallery: [
                    'https://commons.wikimedia.org/wiki/Special:FilePath/Opava%2C_kostel_svat%C3%A9_Hedviky_%282%29.jpg?width=900',
                    'https://commons.wikimedia.org/wiki/Special:FilePath/Sv_hedvika.JPG?width=900',
                    'https://commons.wikimedia.org/wiki/Special:FilePath/Opava%2C_kostel_svat%C3%A9_Hedviky_%281%29.jpg?width=900'
                ]
            },
            {
                id: 'dvorakovy-sady',
                title: 'Dvořákovy sady',
                shortDesc: 'Anglický park v centru Opavy s pomníkem Petra Bezruče, ideální na procházku i odpočinek.',
                location: 'Centrum, Opava-Město',
                access: 'Celoročně, volný vstup',
                type: 'Park / Příroda',
                trivia: 'V parku stojí pomník básníka Petra Bezruče a také historický meteorologický sloup z počátku 20. století.',
                description: `
                    <p>Dvořákovy sady jsou oblíbeným zeleným útočištěm přímo v centru Opavy, jen pár kroků od Horního náměstí a Konkatedrály. Park v anglickém stylu nabízí vzrostlé stromy, klidné cestičky a lavičky k odpočinku.</p>
                    <p class="mt-4">Central místem parku je pomník slezského básníka Petra Bezruče, kolem kterého se pravidelně konají menší kulturní akce. Nechybí ani zajímavý historický meteorologický sloup.</p>
                    <p class="mt-4">Park je ideálním tipem na procházku po prohlídce historického centra nebo cestou od Slezského zemského muzea, které leží jen kousek odtud.</p>
                `,
                thumbnail: 'https://commons.wikimedia.org/wiki/Special:FilePath/Opava%2C_Dvo%C5%99%C3%A1kovy_sady%2C_Bezru%C4%8D%C5%AFv_pomn%C3%ADk.jpg?width=500',
                heroImg: 'https://commons.wikimedia.org/wiki/Special:FilePath/Opava%2C_Dvo%C5%99%C3%A1kovy_sady%2C_Bezru%C4%8D%C5%AFv_pomn%C3%ADk.jpg?width=1400',
                gallery: [
                    'https://commons.wikimedia.org/wiki/Special:FilePath/Opava%2C_park%2C_informa%C4%8Dn%C3%AD_tabule_%281%29.jpg?width=900',
                    'https://commons.wikimedia.org/wiki/Special:FilePath/Opava%2C_park%2C_informa%C4%8Dn%C3%AD_tabule_%282%29.jpg?width=900',
                    'https://commons.wikimedia.org/wiki/Special:FilePath/Opava%2C_Dvo%C5%99%C3%A1kovy_sady%2C_Bezru%C4%8D%C5%AFv_pomn%C3%ADk.jpg?width=900'
                ]
            },
{"id": "minorite", "title": "Minoritský klášter a kostel sv. Ducha", "shortDesc": "Gotický klášter ze 13. století se Sněmovním sálem – místo setkání tří králů i komorních koncertů.", "location": "Masarykova třída 39, Opava", "access": "Prohlídky a koncerty podle programu, exteriér celoročně", "type": "Klášter / Historie", "trivia": "Roku 1473 se tu podle tradice sešli čeští, polští a uherští panovníci. Pod presbytářem kostela sv. Ducha bývala hrobka opavských knížat.", "description": "<p>Minoritský klášter s kostelem sv. Ducha patří k nejstarším stavbám Opavy – vznikl ve 13. století a je úzce spjatý s opavskou větví Přemyslovců.</p><p class=\"mt-4\">Největším prostorem komplexu je Sněmovní sál pro zhruba 300 lidí, v němž se konají koncerty cyklu Minoritské večery, plesy i konference. Návštěvníci mohou vidět také zimní refektář a gotickou síň.</p><p class=\"mt-4\">Ke klášteru přiléhá budova bývalého zemského sněmu, kde zasedali slezští stavové; dnes část areálu využívá Slezská univerzita.</p>", "thumbnail": "https://commons.wikimedia.org/wiki/Special:FilePath/Minoritsk%C3%BD_kl%C3%A1%C5%A1ter_s_kostelem_sv._Ducha%2C_Opava.JPG?width=800", "heroImg": "https://commons.wikimedia.org/wiki/Special:FilePath/Minoritsk%C3%BD_kl%C3%A1%C5%A1ter_s_kostelem_sv._Ducha%2C_Opava.JPG?width=1920", "alts": ["https://commons.wikimedia.org/wiki/Special:FilePath/Church_of_the_Holy_Spirit_in_Opava_%281%29.jpg?width=1600", "https://commons.wikimedia.org/wiki/Special:FilePath/Minoritsk%C3%BD_kl%C3%A1%C5%A1ter_s_kostelem_sv._Ducha.jpg?width=1600"], "gallery": ["https://commons.wikimedia.org/wiki/Special:FilePath/Church_of_the_Holy_Spirit_in_Opava_%281%29.jpg?width=1000", "https://commons.wikimedia.org/wiki/Special:FilePath/Minoritsk%C3%BD_kl%C3%A1%C5%A1ter%2C_Opava_-_Immaculata.jpg?width=1000", "https://commons.wikimedia.org/wiki/Special:FilePath/Minoritsk%C3%BD_kl%C3%A1%C5%A1ter_s_kostelem_sv._Ducha.jpg?width=1000"]}, {"id": "sv-vojtech", "title": "Kostel sv. Vojtěcha", "shortDesc": "Monumentální barokní jezuitský kostel na Dolním náměstí, inspirovaný římským Il Gesù.", "location": "Dolní náměstí, Opava", "access": "Bohoslužby a koncerty, exteriér celoročně", "type": "Kostel / Baroko", "trivia": "Kostel byl původně zasvěcen sv. Jiří. Sousední bývalá jezuitská kolej dnes slouží Zemskému archivu v Opavě.", "description": "<p>Kostel sv. Vojtěcha vyrostl v poslední čtvrtině 17. století na místě staršího gotického kostela. Jezuité jej stavěli podle vzoru římského kostela Il Gesù, mateřského chrámu svého řádu.</p><p class=\"mt-4\">Patří k nejvýraznějším ukázkám barokního sakrálního umění ve Slezsku – mohutné průčelí uzavírá Dolní náměstí a interiér zdobí bohaté oltáře.</p><p class=\"mt-4\">Kostel býval významným poutním místem a dnes zde kromě bohoslužeb zaznívají i koncerty vážné hudby.</p>", "thumbnail": "https://commons.wikimedia.org/wiki/Special:FilePath/Opava%2C_Doln%C3%AD_n%C3%A1m%C4%9Bst%C3%AD%2C_kostel_sv.Vojt%C4%9Bcha.jpg?width=800", "heroImg": "https://commons.wikimedia.org/wiki/Special:FilePath/Opava%2C_Doln%C3%AD_n%C3%A1m%C4%9Bst%C3%AD%2C_kostel_sv.Vojt%C4%9Bcha.jpg?width=1920", "alts": ["https://commons.wikimedia.org/wiki/Special:FilePath/Opava%2C_kostel_svat%C3%A9ho_Vojt%C4%9Bcha.jpg?width=1600"], "gallery": ["https://commons.wikimedia.org/wiki/Special:FilePath/Opava%2C_kostel_svat%C3%A9ho_Vojt%C4%9Bcha.jpg?width=1000", "https://commons.wikimedia.org/wiki/Special:FilePath/Opava%2C_kostel_sv.Vojt%C4%9Bcha%2C_interi%C3%A9r.jpg?width=1000", "https://commons.wikimedia.org/wiki/Special:FilePath/Opava-Doln%C3%AD_n%C3%A1m._8.JPG?width=1000"]}, {"id": "sv-vaclav", "title": "Kostel sv. Václava a Dům umění", "shortDesc": "Největší stavba slezské cihlové gotiky v českém Slezsku – bývalý dominikánský kostel, dnes výstavní a koncertní síň.", "location": "Masařská / Dům umění, Opava", "access": "Podle programu výstav a koncertů", "type": "Gotika / Kultura", "trivia": "Zasvěcení sv. Václavu mělo zdůraznit přemyslovský původ opavských knížat. Kostel několikrát vyhořel – jen v 15. století dvakrát (1461 a 1490).", "description": "<p>Kostel sv. Václava patřil k dominikánskému klášteru a stavěl se ve dvou etapách: v letech 1291–1305 vznikl chór, sakristie a kaple sv. Dominika, v letech 1318–1336 za knížete Mikuláše II. pak zbytek stavby.</p><p class=\"mt-4\">Na konci 18. století přestal kostel i klášter sloužit církvi. Dnes je areál známý jako Dům umění a jeho vysoká gotická loď hostí výstavy, koncerty i festivaly.</p><p class=\"mt-4\">Červené cihlové zdivo a štíhlá gotická okna z něj dělají jednu z nejfotogeničtějších památek historického centra.</p>", "thumbnail": "https://commons.wikimedia.org/wiki/Special:FilePath/D%C5%AFm_um%C4%9Bn%C3%AD-kostel_sv.V%C3%A1clava_%28Dominik%C3%A1nsk%C3%BD_kl%C3%A1%C5%A1ter%29..JPG?width=800", "heroImg": "https://commons.wikimedia.org/wiki/Special:FilePath/D%C5%AFm_um%C4%9Bn%C3%AD-kostel_sv.V%C3%A1clava_%28Dominik%C3%A1nsk%C3%BD_kl%C3%A1%C5%A1ter%29..JPG?width=1920", "alts": [], "gallery": []}, {"id": "bezruc", "title": "Památník Petra Bezruče", "shortDesc": "Literární muzeum na místě rodného domu autora Slezských písní, centrum festivalu Bezručova Opava.", "location": "Ostrožná 35, Opava", "access": "Út–Ne (Slezské zemské muzeum)", "type": "Muzeum / Literatura", "trivia": "Ve fondech památníku je přes 200 000 dokumentů z pozůstalostí asi 85 spisovatelů. Festival Bezručova Opava vznikl z jeho iniciativy už v roce 1958.", "description": "<p>Památník stojí na místě rodného domu básníka Petra Bezruče (Vladimíra Vaška), který byl těžce poškozen na konci 2. světové války. Nová budova vznikla v letech 1955–1956.</p><p class=\"mt-4\">V přízemí je stálá expozice o životě slezského básníka, v patře sál pro krátkodobé výstavy, přednášky a autorská čtení. Památník je jedním z expozičních objektů Slezského zemského muzea.</p><p class=\"mt-4\">Každé září se z jeho iniciativy koná literární festival Bezručova Opava – nejstarší festival svého druhu v zemi.</p>", "thumbnail": "https://commons.wikimedia.org/wiki/Special:FilePath/Pam%C3%A1tn%C3%ADk_Petra_Bezru%C4%8De_v_roce_2012.jpg?width=800", "heroImg": "https://commons.wikimedia.org/wiki/Special:FilePath/Pam%C3%A1tn%C3%ADk_Petra_Bezru%C4%8De_v_roce_2012.jpg?width=1920", "alts": ["https://commons.wikimedia.org/wiki/Special:FilePath/Pam%C3%A1tn%C3%ADk_Petra_Bezru%C4%8De.jpg?width=1600", "https://commons.wikimedia.org/wiki/Special:FilePath/Opava%2C_Ostro%C5%BEn%C3%A1.JPG?width=1600"], "gallery": ["https://commons.wikimedia.org/wiki/Special:FilePath/Opava%2C_socha_Petra_Bezru%C4%8De.JPG?width=1000", "https://commons.wikimedia.org/wiki/Special:FilePath/Opava%2C_Dvo%C5%99%C3%A1kovy_sady%2C_Bezru%C4%8D%C5%AFv_pomn%C3%ADk.jpg?width=1000"]}, {"id": "svedska-kaple", "title": "Švédská kaple (kaple sv. Kříže)", "shortDesc": "Gotická osmiboká kaple v Kateřinkách s unikátním nástěnným cyklem Apokalypsy.", "location": "Ratibořská ulice, Opava-Kateřinky", "access": "Exteriér celoročně, interiér při komentovaných prohlídkách", "type": "Národní kulturní památka", "trivia": "Je jednou ze tří národních kulturních památek Opavy. Malby uvnitř zobrazují 15 znamení konce světa.", "description": "<p>Kaple sv. Kříže, kterou Opavané znají jako Švédskou kapli, pochází z konce 14. století a její vznik se spojuje s vládou knížete Přemka Opavského.</p><p class=\"mt-4\">Stavba má osmiboký půdorys; původní hvězdicová klenba se při pozdějších přestavbách nedochovala. Největším pokladem je gotický nástěnný cyklus Apokalypsy s patnácti znameními konce světa.</p><p class=\"mt-4\">Kaple leží kousek od zastávek MHD na Ratibořské ulici – ideální zastávka na cestě do Kateřinek.</p>", "thumbnail": "https://commons.wikimedia.org/wiki/Special:FilePath/%C5%A0v%C3%A9dsk%C3%A1_kaple_%28kaple_sv.K%C5%99%C3%AD%C5%BEe%29%2C_Opava-Kate%C5%99inky..JPG?width=800", "heroImg": "https://commons.wikimedia.org/wiki/Special:FilePath/%C5%A0v%C3%A9dsk%C3%A1_kaple_%28kaple_sv.K%C5%99%C3%AD%C5%BEe%29%2C_Opava-Kate%C5%99inky..JPG?width=1920", "alts": [], "gallery": []}, {"id": "horni-namesti", "title": "Horní náměstí a okružní sady", "shortDesc": "Srdce Opavy s Hláskou, divadlem a konkatedrálou, obklopené prstencem parků na místě hradeb.", "location": "Horní náměstí – Dvořákovy, Smetanovy a Janáčkovy sady", "access": "Celoročně, volný vstup", "type": "Město / Procházka", "trivia": "Okružní parky vznikly v 19. století na místě městských hradeb a příkopů. Ve Smetanových sadech jsou dodnes k vidění zbytky opevnění u johanitského kostela.", "description": "<p>Horní náměstí je přirozeným centrem Opavy – na jedné straně Hláska s radnicí, na druhé Slezské divadlo a o kus dál konkatedrála Nanebevzetí Panny Marie. Konají se tu trhy, městské slavnosti i adventní program.</p><p class=\"mt-4\">Historické jádro obepíná zelený prstenec parků – Dvořákovy sady, sady Svobody, Smetanovy sady a Janáčkovy sady. Vznikly postupně v 19. století zasypáním hradebních příkopů; kaštanové aleje v Dvořákových sadech byly vysázeny roku 1856.</p><p class=\"mt-4\">Ve Dvořákových sadech stojí secesní meteorologický sloup z roku 1913 a obnovené arkády, které dnes slouží jako výstavní prostor.</p>", "thumbnail": "https://commons.wikimedia.org/wiki/Special:FilePath/Opava%2C_Horn%C3%AD_n%C3%A1m%C4%9Bst%C3%AD%2C_01.jpg?width=800", "heroImg": "https://commons.wikimedia.org/wiki/Special:FilePath/Opava%2C_Horn%C3%AD_n%C3%A1m%C4%9Bst%C3%AD%2C_01.jpg?width=1920", "alts": ["https://commons.wikimedia.org/wiki/Special:FilePath/Opava%2C_Horn%C3%AD_n%C3%A1m%C4%9Bst%C3%AD_%28srpen_2022%29.jpg?width=1600", "https://commons.wikimedia.org/wiki/Special:FilePath/Opava_Wikivoyage_Banner.jpg?width=1600"], "gallery": ["https://commons.wikimedia.org/wiki/Special:FilePath/Ark%C3%A1dy%2C_Opava_-_M%C4%9Bsto%2C_okres_Opava_03.jpg?width=1000", "https://commons.wikimedia.org/wiki/Special:FilePath/Opava_panorama.jpg?width=1000", "https://commons.wikimedia.org/wiki/Special:FilePath/Opava%2C_Horn%C3%AD_n%C3%A1m%C4%9Bst%C3%AD_%28srpen_2022%29.jpg?width=1000"]}, {"id": "rekordy", "title": "Opavské rekordy a prvenství", "shortDesc": "Nejstarší muzeum v Česku, trolejbusy od roku 1952 a hlavní město Slezska – Opava v číslech.", "location": "Opava – různá místa", "access": "Celoročně", "type": "Rekordy / Zajímavosti", "trivia": "Slezské zemské muzeum bylo založeno roku 1814 a je nejstarším veřejným muzeem na území dnešní České republiky.", "description": "<p><strong>Nejstarší muzeum v Česku.</strong> Slezské zemské muzeum vzniklo v roce 1814 – dřív než Národní muzeum v Praze (1818). Jeho novorenesanční budova v Komenského ulici je dnes jedním z nejkrásnějších muzejních paláců v zemi.</p><p class=\"mt-4\"><strong>Hlavní město Slezska.</strong> V letech 1742–1918 byla Opava metropolí Rakouského Slezska a do roku 1928 i země Slezské. Odtud honosné paláce na Masarykově třídě a velkorysé okružní sady.</p><p class=\"mt-4\"><strong>Trolejbusy od roku 1952.</strong> Trolejbusy jezdí v Opavě nepřetržitě už od roku 1952. Vozy, které dnes vidíš v aplikaci, navazují na více než 70 let tradice.</p><p class=\"mt-4\"><strong>Hláska.</strong> Radniční věž na Horním náměstí, dokončená roku 1618, je symbolem města. Z ochozu věže kdysi strážný hlásil požár či blížící se nebezpečí – odtud název „Hláska“.</p>", "thumbnail": "https://commons.wikimedia.org/wiki/Special:FilePath/Radnice_Hl%C3%A1ska_na_Horn%C3%ADm_n%C3%A1m%C4%9Bst%C3%AD.jpg?width=800", "heroImg": "https://commons.wikimedia.org/wiki/Special:FilePath/Radnice_Hl%C3%A1ska_na_Horn%C3%ADm_n%C3%A1m%C4%9Bst%C3%AD.jpg?width=1920", "alts": ["https://commons.wikimedia.org/wiki/Special:FilePath/Opava%2C_Silesian_Museum_1.jpg?width=1600"], "gallery": ["https://commons.wikimedia.org/wiki/Special:FilePath/Opava%2C_Silesian_Museum_1.jpg?width=1000", "https://commons.wikimedia.org/wiki/Special:FilePath/Radnice_Hl%C3%A1ska_na_Horn%C3%ADm_n%C3%A1m%C4%9Bst%C3%AD.jpg?width=1000"]}, {"id": "tradice", "title": "Opavské tradice a festivaly", "shortDesc": "Bezručova Opava, adventní trhy na Horním náměstí a divadlo s více než dvousetletou historií.", "location": "Horní náměstí a centrum Opavy", "access": "Podle kalendáře akcí", "type": "Tradice / Kultura", "trivia": "Festival Bezručova Opava se koná každoročně od roku 1958 a patří k nejstarším festivalům svého druhu v Česku.", "description": "<p><strong>Bezručova Opava</strong> – festival, který vždy koncem léta oslavuje básníka Petra Bezruče. Za desítky let se z literárního setkání stal vícežánrový festival s divadlem, koncerty a čtením po celém městě.</p><p class=\"mt-4\"><strong>Slezské divadlo</strong> stojí na Horním náměstí od roku 1805 a patří k nejstarším divadelním budovám v Česku. Hraje činohru, operu, operetu i balet.</p><p class=\"mt-4\"><strong>Trhy na Horním náměstí</strong> – náměstí bylo odjakživa hlavním opavským tržištěm. Dodnes se tu konají farmářské a adventní trhy s vánočním stromem pod Hláskou.</p><p class=\"mt-4\"><strong>Tip:</strong> na všechny akce v centru dojedeš MHD na zastávky Divadlo, Hrnčířská nebo Náměstí Republiky.</p>", "thumbnail": "https://commons.wikimedia.org/wiki/Special:FilePath/Slezsk%C3%A9_divadlo_a_radnice_Hl%C3%A1ska%2C_Opava_-_panoramio.jpg?width=800", "heroImg": "https://commons.wikimedia.org/wiki/Special:FilePath/Slezsk%C3%A9_divadlo_a_radnice_Hl%C3%A1ska%2C_Opava_-_panoramio.jpg?width=1920", "alts": ["https://commons.wikimedia.org/wiki/Special:FilePath/Opava_-_Slezsk%C3%A9_Divadlo_01.jpg?width=1600"], "gallery": ["https://commons.wikimedia.org/wiki/Special:FilePath/Opava_-_Slezsk%C3%A9_Divadlo_01.jpg?width=1000", "https://commons.wikimedia.org/wiki/Special:FilePath/Centrum_m%C4%9Bsta_u_divadla.jpg?width=1000"]}
        ];
        const ALT41={"hlaska": ["https://commons.wikimedia.org/wiki/Special:FilePath/Opava_-_radnice.jpg?width=1600", "https://commons.wikimedia.org/wiki/Special:FilePath/Opava%2C_Horn%C3%AD_n%C3%A1m%C4%9Bst%C3%AD%2C_01.jpg?width=1600"], "divadlo": ["https://commons.wikimedia.org/wiki/Special:FilePath/Opava%2C_Horn%C3%AD_n%C3%A1m%C4%9Bst%C3%AD%2C_01.jpg?width=1600", "https://commons.wikimedia.org/wiki/Special:FilePath/Slezsk%C3%A9_divadlo_a_radnice_Hl%C3%A1ska%2C_Opava_-_panoramio.jpg?width=1600"], "dvorakovy-sady": ["https://commons.wikimedia.org/wiki/Special:FilePath/Ark%C3%A1dy%2C_Opava_-_M%C4%9Bsto%2C_okres_Opava_03.jpg?width=1600"], "muzeum": ["https://commons.wikimedia.org/wiki/Special:FilePath/Opava%2C_Silesian_Museum_1.jpg?width=1600"]};
        placesData.forEach(p=>{p.thumbnail=p.thumbnail.replace('width=500','width=800');p.heroImg=p.heroImg.replace('width=1400','width=1920');p.gallery=p.gallery.map(u=>u.replace('width=900','width=1000'));p.alts=(p.alts||[]).concat(ALT41[p.id]||[])});
        (function(){const panel=document.getElementById('bedekr-panel');if(!panel)return;
         panel.addEventListener('error',e=>{const im=e.target;if(!im||im.tagName!=='IMG')return;
          if(im.closest('#detail-gallery')){im.parentElement.remove();return}
          const p=placesData.find(q=>q.title===im.alt);if(!p)return;
          const tried=(im.dataset.tried||'').split('\n');tried.push(im.getAttribute('src'));im.dataset.tried=tried.join('\n');
          const next=[p.heroImg,...p.alts,...p.gallery,p.thumbnail].find(u=>!tried.includes(u));
          if(next)im.src=next;else{im.style.visibility='hidden';im.parentElement.classList.add('img41-none')}},true);
         const gal=document.getElementById('detail-gallery');if(gal){const upd=()=>{gal.parentElement.style.display=gal.children.length?'':'none'};new MutationObserver(upd).observe(gal,{childList:true})}
        })();

        // Reference na DOM elementy
        const mainView = document.getElementById('main-view');
        const detailView = document.getElementById('detail-view');
        const placesGrid = document.getElementById('places-grid');

        // Funkce pro vykreslení úvodních karet
        function renderCards() {
            placesGrid.innerHTML = '';
            placesData.forEach(place => {
                const card = document.createElement('div');
                card.className = 'bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 group flex flex-col h-full border border-slate-100';
                card.innerHTML = `
                    <div class="h-56 card-img-wrap bdk-fit relative" style="--bdk-bg:url('${place.thumbnail}')">
                        <img src="${place.thumbnail}" alt="${place.title}" class="w-full h-full object-contain" loading="lazy">
                        <div class="absolute top-3 right-3 bg-white/90 backdrop-blur px-3 py-1 text-xs font-semibold rounded-full text-slate-800 shadow">
                            ${place.type.split('/')[0].trim()}
                        </div>
                    </div>
                    <div class="p-6 flex flex-col flex-grow">
                        <h3 class="text-2xl font-bold text-slate-900 mb-2 group-hover:text-[#C1784F] transition-colors">${place.title}</h3>
                        <p class="text-slate-600 mb-6 flex-grow leading-relaxed">${place.shortDesc}</p>
                        <button onclick="showDetail('${place.id}')" class="w-full bg-slate-50 hover:bg-[#C1784F] text-slate-800 hover:text-white font-semibold py-3 px-4 rounded-xl border border-slate-200 hover:border-[#C1784F] transition-all duration-300 flex items-center justify-center">
                            <span>Zobrazit více</span>
                            <i class="fa-solid fa-arrow-right ml-2 group-hover:translate-x-1 transition-transform"></i>
                        </button>
                    </div>
                `;
                placesGrid.appendChild(card);
            });
        }

        // Funkce pro zobrazení detailu památky
        function showDetail(id) {
            const place = placesData.find(p => p.id === id);
            if (!place) return;

            // Naplnění dat do DOM
            document.getElementById('detail-title').innerText = place.title;
            document.getElementById('detail-hero-img').src = place.heroImg; document.getElementById('detail-hero-wrap').style.setProperty('--bdk-bg', 'url("' + place.thumbnail + '")');
            document.getElementById('detail-hero-img').alt = place.title;
            document.getElementById('detail-description').innerHTML = place.description;
            document.getElementById('detail-trivia').innerText = place.trivia;
            document.getElementById('detail-location').innerText = place.location;
            document.getElementById('detail-access').innerText = place.access;
            document.getElementById('detail-type').innerText = place.type;

            // Vykreslení galerie
            const galleryContainer = document.getElementById('detail-gallery');
            galleryContainer.innerHTML = '';
            place.gallery.forEach((imgUrl, index) => {
                const imgWrap = document.createElement('div');
                imgWrap.className = 'rounded-xl overflow-hidden h-64 shadow-md hover:shadow-xl transition-shadow cursor-pointer card-img-wrap group';
                imgWrap.innerHTML = `<img src="${imgUrl}" alt="Fotografie z ${place.title} ${index + 1}" class="w-full h-full object-cover">`;
                galleryContainer.appendChild(imgWrap);
            });

            // Přepnutí views
            mainView.classList.add('hidden');
            detailView.classList.remove('hidden');
            
            // Odsrolovat nahoru
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }

        // Funkce pro návrat na hlavní stránku
        function showMainView() {
            detailView.classList.add('hidden');
            mainView.classList.remove('hidden');
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }

        // Inicializace při načtení
        window.addEventListener('DOMContentLoaded', () => {
            renderCards();
        });

    
window.showDetail=showDetail;window.showMainView=showMainView;window.__places41=placesData;
})();
const bedekrPanel=document.getElementById('bedekr-panel'), bedekrBtn=document.getElementById('btn-info');
function setBedekr(open){
  bedekrPanel.classList.toggle('open',open);
  bedekrPanel.setAttribute('aria-hidden',open?'false':'true');
  if(open)document.getElementById('bedekr-body')?.scrollTo({top:0,behavior:'instant'});
}
bedekrBtn.onclick=()=>setBedekr(!bedekrPanel.classList.contains('open'));
document.getElementById('bedekr-close').onclick=()=>setBedekr(false);
