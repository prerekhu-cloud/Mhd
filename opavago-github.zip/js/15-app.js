
(function(){
  const escH = s => String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function ensureSearchSuggest(id){
    const input=document.getElementById(id); if(!input||input.dataset.enhancedSuggest)return;
    input.dataset.enhancedSuggest='1';
    const field=input.closest('.search-field'); if(!field)return;
    let box=document.createElement('div'); box.className='search-suggest-box'; box.style.display='none'; field.appendChild(box);
    const render=()=>{
      const q=input.value.trim(); input.removeAttribute('data-lat'); input.removeAttribute('data-lng');
      if(q.length<2){box.style.display='none';box.innerHTML='';return;}
      let list=[];
      try{
        const nq=normName(q);
        list=(LOGICAL_STOPS||[]).map(s=>({...s,score:(normName(s.name)===nq?0:(normName(s.name).startsWith(nq)?1:(normName(s.name).includes(nq)?2:9)))})).filter(s=>s.score<9).sort((a,b)=>a.score-b.score||a.name.localeCompare(b.name,'cs')).slice(0,5);
      }catch(_){list=[]}
      if(!list.length){box.style.display='none';box.innerHTML='';return;}
      box.innerHTML=list.map((s,i)=>'<div class="search-suggest-item" data-i="'+i+'"><i class="fa-solid fa-bus-simple"></i><span class="suggest-main"><strong>'+escH(cleanName(s.name))+'</strong><small>zastávka MHD Opava</small></span></div>').join('');
      box.style.display='block';
      box.querySelectorAll('.search-suggest-item').forEach(el=>el.onclick=()=>{const s=list[Number(el.dataset.i)];input.value=cleanName(s.name);input.dataset.lat=s.lat;input.dataset.lng=s.lng;box.style.display='none';box.innerHTML='';});
    };
    input.addEventListener('input',render); input.addEventListener('focus',()=>{if(input.value.trim().length>=2)render()});
    document.addEventListener('click',e=>{if(!field.contains(e.target))box.style.display='none'});
  }
  ['from-address','to-address','stop-address'].forEach(ensureSearchSuggest);

  function ensureRideHUD(){
    const host=document.getElementById('mapbox3d'); if(!host||document.getElementById('ride-hud'))return;
    const hud=document.createElement('div');hud.id='ride-hud';hud.innerHTML='<div class="ride-hud-card"><div class="ride-hud-top"><div class="ride-hud-line" id="ride-hud-line">–</div><div class="ride-hud-copy"><div class="ride-hud-overline">JÍZDA VOZIDLEM</div><div class="ride-hud-title" id="ride-hud-title">–</div><div class="ride-hud-model" id="ride-hud-model">–</div></div></div><div class="ride-hud-next"><div class="ride-hud-next-label">PŘÍŠTÍ ZASTÁVKA</div><div class="ride-hud-next-row"><span class="ride-hud-next-dot"></span><span class="ride-hud-next-name" id="ride-hud-next">–</span><span class="ride-hud-next-dist" id="ride-hud-next-dist">–</span></div></div><div class="ride-hud-progress"><i id="ride-hud-progress-bar"></i></div><div class="ride-hud-bottom"><span class="ride-hud-stat" id="ride-hud-stat">–</span><div class="ride-hud-actions"><button id="ride-hud-pause" class="ride-hud-action" type="button"><i class="fa-solid fa-pause"></i> Pauza</button><button id="ride-hud-follow" class="ride-hud-action active" type="button"><i class="fa-solid fa-location-crosshairs"></i> Sledovat</button></div></div></div>';
    host.appendChild(hud);
    document.getElementById('ride-hud-pause')?.addEventListener('click',e=>{
      if(typeof rideSpeedMultiplier==='undefined')return;
      const btn=e.currentTarget;
      if(btn.dataset.paused==='1'){rideSpeedMultiplier=btn.dataset.beforeSpeed==='2'?2:1;btn.dataset.paused='0';btn.innerHTML='<i class="fa-solid fa-pause"></i> Pauza';btn.classList.remove('active');}
      else{btn.dataset.beforeSpeed=rideSpeedMultiplier===2?'2':'1';rideSpeedMultiplier=0;btn.dataset.paused='1';btn.innerHTML='<i class="fa-solid fa-play"></i> Pokračovat';btn.classList.add('active');}
    });
    document.getElementById('ride-hud-follow')?.addEventListener('click',e=>{
      if(typeof rideFollow==='undefined')return;rideFollow=!rideFollow;e.currentTarget.classList.toggle('active',rideFollow);e.currentTarget.innerHTML=rideFollow?'<i class="fa-solid fa-location-crosshairs"></i> Sledovat':'<i class="fa-solid fa-lock-open"></i> Volně';
    });
  }
  function updateRideHUD(){
    const hud=document.getElementById('ride-hud'); if(!hud||!document.body.classList.contains('ride-mode')||!rideBus)return;
    const stops=rideBus._stopsWithDist||[],distance=Math.max(0,Number(rideBus.distance)||0),total=Math.max(1,Number(rideBus.length)||Number(rideBus._ridePlan?.total)||1);
    const nextIndex=Math.min(Math.max(1,rideBus.currentStopIndex||1),Math.max(1,stops.length-1)),next=stops[nextIndex];
    const remaining=next?Math.max(0,next.dist-distance):0;
    const done=Math.max(0,Math.min(100,(distance/total)*100));
    const lineEl=document.getElementById('ride-hud-line'); if(lineEl){lineEl.textContent=rideBus.line||'–';try{lineEl.style.background=lineBadgeColor(String(rideBus.line))}catch(_){lineEl.style.background='#C1784F'}}
    const title=document.getElementById('ride-hud-title');if(title)title.textContent=stops.length?(cleanName(stops[0].name)+' → '+cleanName(stops.at(-1).name)):'Trasa';
    const model=document.getElementById('ride-hud-model');if(model)model.textContent=rideBus.type?.name||rideBus.type?.id||'3D vozidlo';
    const nextName=document.getElementById('ride-hud-next');if(nextName)nextName.textContent=next?cleanName(next.name):'Konečná zastávka';
    const nextDist=document.getElementById('ride-hud-next-dist');if(nextDist)nextDist.textContent=next?(remaining>=1000?(remaining/1000).toFixed(1)+' km':Math.round(remaining)+' m'):'–';
    const bar=document.getElementById('ride-hud-progress-bar');if(bar)bar.style.width=done.toFixed(1)+'%';
    const stat=document.getElementById('ride-hud-stat');if(stat)stat.textContent=Math.round(done)+' % trasy • '+Math.max(0,(stops.length-1)-nextIndex)+' zastávek do cíle';
  }
  ensureRideHUD();
  const startOriginal=window.startRide;
  if(typeof startOriginal==='function'&&!window.__rideHudWrapped){
    window.__rideHudWrapped=true;
    window.startRide=async function(){await startOriginal.apply(this,arguments);ensureRideHUD();updateRideHUD();};
    const endOriginal=window.endRide;
    if(typeof endOriginal==='function')window.endRide=function(){try{const p=document.getElementById('ride-hud-pause');if(p){p.dataset.paused='0';p.classList.remove('active');p.innerHTML='<i class="fa-solid fa-pause"></i> Pauza'}}catch(_){};const r=endOriginal.apply(this,arguments);const hud=document.getElementById('ride-hud');if(hud)hud.style.display='none';return r;};
  }
  function hudLoop(){updateRideHUD();requestAnimationFrame(hudLoop)}
  hudLoop();
  const _show3D=window.show3D;
  if(typeof _show3D==='function'&&!window.__rideHudShow3DWrapped){window.__rideHudShow3DWrapped=true;window.show3D=function(){const r=_show3D.apply(this,arguments);setTimeout(ensureRideHUD,80);return r}}
})();
