

/* ============================================================
   v3 – Mapbox 3D vozidla (native model layer + turf),
        popupy zastávek (2D i 3D), hledání a plánovač spojení
   ============================================================ */
(function(){
'use strict';

/* ---------- 3D MODELY VOZIDEL ---------- */
const GLB='https://prerekhu-cloud.github.io/Mhd/';
const VEHICLE_TYPES=[
 {id:'26tr',         uri:GLB+'26tr.glb',         label:'Škoda 26Tr Solaris',        yaw:0, trolley:true, length:12.0},
 {id:'32tr',         uri:GLB+'32tr.glb',         label:'Škoda 32Tr SOR',            yaw:0, trolley:true, length:12.0},
 {id:'32trdoletrol', uri:GLB+'32trdoletrol.glb', label:'Škoda 32Tr SOR – varianta', yaw:0, trolley:true, length:12.0},
 {id:'36tr',         uri:GLB+'36tr.glb',         label:"Škoda 36Tr T'CITY",        yaw:0, trolley:true, length:12.0},
 {id:'sorelektro',   uri:GLB+'Sorelektro.glb',   label:'SOR NS 12 electric',         yaw:0, length:12.0},
 {id:'sorbus',       uri:GLB+'Sorbus.glb',       label:'SOR NS 12 CNG',              yaw:0, length:12.0},
 {id:'iveco12m',     uri:GLB+'Iveco12m.glb',     label:'Iveco Urbanway 12M CNG',    yaw:0, length:12.0},
 {id:'iveco10m',     uri:GLB+'Iveco10m.glb',     label:'Iveco Urbanway 10,5M CNG',  yaw:0, length:10.5},
 {id:'irisbus',      uri:GLB+'Irisbus.glb',      label:'Irisbus Citelis 12M',        yaw:0, length:12.0},
 {id:'zgroupvelky',  uri:GLB+'Zgroupvelky.glb',  label:'Z-Group – velký autobus',     yaw:0, length:12.0, extra:'regional'},
 {id:'zgroupmaly',   uri:GLB+'Zgroupmaly.glb',   label:'Z-Group – malý autobus',      yaw:0, length:10.5, extra:'regional'},
 {id:'regioshark',   uri:GLB+'Regioshark.glb',   label:'RegioShark',                  yaw:0, length:45.0, extra:'train'},
 {id:'regionova',    uri:GLB+'Regionovamodra.glb',label:'RegioNova (modrá)',          yaw:0, length:28.4, extra:'train'},
 {id:'motorak',      uri:GLB+'Motorakmaly.glb',  label:'Motorák (řada 810)',          yaw:0, length:14.0, extra:'train'}
];
const TROLLEY_UP=GLB+'32tr.glb', TROLLEY_DOWN=GLB+'32trdoletrol.glb';
const TROLLEY_MODELS=VEHICLE_TYPES.filter(v=>v.trolley&&v.id!=='32trdoletrol');
const BUS_MODELS=VEHICLE_TYPES.filter(v=>!v.trolley&&!v.extra);
const TYPE_32TR=VEHICLE_TYPES.find(v=>v.id==='32tr');
const TYPE_32TRDOLETROL=VEHICLE_TYPES.find(v=>v.id==='32trdoletrol');
const LINE204_DOWN_STOP_PAIRS=[
 ['Divadlo','Ratibořská'],
 ['Kylešovice, Bílovecká','Kylešovice, škola']
];
const LINE204_STOP_FALLBACK={
 'divadlo':{lat:49.9394914,lng:17.9004517},
 'ratiborska':{lat:49.9415,lng:17.9016},
 'kylesovice bilovecka':{lat:49.921388,lng:17.909409},
 'kylesovice skola':{lat:49.9268,lng:17.9187}
};
const MAX_VEHICLES=28;
/* Všechny 3D modely na mapě mají stejnou výslednou délku/měřítko. */
const UNIFORM_MODEL_LENGTH=12.0;
/* Posun od osy trasy na pravou stranu jízdního směru (přibližně střed pravého pruhu). */
const RIGHT_LANE_OFFSET_METERS=3.2;
const MODEL_SOURCE='3d-model-source', MODEL_LAYER='3d-vehicles';

let fleet=[], fleetAnim=null, modelLayerReady=false, fleetLastTime=null;

function turfReady(){return typeof turf!=='undefined'&&turf.lineString&&turf.along}

/* plynulé otáčení vozidla směrem k novému bearingu (nejkratší cestou přes 0/360°),
   místo okamžitého "přeskočení" natočení v každém zatáčce trasy */
function mixAngle(a,b,t){const tt=Math.max(0,Math.min(1,t));let diff=((b-a+540)%360)-180;return a+diff*tt;}

function buildFleet(){
 const routes=[];
 for(const [line,dirsArr] of Object.entries(gpxRoutes)){
  if(NIGHT_LINES.has(line))continue;
  dirsArr.forEach((d,di)=>{ if(d.points&&d.points.length>10&&!d.noDrive) routes.push({line,di,points:d.points}); });
 }
 routes.sort((a,b)=>a.line.localeCompare(b.line,'cs',{numeric:true})||a.di-b.di);
 const chosen=routes.slice(0,MAX_VEHICLES);
 fleet=chosen.map((r,i)=>{
  const pool=r.line==='204'?[TYPE_32TR]:(TROLLEY_LINES.has(r.line)?TROLLEY_MODELS:BUS_MODELS);
  const type=pool[i%pool.length];
  const coords=r.points.map(p=>[p[1],p[0]]);
  const ls=turfReady()?turf.lineString(coords):null;
  const length=ls?turf.length(ls,{units:'meters'}):0;
  const v={
   id:'veh-'+i, line:r.line, direction:r.di, type, points:r.points, coords, ls, length,
   metrics:pathMetrics(r.points), offset:Math.random()*(length||1), start:performance.now(),
   speed:9+Math.random()*5, uri:type.uri,
   dualModel:r.line==='204',
   group:{position:{set(){}},scale:{set(){}},rotation:{}}
  };
  return v;
 });
 /* Regionální autobusy a vlaky (nové modely) na vybraných trasách */
 for(const x of (window.__extraFleet41||[])){const type=VEHICLE_TYPES.find(t=>t.id===x.type);if(!type||!x.points||x.points.length<2)continue;const coords=x.points.map(p=>[p[1],p[0]]);const ls=turfReady()?turf.lineString(coords):null;const length=ls?turf.length(ls,{units:'meters'}):0;fleet.push({id:'veh-x'+fleet.length,line:x.line,direction:x.dir,type,points:x.points,coords,ls,length,metrics:pathMetrics(x.points),offset:Math.random()*(length||1),start:performance.now(),speed:11.5,uri:type.uri,dualModel:x.line==='204'&&x.type==='32tr',laneOffset:x.rail?0:undefined,isRail41:!!x.rail,extra41:x.kind,hidden41:true,loop41:!!x.loop,alt41:x.alt||null,mid41:x.mid||0,pick41:!!x.pick,tt41:!!x.tt,group:{position:{set(){}},scale:{set(){}},rotation:{}}})}
 busVehicles=fleet;
 if(fleet.some(v=>v.dualModel))loadOfficialStops().catch(()=>{});
 return fleet;
}
function norm204Name(n){return clean(n).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[,.]/g,' ').replace(/\s+/g,' ').trim()}
function find204StopCoord(name){
 const key=norm204Name(name);
 let best=bestOfficialStop(name);
 if(!best&&officialStops.length){
  best=officialStops.find(s=>{const k=norm204Name(s.name);return k===key||k.includes(key)||key.includes(k)});
 }
 if(best)return {lat:best.lat,lng:best.lng};
 if(LINE204_STOP_FALLBACK[key])return LINE204_STOP_FALLBACK[key];
 return null;
}
function ensure204Segments(v){
 if(v._segReady||!v.dualModel||!turfReady()||!v.ls)return;
 try{
  const ranges=[];
  for(const [a,b] of LINE204_DOWN_STOP_PAIRS){
   const pa=find204StopCoord(a), pb=find204StopCoord(b);
   if(!pa||!pb)return;
   const da=turf.nearestPointOnLine(v.ls,turf.point([pa.lng,pa.lat]),{units:'meters'}).properties.location;
   const db=turf.nearestPointOnLine(v.ls,turf.point([pb.lng,pb.lat]),{units:'meters'}).properties.location;
   ranges.push([Math.min(da,db),Math.max(da,db)]);
  }
  v.trolleyDownRanges=ranges;
  v._segReady=true;
 }catch(e){}
}
function shouldShowTrolleyDown(v){
 if(!v.dualModel)return false;
 if(typeof window.__poles41==='function'){const r=window.__poles41(v);if(r!=null)return r}
 if(!v._segReady)ensure204Segments(v);
 if(!v.trolleyDownRanges)return false;
 return v.trolleyDownRanges.some(([a,b])=>v.distance>=a&&v.distance<=b);
}

function vehiclePose(v,now){
 if(!v.ls||!v.length)return null;
 /* Vzdálenost ujetá po trase (v.distance) je teď PRŮBĚŽNĚ integrovaný stav
    (přírůstek za snímek = dt * aktuální rychlost), ne přepočet z celkového
    uplynulého času od startu × aktuální rychlosti jako dřív. Díky tomu změna
    v.speed (např. 2× zrychlit v jízdě vozidlem) nikdy nezpůsobí skok polohy -
    jen se od aktuálního místa změní tempo přírůstku dál. */
 if(typeof v.distance!=='number')v.distance=(v.offset||0)%v.length;
 const useSpeed=(v.effSpeed!=null?v.effSpeed:v.speed)||0;
 const dt=v._poseLastT?Math.min(now-v._poseLastT,120):16;
 v._poseLastT=now;
 const nextDistance=v.distance+(dt/1000)*useSpeed; v.distance=(typeof rideActive!=='undefined'&&rideActive&&typeof rideBus!=='undefined'&&v===rideBus)?Math.min(v.length,nextDistance):(nextDistance+v.length)%v.length;
 const d=v.distance;
 const p=turf.along(v.ls,d,{units:'meters'}).geometry.coordinates;
 const n=turf.along(v.ls,Math.min(v.length,d+6),{units:'meters'}).geometry.coordinates;
 const brg=turf.bearing(turf.point(p),turf.point(n));
 /* Vždy pravý pruh vzhledem k aktuálnímu směru jízdy.
    U protisměrných vozidel se posun automaticky provede na opačnou stranu silnice. */
 const right=turf.destination(turf.point(p),(v.laneOffset??RIGHT_LANE_OFFSET_METERS)/1000,brg+90,{units:'kilometers'}).geometry.coordinates;
 v.lngLat=right; v.bearing=brg;
 return {position:right,bearing:brg};
}


/* --- THREE.js GLB modely vozidel v Mapbox custom layeru --- */
const MODEL_TARGET_LEN=12.0;      // délka vozidla v metrech
const modelCache=new Map();       // uri -> Promise<THREE.Object3D>
let gltfLoader=null, fleetSpawned=false, lastScene=null;

function threeReady(){return typeof THREE!=='undefined'&&typeof THREE.GLTFLoader==='function'}

function prepModel(root,targetLen){
 root.updateMatrixWorld(true);
 const box=new THREE.Box3().setFromObject(root);
 const size=new THREE.Vector3();box.getSize(size);
 const center=new THREE.Vector3();box.getCenter(center);
 const scale=(targetLen||UNIFORM_MODEL_LENGTH)/Math.max(.001,size.z);
 root.position.set(-center.x,-box.min.y,-center.z);
 const scaled=new THREE.Group();scaled.add(root);scaled.scale.setScalar(scale);
 /* glTF má osu Y svisle, Mapbox custom layer osu Z svisle. */
 const zUp=new THREE.Group();zUp.add(scaled);zUp.rotation.x=Math.PI/2;
 const holder=new THREE.Group();holder.add(zUp);holder.userData.ready=true;
 return holder;
}

function loadModel(uri,targetLen){
 if(modelCache.has(uri))return modelCache.get(uri);
 const p=new Promise((res,rej)=>{
  if(!gltfLoader){gltfLoader=new THREE.GLTFLoader();try{gltfLoader.setCrossOrigin('anonymous')}catch(e){}}
  gltfLoader.load(uri,g=>{try{
   g.scene.traverse(o=>{if(!o.isMesh)return;o.castShadow=true;o.frustumCulled=false;
    /* modely se zapečenou texturou (jen emissive): zobrazit přesně barvy textury bez dalšího osvětlení */
    if(o.material&&!Array.isArray(o.material)&&!o.material.map&&o.material.emissiveMap){const t=o.material.emissiveMap;t.encoding=THREE.LinearEncoding;t.flipY=false;t.needsUpdate=true;const bm=new THREE.MeshBasicMaterial({map:t,side:THREE.DoubleSide});bm.color.setScalar(.9);bm.userData.basic41=true;(window.__basicMats41=window.__basicMats41||[]).push(bm);o.material=bm;return}
    (Array.isArray(o.material)?o.material:[o.material]).filter(Boolean).forEach(mat=>{
     if(mat.map){mat.map.encoding=THREE.sRGBEncoding;mat.map.flipY=false;mat.map.needsUpdate=true}
     if(mat.emissive){mat.emissive.setRGB(0,0,0);mat.emissiveIntensity=0}
     if(mat.color)mat.color.setRGB(1,1,1);mat.side=THREE.DoubleSide;mat.depthWrite=true;mat.needsUpdate=true;
    });
   });res(prepModel(g.scene,targetLen));
  }catch(e){rej(e)}},undefined,err=>rej(err));
 });modelCache.set(uri,p);return p;
}

/* GLTFLoader.load nemá vlastní timeout – při zablokovaném/"zaseknutém" stahování
   (typicky content:// / file:// stránka na mobilu) by se promise nikdy nerozhodla
   a vozidlo by čekalo navždy. Proto po X ms bereme model jako nedostupný. */
function withTimeout(promise,ms){
 return new Promise((res,rej)=>{
  const t=setTimeout(()=>rej(new Error('timeout po '+ms+'ms')),ms);
  promise.then(v=>{clearTimeout(t);res(v)},e=>{clearTimeout(t);rej(e)});
 });
}

/* náhradní jednoduchý 3D model vozidla – použije se, pokud se GLB nepodaří stáhnout
   (výpadek sítě / CORS / špatná cesta / zaseknuté stahování), aby vozidlo i tak jezdilo po trase */
function buildFallbackModel(type){
 const root=buildBus(type);
 return prepModel(root,type.length||MODEL_TARGET_LEN);
}

/* Stejné GLB modely jako v garáži, všechny ve shodném měřítku. */
async function spawnFleetModels(){
 if(fleetSpawned)return;const scene=threeLayer&&threeLayer.scene;
 if(!scene){setTimeout(spawnFleetModels,500);return}fleetSpawned=true;
 const byType=new Map();for(const v of fleet){const k=v.type.id;if(!byType.has(k))byType.set(k,[]);byType.get(k).push(v)}
 await Promise.allSettled([...byType.values()].map(async vehs=>{const type=vehs[0].type;try{
  const proto=await loadModel(type.uri,type.extra?type.length:UNIFORM_MODEL_LENGTH);if(!threeLayer||threeLayer.scene!==scene)return;
  for(const v of vehs){const g=proto.clone(true);g.visible=false;scene.add(g);v.group=g}map3d?.triggerRepaint();
 }catch(err){console.error('[fleet] GLB se nepodařilo načíst:',type.id,err)}}));
 const dualVehicles=fleet.filter(v=>v.dualModel);
 if(dualVehicles.length){
  try{
   const protoAlt=await loadModel(TYPE_32TRDOLETROL.uri,UNIFORM_MODEL_LENGTH);
   if(threeLayer&&threeLayer.scene===scene){
    for(const v of dualVehicles){const g=protoAlt.clone(true);g.visible=false;scene.add(g);v.groupAlt=g}
    map3d?.triggerRepaint();
   }
  }catch(err){console.error('[fleet] GLB varianty 32Tr (trolejemi dole) se nepodařilo načíst:',err)}
 }
}

/* render() se teď řeší přímo v initThreeLayer() peče maticí, takže žádný patch
   už není potřeba – funkce zůstává jako neškodná no-op kvůli zpětné kompatibilitě
   volání jinde v kódu */
function patchThreeRender(){}

const TILT_SAMPLE_M=6;      // jak daleko před/za vozidlem se vzorkuje terén pro sklon
const MAX_TILT_RAD=9*Math.PI/180;  // maximální náklon vozidla (ochrana proti šumu v datech terénu)
const TILT_INVERT=false;    // přepni na true, pokud by se vozidla nakláněla opačně, než mají
const NOOVERTAKE_RADIUS_M=13;  // minimální rozestup mezi vozidly jedoucími za sebou stejným směrem
const NOOVERTAKE_CONE_DEG=32;  // "vozidlo přímo přede mnou, stejným směrem" - úhlová tolerance

function animateFleet(){
 fleetAnim=requestAnimationFrame(animateFleet);
 if(!map3d||!map3dReady||!turfReady()||!fleet.length)return;
 const now=performance.now();
 const dt=fleetLastTime?Math.min(now-fleetLastTime,120):16;
 fleetLastTime=now;
 let any=false;
 for(const v of fleet){
  /* vehiclePose() se volá VŽDY (i než se dotáhne 3D model), aby poloha vozidla
     (lngLat/bearing/distance) byla vždy čerstvá - jízda vozidlem se totiž na
     tato pole spoléhá i dřív, než se stihne stáhnout GLB model. */
  /* vozidla 'na vyžádání' (výběr linky pro jízdu) se mimo jízdu vůbec nepočítají */
  if(((v.pick41||v.tt41)&&v.hidden41||v.skip41)&&v!==rideBus){if(v.group)v.group.visible=false;if(v.groupAlt)v.groupAlt.visible=false;continue}
  const pose=vehiclePose(v,now); if(!pose)continue;

  /* Náklon vozidla podle sklonu terénu (z kopce / do kopce) - porovnáme výšku
     terénu kousek před a za vozidlem podél trasy a nakloníme model tak, aby
     zůstal rovnoběžný se svahem, místo aby "plaval" vodorovně nad/pod terénem. */
  let pitch=0;
  const dAhead=Math.min(v.length,v.distance+TILT_SAMPLE_M);
  const dBehind=Math.max(0,v.distance-TILT_SAMPLE_M);
  if(dAhead>dBehind){
   const pAh=turf.along(v.ls,dAhead,{units:'meters'}).geometry.coordinates;
   const pBe=turf.along(v.ls,dBehind,{units:'meters'}).geometry.coordinates;
   const eAh=groundElevation(pAh),eBe=groundElevation(pBe);
   let grade=Math.atan2((eAh-eBe)||0,Math.max(1,dAhead-dBehind));
   grade=Math.max(-MAX_TILT_RAD,Math.min(MAX_TILT_RAD,grade));
   pitch=TILT_INVERT?grade:-grade;
  }
  if(v.smoothTilt==null)v.smoothTilt=pitch;
  v.smoothTilt+=(pitch-v.smoothTilt)*Math.min(1,dt*0.004);

  const g=v.group; if(!g||!g.userData||!g.userData.ready)continue;
  if(v.smoothBearing==null)v.smoothBearing=pose.bearing;
  /* natáčení vozidla plynule dohání skutečný bearing trasy – vozidlo tak
     v zatáčkách "zatáčí", místo aby se okamžitě přeskočilo na nový úhel */
  v.smoothBearing=mixAngle(v.smoothBearing,pose.bearing,dt*0.006);
  /* poslední známou výšku terénu dočasně cachujeme na vozidle, aby vozidlo
     nezacukalo, když dlaždice terénu ještě není načtená (queryTerrainElevation vrátí null) */
  const elev=groundElevation(pose.position);
  v.groundElev=(elev||elev===0)?elev:(v.groundElev||0);
  const mc=mapboxgl.MercatorCoordinate.fromLngLat(pose.position,v.groundElev);
  const sc=mc.meterInMercatorCoordinateUnits();
  const rz=THREE.MathUtils.degToRad(-(v.smoothBearing+(v.type.yaw||0))+180);
  /* lokální matice vozidla (bez mapové projekce) – v render() se jen vynásobí
     aktuální mapovou maticí. Jednotné kladné měřítko (žádné záporné Y) přesně
     podle ověřeného postupu z man1.html; Y-up→Z-up konverze je už jednou
     zapečená v prepModel() (yUpFix), takže se tu neopakuje. Náklon (pitch) se
     násobí AŽ ZA otočením podle bearingu, takže se vždy nakloní ve směru jízdy
     vozidla, bez ohledu na to, kterým směrem zrovna jede. */
  if(!v.localMatrix)v.localMatrix=new THREE.Matrix4();
  v.localMatrix.makeTranslation(mc.x,mc.y,mc.z)
   .multiply(new THREE.Matrix4().makeScale(sc,-sc,sc))
   .multiply(new THREE.Matrix4().makeRotationZ(rz))
   .multiply(new THREE.Matrix4().makeRotationX(v.smoothTilt||0));
  if(v.dualModel){
   const showAlt=shouldShowTrolleyDown(v);
   g.visible=!showAlt;
   if(v.groupAlt)v.groupAlt.visible=showAlt;
  }else{
   g.visible=!v.hidden41;
  }
  any=true;
 }

 /* Zabránění "předjíždění": pokud je jiné vozidlo těsně vpředu ve stejném
    směru jízdy (v úzkém kuželu před vozidlem, blízko), dočasně přibrzdíme na
    jeho rychlost, aby se vozidla vizuálně neprojížděla skrz sebe / nepředjížděla.
    effSpeed se přepočítává každý snímek, takže jakmile vozidlo vpředu odjede
    dál, vozidlo za ním samo zase zrychlí zpět na svou běžnou rychlost. */
 for(const v of fleet){
  if(!v.lngLat)continue;
  let leaderSpeed=null,bestGap=Infinity;
  for(const o of fleet){
   if(o===v||!o.lngLat||o.hidden41||v.hidden41||v.tt41||!!o.isRail41!==!!v.isRail41)continue;
   const gap=turf.distance(turf.point(v.lngLat),turf.point(o.lngLat),{units:'meters'});
   if(gap>=NOOVERTAKE_RADIUS_M)continue;
   const brgTo=turf.bearing(turf.point(v.lngLat),turf.point(o.lngLat));
   const aheadDiff=Math.abs((((brgTo-v.bearing)+540)%360)-180);
   if(aheadDiff>NOOVERTAKE_CONE_DEG)continue;
   const headingDiff=Math.abs((((( o.bearing||0)-(v.bearing||0))+540)%360)-180);
   if(headingDiff>NOOVERTAKE_CONE_DEG)continue;
   if(gap<bestGap){bestGap=gap;leaderSpeed=(o.effSpeed!=null?o.effSpeed:o.speed);}
  }
  v.effSpeed=(bestGap<NOOVERTAKE_RADIUS_M&&leaderSpeed!=null)?Math.min(v.speed,leaderSpeed*0.97):null;
 }

 if(any)map3d.triggerRepaint();
}

function startFleet(){
 if(!turfReady()||!threeReady()){setTimeout(startFleet,300);return}
 if(!map3d||!map3dReady){setTimeout(startFleet,300);return}
 if(!threeLayer||!threeLayer.scene){try{if(map3d.getLayer('3d-vehicles'))map3d.removeLayer('3d-vehicles');initThreeLayer()}catch(e){console.warn('[fleet] initThreeLayer:',e)}}
 if(!threeLayer||!threeLayer.scene){setTimeout(startFleet,400);return}
 if(lastScene!==threeLayer.scene){lastScene=threeLayer.scene;fleetSpawned=false;fleet.forEach(v=>{v.group=null});}
 if(!fleet.length)buildFleet();
 console.log('[fleet] start, vozidel:',fleet.length,'threeLayer:',!!threeLayer);
 patchThreeRender();
 spawnFleetModels();
 if(!fleetAnim)animateFleet();
 modelLayerReady=true;
}

make3dVehicles=function(){ const riding=typeof rideActive!=='undefined'&&rideActive&&rideBus; if(!riding&&(!fleet.length||(turfReady()&&fleet.some(v=>!v.ls)))) buildFleet(); else busVehicles=fleet; startFleet(); };
window.fleetDebug=()=>({total:fleet.length,loaded:fleet.filter(v=>v.group&&v.group.userData&&v.group.userData.ready).length,visible:fleet.filter(v=>v.group&&v.group.visible).length,spawned:fleetSpawned,cache:modelCache.size,three:threeReady(),turf:turfReady(),layer:!!(threeLayer&&threeLayer.scene),anim:!!fleetAnim,ready:map3dReady});
window.fleetStart=startFleet;
window.__fleetReset=function(){fleetSpawned=false;fleetLastTime=null;fleet.forEach(v=>{v.group=null;v.smoothBearing=null;});startFleet();};

/* ---------- POPUP ZASTÁVKY (2D i 3D) ---------- */
function stopLines(s){ try{return linesAtOfficialStop(s)}catch(e){return []} }
function stopPopupHTML(s,lines,loading){
 const badges=(lines&&lines.length)?`<div class="sp-lines">${lines.map(n=>`<span class="sp-line" data-line="${esc(n)}">${esc(n)}</span>`).join('')}</div>`
   :`<div class="sp-empty">${loading?'Načítám linky…':'Linky nejsou v datech k dispozici.'}</div>`;
 return `<div class="stop-pop">
  <div class="sp-head"><span class="sp-name">${esc(clean(s.name))}</span>${s.request?'<span class="sp-req"><i class="fa-solid fa-thumbs-up"></i> na znamení</span>':''}</div>
  <div class="sp-meta">${s.direction?'Směr: '+esc(s.direction):'Zastávka MHD Opava'}</div>
  <div class="sp-label">Obsluhující linky</div>${badges}
  <button class="sp-departures" data-stop="${esc(s.rawName||s.name)}"><i class="fa-solid fa-clock"></i> Odjezdy v reálném čase</button></div>`;
}
function bindLineBadges(root){
 if(!root)return;
 root.querySelectorAll('.sp-line').forEach(b=>b.onclick=()=>{const l=b.dataset.line;if(l)try{openLine(l)}catch(e){}});
 root.querySelectorAll('.sp-departures').forEach(b=>b.onclick=()=>{const n=b.dataset.stop;if(n&&typeof openDeparturesPanel==='function')openDeparturesPanel(n)});
}

renderOfficialStopMarkers=function(){
 stopMarkers.clearLayers();
 /* Zastávky mívají v datech více záznamů se stejným názvem (různá nástupiště /
    směry na stejném místě) - dřív se kreslilo kolečko pro každý záznam zvlášť.
    Teď seskupíme podle názvu a vykreslíme jen jedno (menší) kolečko na zastávku. */
 const groups=new Map();
 for(const s of officialStops){
  const key=normalizePlannerName(s.name);
  if(!groups.has(key))groups.set(key,[]);
  groups.get(key).push(s);
 }
 for(const arr of groups.values()){
  const s=arr[0];
  const anyRequest=arr.some(x=>x.request);
  const icon=L.divIcon({className:'opava-stop-marker',html:`<div class="opava-stop-icon ${anyRequest?'request':''}"></div>`,iconSize:[9,9],iconAnchor:[4,4]});
  const marker=L.marker([s.lat,s.lng],{icon,zIndexOffset:300});
  const groupLines=()=>[...new Set(arr.flatMap(x=>stopLines(x)))];
  marker.bindPopup(stopPopupHTML(s,groupLines(),!networkLoaded),{maxWidth:280});
  marker.on('popupopen',ev=>{
   const refresh=()=>{try{marker.setPopupContent(stopPopupHTML(s,groupLines(),false));bindLineBadges(marker.getPopup().getElement())}catch(e){}};
   if(networkLoaded)refresh(); else loadGTFS().then(refresh).catch(()=>{});
   bindLineBadges(ev.popup.getElement());
  });
  marker.addTo(stopMarkers);
 }
};

function open3dStopPopup(lngLat,name){
 const s=officialStops.find(x=>normalizePlannerName(x.name)===normalizePlannerName(name))||{name,request:0,direction:''};
 const pop=new mapboxgl.Popup({closeButton:true,maxWidth:'280px',className:'mapbox-stop-popup'})
  .setLngLat(lngLat).setHTML(stopPopupHTML(s,stopLines(s),!networkLoaded)).addTo(map3d);
 const done=()=>{try{pop.setHTML(stopPopupHTML(s,stopLines(s),false));bindLineBadges(pop.getElement())}catch(e){}};
 if(networkLoaded)done(); else loadGTFS().then(done).catch(()=>{});
 bindLineBadges(pop.getElement());
}

/* ---------- 3D MAPA: bez popisků, bližší pohled ---------- */
apply3dBasemap=function(){
 if(!map3d)return;
 try{
  const dark=document.body.classList.contains('dark');
  map3d.setConfigProperty?.('basemap','lightPreset',dark?'night':'day');
  map3d.setConfigProperty?.('basemap','showPointOfInterestLabels',false);
  map3d.setConfigProperty?.('basemap','showPlaceLabels',false);
  map3d.setConfigProperty?.('basemap','showRoadLabels',false);
  map3d.setConfigProperty?.('basemap','showTransitLabels',false);
  map3d.setConfigProperty?.('basemap','show3dObjects',true);
  if(map3d.getLayer(MODEL_LAYER))map3d.setPaintProperty(MODEL_LAYER,'model-emissive-strength',dark?0.9:0.25);
 }catch(e){}
};

initMapbox3D=function(){
 if(map3d)return;
 mapboxgl.accessToken=MAPBOX_TOKEN;
 map3d=new mapboxgl.Map({
  container:'mapbox3d', style:'mapbox://styles/mapbox/standard',
  center:[OPAVA_CENTER[1],OPAVA_CENTER[0]], zoom:15.6, pitch:62, bearing:-18,
  antialias:true, projection:'mercator', maxPitch:80
 });
 map3d.addControl(new mapboxgl.NavigationControl({visualizePitch:true}),'bottom-right');
 map3d.on('style.load',()=>{
  apply3dBasemap();
  try{
   if(!map3d.getSource('mapbox-dem')){
    map3d.addSource('mapbox-dem',{type:'raster-dem',url:'mapbox://mapbox.mapbox-terrain-dem-v1',tileSize:512,maxzoom:14});
    map3d.setTerrain({source:'mapbox-dem',exaggeration:1.05});
   }
  }catch(e){}
  if(!map3d.getSource('routes-3d'))map3d.addSource('routes-3d',{type:'geojson',data:geojsonRoutes()});
  if(!map3d.getLayer('routes-3d-line'))map3d.addLayer({id:'routes-3d-line',type:'line',source:'routes-3d',slot:'middle',
    layout:{'line-cap':'round','line-join':'round'},
    paint:{'line-color':document.body.classList.contains('dark')?'#E39A70':'#C1784F','line-width':['interpolate',['linear'],['zoom'],10,3,14,3,16,4.55,18,18.2,20,72.9],'line-opacity':.9}});
  if(!map3d.getLayer('routes-3d-hit'))map3d.addLayer({id:'routes-3d-hit',type:'line',source:'routes-3d',slot:'middle',
    paint:{'line-color':'#000','line-width':18,'line-opacity':0}});
  if(!map3d.getSource('stops-3d'))map3d.addSource('stops-3d',{type:'geojson',data:geojsonStops()});
  else map3d.getSource('stops-3d').setData(geojsonStops());
  if(!map3d.getLayer('stops-3d'))map3d.addLayer({id:'stops-3d',type:'circle',source:'stops-3d',slot:'middle',
   paint:{'circle-radius':['interpolate',['linear'],['zoom'],11,3,14,6,17,9],
          'circle-color':['case',['==',['get','request'],1],'#C1784F','#ffffff'],
          'circle-stroke-color':'#C1784F','circle-stroke-width':2,'circle-opacity':.98,'circle-pitch-alignment':'map'}});
  map3d.on('click','stops-3d',e=>{const f=e.features&&e.features[0];if(!f)return;
   open3dStopPopup(f.geometry.coordinates.slice(),f.properties?.name||'');});
  map3d.on('mouseenter','stops-3d',()=>map3d.getCanvas().style.cursor='pointer');
  map3d.on('mouseleave','stops-3d',()=>map3d.getCanvas().style.cursor='');
  map3d.on('click','routes-3d-hit',e=>{
   const feats=map3d.queryRenderedFeatures(e.point,{layers:['routes-3d-hit']});
   const lines=[...new Set(feats.map(f=>f.properties?.line).filter(Boolean))];
   if(!lines.length)return;
   new mapboxgl.Popup({closeButton:true,maxWidth:'280px'}).setLngLat(e.lngLat)
    .setHTML('<div class="stop-pop"><div class="sp-head"><span class="sp-name">Linky na úseku</span></div><div class="sp-lines">'+lines.map(n=>`<span class="sp-line" data-line="${esc(n)}">${esc(n)}</span>`).join('')+'</div></div>').addTo(map3d);
  });
  try{
   if(map3d.getSource('composite')&&!map3d.getLayer('add-3d-buildings')){
    map3d.addLayer({id:'add-3d-buildings',source:'composite','source-layer':'building',filter:['==','extrude','true'],
     type:'fill-extrusion',minzoom:12,slot:'middle',
     paint:{'fill-extrusion-color':document.body.classList.contains('dark')?'#3a3734':'#b8b0a8',
            'fill-extrusion-opacity':.95,'fill-extrusion-height':['get','height'],'fill-extrusion-base':['get','min_height']}});
   }
  }catch(e){}
  map3dReady=true;
  make3dVehicles();
  try{sync3dStops()}catch(e){}
  try{push3dSearchRoute()}catch(e){}
  push3dHighlight();
  try{updateRideStops()}catch(e){}
 });
 map3d.on('load',()=>map3d.resize());
};

updateRide=function(){
 if(!rideActive||!rideBus||!map3dReady)return;
 const now=performance.now();
 if(typeof rideSpeed==='number')rideBus.speed=Math.max(3,rideSpeed*1.4);
 if(rideBus.ls)vehiclePose(rideBus,now);
 const stops=rideStopsFor(rideBus.line,rideBus.direction);
 if(rideBus.lngLat&&stops.length){
  let nearest=0,best=1e9;
  stops.forEach((s,i)=>{if(!Number.isFinite(s.lat))return;const d=haversine([s.lat,s.lng],[rideBus.lngLat[1],rideBus.lngLat[0]]);if(d<best){best=d;nearest=i}});
  if(nearest!==rideBus.currentStopIndex){rideBus.currentStopIndex=nearest;updateRideStops();}
 }
 if(rideFollow&&rideBus.lngLat){
  /* Vyhlazení otočení kamery (aby nekmitala při drobných odchylkách trasy). */
  if(typeof rideBus._smoothBearing!=='number')rideBus._smoothBearing=rideBus.bearing;
  const diff=((rideBus.bearing-rideBus._smoothBearing+540)%360)-180;
  rideBus._smoothBearing=(rideBus._smoothBearing+diff*0.18+360)%360;
  /* jumpTo (bez animace) volané každý snímek - plynulost vzniká z frekvence volání.
     Předchozí easeTo s trváním se volalo 60x/s a jednotlivé animace se navzájem
     přebíjely, což způsobovalo trhaný pohyb kamery. */
  map3d.jumpTo({center:rideBus.lngLat,bearing:rideBus._smoothBearing,zoom:16.4,pitch:64});
 }
 requestAnimationFrame(updateRide);
};

/* ---------- ZVÝRAZNĚNÍ ADRESY A ZASTÁVEK ---------- */
const highlightLayer=L.layerGroup().addTo(map);
let highlightData={type:'FeatureCollection',features:[]};

function push3dHighlight(){
 if(!map3d||!map3dReady)return;
 try{
  if(!map3d.getSource('highlight-3d')){
   map3d.addSource('highlight-3d',{type:'geojson',data:highlightData});
   map3d.addLayer({id:'highlight-3d-halo',type:'circle',source:'highlight-3d',slot:'middle',
    paint:{'circle-radius':['case',['==',['get','kind'],'address'],18,13],
           'circle-color':['case',['==',['get','kind'],'address'],'#2F6F4E','#C1784F'],
           'circle-opacity':.28,'circle-pitch-alignment':'map'}});
   map3d.addLayer({id:'highlight-3d-dot',type:'circle',source:'highlight-3d',slot:'middle',
    paint:{'circle-radius':['case',['==',['get','kind'],'address'],7,6],
           'circle-color':['case',['==',['get','kind'],'address'],'#2F6F4E','#C1784F'],
           'circle-stroke-color':'#fff','circle-stroke-width':2,'circle-pitch-alignment':'map'}});
  }else map3d.getSource('highlight-3d').setData(highlightData);
 }catch(e){}
}
function clearHighlights(){
 highlightLayer.clearLayers();
 highlightData={type:'FeatureCollection',features:[]};
 push3dHighlight();
}
function highlightAddress(loc){
 highlightLayer.addLayer(L.circle([loc.lat,loc.lng],{radius:70,color:'#2F6F4E',weight:2,fillColor:'#2F6F4E',fillOpacity:.12}));
 highlightLayer.addLayer(L.marker([loc.lat,loc.lng],{icon:L.divIcon({className:'hl-address',html:'<div class="hl-pin"><i class="fa-solid fa-location-dot"></i></div>',iconSize:[30,30],iconAnchor:[15,28]}),zIndexOffset:900})
  .bindPopup('<div class="stop-pop"><div class="sp-head"><span class="sp-name">Hledané místo</span></div><div class="sp-meta">'+esc(loc.label||'')+'</div></div>'));
 highlightData.features.push({type:'Feature',properties:{kind:'address',label:loc.label||''},geometry:{type:'Point',coordinates:[loc.lng,loc.lat]}});
 push3dHighlight();
}
function highlightStops(stops){
 stops.forEach((s,i)=>{
  const lines=stopLines(s);
  highlightLayer.addLayer(L.circleMarker([s.lat,s.lng],{radius:13,color:'#C1784F',weight:3,fillColor:'#C1784F',fillOpacity:.18}));
  const m=L.marker([s.lat,s.lng],{icon:L.divIcon({className:'hl-stop',html:`<div class="hl-badge">${i+1}</div>`,iconSize:[24,24],iconAnchor:[12,12]}),zIndexOffset:950})
   .bindPopup(stopPopupHTML(s,lines,!networkLoaded),{maxWidth:280});
  m.on('popupopen',ev=>bindLineBadges(ev.popup.getElement()));
  highlightLayer.addLayer(m);
  highlightData.features.push({type:'Feature',properties:{kind:'stop',name:s.name},geometry:{type:'Point',coordinates:[s.lng,s.lat]}});
 });
 push3dHighlight();
}

runNearestSearch=async function(){
 try{
  setSearchStatus('nearest-status','Hledám…');
  document.getElementById('nearest-results').innerHTML='';
  await loadPlannerStops();
  if(!networkLoaded){try{await loadGTFS()}catch(e){}}
  const el=document.getElementById('stop-address');
  let loc;
  if(el.dataset.lat&&el.dataset.lng)loc={lat:Number(el.dataset.lat),lng:Number(el.dataset.lng),label:el.value};
  else loc=await geocodeAddress(el.value.trim());
  const nearest=nearestPlannerStops(loc.lat,loc.lng,4);
  if(!nearest.length)throw Error('V okolí nebyly nalezeny zastávky.');
  clearHighlights();
  highlightAddress(loc);
  highlightStops(nearest);
  renderNearest(nearest,loc.lat,loc.lng,loc);
  const b=L.latLngBounds([[loc.lat,loc.lng],...nearest.map(s=>[s.lat,s.lng])]);
  map.fitBounds(b,{padding:[70,70],animate:true});
  setSearchStatus('nearest-status','Nalezeno '+nearest.length+' nejbližších zastávek u: '+String(loc.label||'').split(',')[0]);
 }catch(e){setSearchStatus('nearest-status',e.message||'Vyhledávání se nepodařilo.',true)}
};

renderNearest=function(results,lat,lng,loc){
 const box=document.getElementById('nearest-results');
 box.innerHTML=`<div class="nearest-title">Hledané místo</div>
  <div class="hl-address-row"><i class="fa-solid fa-location-dot"></i><span>${esc((loc&&loc.label)||'')}</span></div>
  <div class="nearest-title">Nejbližší zastávky a jejich linky</div>`+
  results.map((s,i)=>{
   const lines=stopLines(s);
   return `<div class="nearest-row" data-lat="${s.lat}" data-lng="${s.lng}">
    <span class="nearest-num">${i+1}</span>
    <span class="nearest-name">${esc(clean(s.name))}${s.request?' <i class="fa-solid fa-thumbs-up sp-req-ico" title="na znamení"></i>':''}
     <span class="nearest-lines">${lines.length?lines.map(n=>`<span class="sp-line" data-line="${esc(n)}">${esc(n)}</span>`).join(''):'<span class="sp-empty">linky nejsou v datech</span>'}</span>
    </span>
    <span class="nearest-dist">${formatDistance(s.distance)}</span></div>`;
  }).join('');
 box.querySelectorAll('.nearest-row').forEach((r,i)=>r.onclick=ev=>{
  if(ev.target.classList.contains('sp-line'))return;
  const s=results[i];
  map.setView([s.lat,s.lng],17,{animate:true});
  L.popup({maxWidth:280}).setLatLng([s.lat,s.lng]).setContent(stopPopupHTML(s,stopLines(s),!networkLoaded)).openOn(map);
  if(map3d&&map3dReady)map3d.flyTo({center:[s.lng,s.lat],zoom:17,pitch:62,essential:true});
 });
 bindLineBadges(box);
};

/* ---------- PLÁNOVAČ SPOJENÍ ---------- */
const WALK_SPEED=1.25, DWELL=25, TRANSFER_PENALTY=270;

function buildGraph(linePenalty){
 const pats=plannerPatterns();
 const nodes=new Map();
 const nodeOf=s=>{
  const k=normalizePlannerName(s.name);
  let n=nodes.get(k);
  if(!n){n={key:k,name:clean(s.name),lat:s.lat,lng:s.lng,request:!!s.request,edges:[],lines:new Set()};nodes.set(k,n)}
  if(!Number.isFinite(n.lat)&&Number.isFinite(s.lat)){n.lat=s.lat;n.lng=s.lng}
  return n;
 };
 pats.forEach(p=>{
  const seq=p.stops.map(nodeOf);
  seq.forEach(n=>n.lines.add(p.line));
  const penalty=(linePenalty&&linePenalty.has(p.line))?linePenalty.get(p.line):1;
  for(let i=0;i+1<seq.length;i++){
   const a=seq[i],b=seq[i+1];
   if(a.key===b.key)continue;
   const dist=(Number.isFinite(a.lat)&&Number.isFinite(b.lat))?haversine([a.lat,a.lng],[b.lat,b.lng]):700;
   a.edges.push({to:b.key,line:p.line,dir:p.dir,time:(Math.max(55,dist/7.2)+DWELL)*penalty,dist});
  }
 });
 const arr=[...nodes.values()].filter(n=>Number.isFinite(n.lat));
 for(let i=0;i<arr.length;i++)for(let j=i+1;j<arr.length;j++){
  const d=haversine([arr[i].lat,arr[i].lng],[arr[j].lat,arr[j].lng]);
  if(d<250){
   arr[i].edges.push({to:arr[j].key,line:null,time:d/WALK_SPEED+30,dist:d,walk:true});
   arr[j].edges.push({to:arr[i].key,line:null,time:d/WALK_SPEED+30,dist:d,walk:true});
  }
 }
 return {nodes,pats};
}

function planJourney(origin,dest,linePenalty){
 const {nodes}=buildGraph(linePenalty);
 const list=[...nodes.values()].filter(x=>Number.isFinite(x.lat));
 if(!list.length)return null;
 const near=(pt,n)=>list.map(x=>({node:x,dist:haversine([pt.lat,pt.lng],[x.lat,x.lng])}))
   .sort((a,b)=>a.dist-b.dist).slice(0,n);
 const starts=near(origin,6), ends=near(dest,6);
 const endMap=new Map(ends.map(e=>[e.node.key,e.dist]));
 const best=new Map(), pq=[];
 const push=st=>{pq.push(st);let i=pq.length-1;while(i>0){const p=(i-1)>>1;if(pq[p].cost<=pq[i].cost)break;const t=pq[p];pq[p]=pq[i];pq[i]=t;i=p}};
 const pop=()=>{const top=pq[0],last=pq.pop();if(pq.length){pq[0]=last;let i=0;for(;;){const l=2*i+1,r=l+2>pq.length?-1:2*i+2;let m=i;if(l<pq.length&&pq[l].cost<pq[m].cost)m=l;if(r>0&&r<pq.length&&pq[r].cost<pq[m].cost)m=r;if(m===i)break;const t=pq[m];pq[m]=pq[i];pq[i]=t;i=m}}return top};
 starts.forEach(s=>push({key:s.node.key,line:null,cost:s.dist/WALK_SPEED,prev:null,edge:null,walkIn:s.dist}));
 let goal=null,guard=0;
 while(pq.length&&guard++<300000){
  const st=pop();
  const id=st.key+'|'+(st.line||'-');
  if(best.has(id)&&best.get(id)<=st.cost)continue;
  best.set(id,st.cost);
  if(goal&&st.cost>=goal.total)break;
  if(st.line&&endMap.has(st.key)){
   const total=st.cost+endMap.get(st.key)/WALK_SPEED;
   if(!goal||total<goal.total)goal={state:st,total,walkOut:endMap.get(st.key)};
  }
  const node=nodes.get(st.key); if(!node)continue;
  for(const e of node.edges){
   const penalty=e.walk?TRANSFER_PENALTY*0.6:(st.line===null?60:(e.line!==st.line?TRANSFER_PENALTY:0));
   const cost=st.cost+e.time+penalty;
   if(goal&&cost>=goal.total)continue;
   const nid=e.to+'|'+(e.line||'-');
   if(best.has(nid)&&best.get(nid)<=cost)continue;
   push({key:e.to,line:e.line,dir:e.dir,cost,prev:st,edge:e});
  }
 }
 if(!goal)return null;
 const chain=[]; let cur=goal.state;
 while(cur){chain.unshift(cur);cur=cur.prev}
 const legs=[];
 for(let i=1;i<chain.length;i++){
  const st=chain[i], e=st.edge;
  if(!e)continue;
  const from=nodes.get(chain[i-1].key), to=nodes.get(st.key);
  const last=legs[legs.length-1];
  if(last&&!e.walk&&!last.walk&&last.line===e.line){last.stops.push(to);last.time+=e.time}
  else legs.push({line:e.line,dir:e.dir,walk:!!e.walk,stops:[from,to],time:e.time});
 }
 return {legs,walkIn:chain[0].walkIn||0,walkOut:goal.walkOut,total:goal.total,
         first:legs.length?legs[0].stops[0]:null,last:legs.length?legs[legs.length-1].stops.slice(-1)[0]:null};
}

/* "Podpis" spojení podle použitých linek - k rozlišení odlišných variant */
function planSignature(plan){
 if(!plan)return '';
 return plan.legs.filter(l=>!l.walk).map(l=>l.line).join('>')||'pesky';
}

/* Několik různých variant spojení (ne jen jednu nejlepší) - najdeme nejlepší
   trasu, pak dočasně "prodražíme" použité linky a zkusíme znovu, dokud
   nenajdeme dostatek odlišných variant (jiná kombinace linek). */
function planJourneyVariants(origin,dest,maxVariants){
 maxVariants=maxVariants||3;
 const variants=[]; const seen=new Set(); const penalty=new Map();
 for(let attempt=0;attempt<maxVariants+2&&variants.length<maxVariants;attempt++){
  const plan=planJourney(origin,dest,penalty);
  if(!plan)break;
  const sig=planSignature(plan);
  if(!seen.has(sig)){seen.add(sig);variants.push(plan)}
  const transitLegs=plan.legs.filter(l=>!l.walk);
  if(!transitLegs.length)break;
  transitLegs.forEach(l=>penalty.set(l.line,(penalty.get(l.line)||1)*1.8));
 }
 variants.sort((a,b)=>a.total-b.total);
 return variants;
}

function fmtMin(sec){return Math.max(1,Math.round(sec/60))+' min'}

/* Skrytí/obnovení základní sítě (všechny linky + kolečka zastávek) na mapě,
   když se zobrazuje konkrétní vyhledané spojení - ať je vidět jen trasa
   samotného spojení, ne všechny ostatní linky a zastávky přes ni. */
let searchHidBaseLayers=false;
function hideBaseNetworkForSearch(){
 if(searchHidBaseLayers)return;
 searchHidBaseLayers=true;
 try{Object.values(routeLayers).forEach(g=>{if(map.hasLayer(g))map.removeLayer(g)})}catch(e){}
 try{Object.values(routeHitLayers).forEach(g=>{if(map.hasLayer(g))map.removeLayer(g)})}catch(e){}
 try{if(map.hasLayer(stopMarkers))map.removeLayer(stopMarkers)}catch(e){}
}
function restoreBaseNetworkAfterSearch(){
 if(!searchHidBaseLayers)return;
 searchHidBaseLayers=false;
 try{Object.values(routeLayers).forEach(g=>{if(!map.hasLayer(g))map.addLayer(g)})}catch(e){}
 try{Object.values(routeHitLayers).forEach(g=>{if(!map.hasLayer(g))map.addLayer(g)})}catch(e){}
 try{if(!map.hasLayer(stopMarkers))map.addLayer(stopMarkers)}catch(e){}
}

drawConnection=async function(plan,origin,dest){
 searchRouteLayer.clearLayers();
 if(!plan){restoreBaseNetworkAfterSearch();return}
 hideBaseNetworkForSearch();
 const bounds=L.latLngBounds([]);
 const dot=(ll,html)=>L.marker(ll,{icon:L.divIcon({className:'search-map-marker',html,iconSize:[24,24],iconAnchor:[12,12]}),zIndexOffset:800}).addTo(searchRouteLayer);
 const add=(pts,walking=false,color)=>{
  if(!Array.isArray(pts)||pts.length<2)return false;
  L.polyline(pts,{color:walking?'#2F6F4E':(color||'#C1784F'),weight:walking?4:8,opacity:.96,dashArray:walking?'7 8':null,lineCap:'round',lineJoin:'round'}).addTo(searchRouteLayer);
  pts.forEach(p=>bounds.extend(p));
  return true;
 };
 const stopIcon='<div style="width:15px;height:15px;border-radius:50%;background:#C1784F;border:3px solid #fff;box-shadow:0 1px 7px rgba(0,0,0,.3)"></div>';
 const addStop=s=>{if(s&&Number.isFinite(Number(s.lat))&&Number.isFinite(Number(s.lng))){dot([Number(s.lat),Number(s.lng)],stopIcon);bounds.extend([Number(s.lat),Number(s.lng)])}};
 dot([origin.lat,origin.lng],'<div class="rt-dot a">A</div>');
 dot([dest.lat,dest.lng],'<div class="rt-dot b">B</div>');
 bounds.extend([origin.lat,origin.lng]);bounds.extend([dest.lat,dest.lng]);

 // Všechny pěší úseky se routují po pěší síti. Nikdy se zde nekreslí přímka.
 const walkingBetween=async(a,b)=>{
  if(!a||!b)return false;
  const pts=await roadPath(a,b);
  if(!pts||pts.length<2)throw Error('Nepodařilo se najít pěší trasu mezi body.');
  return add(pts,true);
 };
 const transitBetween=async(leg)=>{
  const from=leg.stops[0],to=leg.stops[leg.stops.length-1];
  const tp=transitPath(leg.line,leg.dir,leg.stops);
  if(!tp||tp.points.length<2)throw Error('Pro linku '+leg.line+' není dostupná přesná trasa mezi zvolenými zastávkami.');
  add(tp.points,false,lineBadgeColor(String(leg.line)));
  leg.stops.forEach(addStop);
 };

 // Trasa začíná pěšky z adresy na skutečně zvolenou nástupní zastávku.
 if(plan.first)await walkingBetween(origin,plan.first);
 for(const leg of plan.legs){
  if(leg.walk){
   const a=leg.stops[0],b=leg.stops[1];
   await walkingBetween(a,b);
   addStop(a);addStop(b);
  }else await transitBetween(leg);
 }
 // A končí pěšky z poslední zastávky na zadanou adresu.
 if(plan.last)await walkingBetween(plan.last,dest);
 if(bounds.isValid())map.fitBounds(bounds,{padding:[80,80],animate:true});
 try{push3dSearchRoute()}catch(e){}
};

let activeConnectionVariants=[], activeConnectionIndex=0, activeConnectionOrigin=null, activeConnectionDest=null;

function estimateVariantMinutes(plan){
 return Math.max(1,Math.round((plan.total||0)/60));
}

function connectionDetailHTML(plan,origin,dest){
 if(!plan){
  return '<div class="connection-result"><div class="connection-summary"><strong>Spojení se nepodařilo sestavit.</strong><div class="search-hint">Zkuste zadat přesnější adresu nebo použijte IDOS.</div></div><a class="idos-button" target="_blank" rel="noopener" href="'+idosUrl()+'"><i class="fa-solid fa-arrow-up-right-from-square"></i> Otevřít IDOS</a></div>';
 }
 const transitLegs=plan.legs.filter(l=>!l.walk);
 const transfers=Math.max(0,transitLegs.length-1);
 let html='<div class="connection-result"><div class="connection-summary"><strong>'+esc(origin.label||'Odkud')+' → '+esc(dest.label||'Kam')+'</strong>'+
  '<div class="conn-facts"><span><i class="fa-regular fa-clock"></i> ~'+fmtMin(plan.total)+'</span><span><i class="fa-solid fa-shuffle"></i> '+(transfers?transfers+'× přestup':'bez přestupu')+'</span><span><i class="fa-solid fa-person-walking"></i> '+formatDistance(Math.round((plan.walkIn||0)+(plan.walkOut||0)))+'</span></div>'+
  '<div class="search-hint">Orientační výpočet ze statických dat sítě. Časy odjezdů ověřte v IDOS nebo v tabuli odjezdů (mpvnet.cz).</div></div>';
 html+='<div class="conn-step"><i class="fa-solid fa-person-walking"></i><div><strong>Pěšky '+formatDistance(Math.round(plan.walkIn||0))+'</strong><div class="conn-sub">na zastávku '+esc(plan.first?plan.first.name:'')+'</div></div></div>';
 plan.legs.forEach(leg=>{
  if(leg.walk){
   const d=(Number.isFinite(leg.stops[0].lat)&&Number.isFinite(leg.stops[1].lat))?haversine([leg.stops[0].lat,leg.stops[0].lng],[leg.stops[1].lat,leg.stops[1].lng]):0;
   html+='<div class="conn-step"><i class="fa-solid fa-person-walking-arrow-right"></i><div><strong>Přejít '+formatDistance(Math.round(d))+'</strong><div class="conn-sub">'+esc(leg.stops[0].name)+' → '+esc(leg.stops[1].name)+'</div></div></div>';
   return;
  }
  const st=leg.stops;
  const lineColor=lineBadgeColor(String(leg.line));
  html+='<div class="connection-leg"><div class="leg-top"><span class="leg-line" style="background:'+lineColor+'">'+esc(leg.line)+'</span>'+
   '<span class="leg-text">'+esc(st[0].name)+' → '+esc(st[st.length-1].name)+'</span>'+
   '<span class="leg-time">'+fmtMin(leg.time)+' · '+(st.length-1)+' zast.</span></div>'+
   '<div class="leg-stops">'+st.map(s=>esc(s.name)+(s.request?' <i class="fa-solid fa-thumbs-up sp-req-ico"></i>':'')).join(' → ')+'</div>'+
   '<button class="leg-departures-btn" data-stop="'+esc(st[0].name)+'"><i class="fa-solid fa-clock"></i> 2 nejbližší odjezdy · mpvnet.cz</button>'+
   '</div>';
 });
 html+='<div class="conn-step"><i class="fa-solid fa-flag-checkered"></i><div><strong>Pěšky '+formatDistance(Math.round(plan.walkOut||0))+'</strong><div class="conn-sub">ze zastávky '+esc(plan.last?plan.last.name:'')+' do cíle</div></div></div>';
 html+='<a class="idos-button" target="_blank" rel="noopener" href="'+idosUrl()+'"><i class="fa-solid fa-clock"></i> Otevřít v IDOS – skutečné časy</a></div>';
 return html;
}
function bindDeparturesButtons(host){
 host.querySelectorAll('.leg-departures-btn').forEach(btn=>{
  btn.addEventListener('click',()=>{try{if(typeof openDeparturesPanel==='function')openDeparturesPanel(btn.dataset.stop)}catch(e){}});
 });
}

renderConnection=function(plan,origin,dest){
 const box=document.getElementById('connection-results');
 box.innerHTML=connectionDetailHTML(plan,origin,dest);
 bindDeparturesButtons(box);
};

/* Seznam více nalezených variant spojení (ne jen jedno nejlepší) nad detailem
   vybrané varianty - kliknutím na kartu se přepne zvýrazněná trasa na mapě. */
function renderConnectionVariants(variants,origin,dest){
 activeConnectionVariants=variants||[];
 activeConnectionOrigin=origin; activeConnectionDest=dest;
 activeConnectionIndex=0;
 const box=document.getElementById('connection-results');
 if(!activeConnectionVariants.length){
  renderConnection(null,origin,dest);
  return;
 }
 let html='';
 if(activeConnectionVariants.length>1){
  html+='<div class="connection-variants">';
  activeConnectionVariants.forEach((plan,i)=>{
   const lines=plan.legs.filter(l=>!l.walk).map(l=>l.line);
   const badges=lines.length?lines.map(l=>'<span class="variant-line-badge" style="background:'+lineBadgeColor(String(l))+'">'+esc(l)+'</span>').join('<i class="fa-solid fa-chevron-right variant-arrow"></i>'):'<span class="variant-line-badge walk"><i class="fa-solid fa-person-walking"></i></span>';
   const transfers=Math.max(0,lines.length-1);
   html+='<button class="connection-variant'+(i===0?' active':'')+'" data-vi="'+i+'"><div class="variant-badges">'+badges+'</div><div class="variant-meta">'+(transfers?transfers+'× přestup':(lines.length?'přímé spojení':'pěší trasa'))+' · ~'+estimateVariantMinutes(plan)+' min</div></button>';
  });
  html+='</div>';
 }
 html+='<div id="connection-variant-detail">'+connectionDetailHTML(activeConnectionVariants[0],origin,dest)+'</div>';
 box.innerHTML=html;
 box.querySelectorAll('.connection-variant').forEach(btn=>{
  btn.addEventListener('click',()=>selectConnectionVariant(Number(btn.dataset.vi)));
 });
 bindDeparturesButtons(document.getElementById('connection-variant-detail'));
}
async function selectConnectionVariant(i){
 if(!activeConnectionVariants[i])return;
 activeConnectionIndex=i;
 document.querySelectorAll('.connection-variant').forEach(b=>b.classList.toggle('active',Number(b.dataset.vi)===i));
 const host=document.getElementById('connection-variant-detail');
 host.innerHTML=connectionDetailHTML(activeConnectionVariants[i],activeConnectionOrigin,activeConnectionDest);
 bindDeparturesButtons(host);
 await drawConnection(activeConnectionVariants[i],activeConnectionOrigin,activeConnectionDest);
}

runConnectionSearch=async function(){
 try{
  setSearchStatus('connection-status','Hledám spojení…');
  document.getElementById('connection-results').innerHTML='';
  const [origin,dest]=await Promise.all([locationFromInput('from-address'),locationFromInput('to-address')]);
  await loadPlannerStops();
  try{await loadGTFS()}catch(e){}
  const variants=planJourneyVariants(origin,dest,3);
  const plan=variants.length?variants[0]:null;
  clearHighlights();
  highlightAddress({lat:origin.lat,lng:origin.lng,label:origin.label});
  highlightAddress({lat:dest.lat,lng:dest.lng,label:dest.label});
  await drawConnection(plan,origin,dest);
  renderConnectionVariants(variants,origin,dest);
  if(plan){
   const transfers=Math.max(0,plan.legs.filter(l=>!l.walk).length-1);
   setSearchStatus('connection-status',(variants.length>1?('Nalezeno '+variants.length+' variant spojení · '):'')+(transfers?('Spojení s '+transfers+'× přestupem'):'Přímé spojení')+' · ~'+fmtMin(plan.total));
  }else setSearchStatus('connection-status','Spojení nebylo nalezeno.',true);
 }catch(e){setSearchStatus('connection-status',e.message||'Spojení se nepodařilo vyhledat.',true)}
};

const _show3D3=show3D;
show3D=function(){_show3D3();setTimeout(()=>{push3dHighlight();startFleet();apply3dBasemap();},500)};

const _theme3=theme;
theme=function(dark,notify=true){
 _theme3(dark,notify);
 try{
  if(map3d){
   apply3dBasemap();
   if(map3d.getLayer('add-3d-buildings'))map3d.setPaintProperty('add-3d-buildings','fill-extrusion-color',dark?'#3a3734':'#b8b0a8');
  }
 }catch(e){}
};


document.querySelectorAll('[data-map-vehicle]').forEach(btn=>{
  btn.addEventListener('click',()=>{
    const id=btn.dataset.mapVehicle;
    window.__preferredVehicleType=id;
    setGarage(false);
    show3D();
    setTimeout(()=>{
      try{
        if(window.__fleetReset) window.__fleetReset();
      }catch(e){console.warn('[garage] vehicle selection',e)}
    },700);
  });
});

window.MHD3D={fleet:()=>fleet,plan:planJourney,buildFleet,VEHICLE_TYPES};

loadOfficialStops().then(()=>{try{renderOfficialStopMarkers()}catch(e){}}).catch(()=>{});

/* ---------- 3D MAPA: denní doba a počasí (Mapbox lightPreset / rain / snow) ---------- */
(function(){
 const panel=document.getElementById('fx3d-control');
 const TIME_BTNS={dawn:'fx-time-dawn',day:'fx-time-day',dusk:'fx-time-dusk',night:'fx-time-night'};
 const WEATHER_BTNS={none:'fx-weather-none',rain:'fx-weather-rain',snow:'fx-weather-snow'};
 function setActive(map,active){Object.entries(map).forEach(([k,id])=>{const el=document.getElementById(id);if(el)el.classList.toggle('fx-active',k===active)})}
 function setLightPreset(preset){if(!map3d)return;try{map3d.setConfigProperty?.('basemap','lightPreset',preset)}catch(e){}setActive(TIME_BTNS,preset)}
 window.__fx3dSetTime=setLightPreset;
 function applyWeather(w){
  if(!map3d)return;
  try{
   if(w==='rain'){
    map3d.setSnow?.(null);
    map3d.setRain?.({density:0.5,intensity:1.0,color:'#a8adbc',opacity:0.7,vignette:0.35,'vignette-color':'#464646',direction:[0,80],'droplet-size':[2.6,18.2],'distortion-strength':0.7,'center-thinning':0});
   }else if(w==='snow'){
    map3d.setRain?.(null);
    map3d.setSnow?.({density:0.85,intensity:1.0,'center-thinning':0.1,direction:[0,50],opacity:1.0,color:'#ffffff','flake-size':0.71,vignette:0.3,'vignette-color':'#ffffff'});
   }else{
    map3d.setRain?.(null);
    map3d.setSnow?.(null);
   }
  }catch(e){console.warn('[fx3d weather]',e)}
  setActive(WEATHER_BTNS,w);
 }
 Object.entries(TIME_BTNS).forEach(([k,id])=>document.getElementById(id)?.addEventListener('click',()=>{setLightPreset(k);if(k==='day'&&document.body.classList.contains('dark'))theme(false);else if(k==='night'&&!document.body.classList.contains('dark'))theme(true);}));
 Object.entries(WEATHER_BTNS).forEach(([k,id])=>document.getElementById(id)?.addEventListener('click',()=>applyWeather(k)));
 setActive(TIME_BTNS,document.body.classList.contains('dark')?'night':'day');setActive(WEATHER_BTNS,'none');
 /* zobrazit/skrýt panel podle aktuálního režimu mapy (2D/3D) */
 document.getElementById('btn-model-3d')?.addEventListener('click',()=>{if(panel)panel.style.display='flex'});
 document.getElementById('btn-map-2d')?.addEventListener('click',()=>{if(panel)panel.style.display='none'});
})();
})();

