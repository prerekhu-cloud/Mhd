
(function(){
 'use strict';
 const shell=document.querySelector('.map-shell'), map3=document.getElementById('mapbox3d');
 if(!shell||!map3)return;
 const fx=document.getElementById('fx3d-control'), rideStart=document.getElementById('ride-start');
 if(fx&&rideStart)fx.appendChild(rideStart);
 document.querySelector('.map-shell > div.absolute.bottom-1.right-4')?.remove();
 let info=document.getElementById('complete-map-info');
 if(!info){info=document.createElement('div');info.id='complete-map-info';info.innerHTML='<div class="complete-clock" aria-label="Aktuální čas">--:--:--</div><div class="complete-scale"><span class="complete-scale-label">100 m</span><span class="complete-scale-bar"></span></div>';shell.appendChild(info)}
 const clock=info.querySelector('.complete-clock'), label=info.querySelector('.complete-scale-label'), bar=info.querySelector('.complete-scale-bar');
 function updateInfo(){
  if(clock)clock.textContent=new Intl.DateTimeFormat('cs-CZ',{hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false}).format(new Date());
  const z=(window.is3D&&is3D()&&window.map3d)?map3.getZoom():(window.map?map.getZoom():13);
  const metres=Math.max(20,Math.round(100*Math.pow(2,16-z)/10)*10);
  if(label)label.textContent=metres>=1000?(metres/1000).toLocaleString('cs-CZ')+' km':metres+' m';
  if(bar)bar.style.width=Math.max(42,Math.min(140,100*Math.pow(2,z-16)))+'px';
 }
 setInterval(updateInfo,1000);updateInfo();
 let tools=document.getElementById('map3d-tools');
 if(!tools){tools=document.createElement('div');tools.id='map3d-tools';tools.innerHTML='<div id="map3d-camera-joystick" title="Otáčet pohledem o 360°" aria-label="Joystick kamery"><span id="map3d-camera-knob"></span></div><div id="map3d-zoom"><button type="button" data-z="1" aria-label="Přiblížit">+</button><button type="button" data-z="-1" aria-label="Oddálit">−</button></div>';shell.appendChild(tools)}
 function refreshMode(){shell.classList.toggle('is-3d',!map3.classList.contains('hidden'));updateInfo()}
 new MutationObserver(refreshMode).observe(map3,{attributes:true,attributeFilter:['class']});refreshMode();
 tools.querySelectorAll('[data-z]').forEach(b=>b.addEventListener('click',()=>{if(window.map3d){map3.zoomTo(map3.getZoom()+Number(b.dataset.z),{duration:220});updateInfo()}}));
 const joy3=tools.querySelector('#map3d-camera-joystick'), knob3=tools.querySelector('#map3d-camera-knob');let pid=null;
 function move(e){if(pid!==e.pointerId||!window.map3d)return;const r=joy3.getBoundingClientRect(),dx=e.clientX-(r.left+r.width/2),dy=e.clientY-(r.top+r.height/2),max=r.width*.28,k=Math.min(1,max/(Math.hypot(dx,dy)||1));knob3.style.transform='translate('+dx*k+'px,'+dy*k+'px)';map3.setBearing((map3.getBearing()+dx*.7+360)%360);map3.setPitch(Math.max(25,Math.min(82,map3.getPitch()-dy*.35)))}
 joy3.addEventListener('pointerdown',e=>{pid=e.pointerId;joy3.setPointerCapture(pid);move(e);e.preventDefault()});joy3.addEventListener('pointermove',move);['pointerup','pointercancel'].forEach(t=>joy3.addEventListener(t,e=>{if(pid===e.pointerId){pid=null;knob3.style.transform='translate(0,0)'}}));
 if(typeof window.vehiclePose==='function'&&!window.__globalSpeedPatch){const basePose=window.vehiclePose;window.vehiclePose=function(v,now){if(typeof rideActive!=='undefined'&&rideActive&&typeof rideSpeedMultiplier==='number'&&rideSpeedMultiplier===2){const s=v.speed;v.speed=s*2;try{return basePose(v,now)}finally{v.speed=s}}return basePose(v,now)};window.__globalSpeedPatch=true}
 const badge=document.getElementById('complete-vehicle-badge');
 if(badge&&!badge.__exactRidePatch){window.rideSelected=async function(v){if(!v)return;const old=busVehicles,start=Number(v.distance)||0;busVehicles=[v];try{if(typeof window.startRide==='function')await window.startRide();if(typeof rideBus!=='undefined'&&rideBus){rideBus.distance=Math.min(start,Math.max(0,rideBus.length-1));rideBus.currentStopIndex=Math.max(1,(rideBus._stopsWithDist||[]).findIndex(s=>Number(s.dist)>rideBus.distance));rideBus._poseLastT=performance.now();window.renderRideStopTable?.(true)}}finally{busVehicles=old}};badge.__exactRidePatch=true}
 const rec=document.getElementById('btn-recenter');if(rec&&!rec.__finalPatch){rec.__finalPatch=true;rec.addEventListener('click',e=>{if(typeof rideActive!=='undefined'&&rideActive&&typeof rideBus!=='undefined'&&rideBus?.lngLat&&window.map3d){e.stopImmediatePropagation();window.rideFollow=true;map3.easeTo({center:rideBus.lngLat,bearing:Number(rideBus.bearing)||0,zoom:19.35,pitch:69,duration:450})}},true)}
})();
