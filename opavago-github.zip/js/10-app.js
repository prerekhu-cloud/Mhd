
/* ---------- JÍZDA VOZIDLEM: ovládání panelu, zvuk, sledování kamery, zkratky na denní dobu/počasí ---------- */
(function(){
 let rideSoundOn=false;
 window.rideSoundOn=rideSoundOn;
 let __rideAudioCtx=null;
 window.playStopChime=function(){
  if(!window.rideSoundOn)return;
  try{
   __rideAudioCtx=__rideAudioCtx||new (window.AudioContext||window.webkitAudioContext)();
   const ctx=__rideAudioCtx;
   const o=ctx.createOscillator();const g=ctx.createGain();
   o.type='sine';o.frequency.setValueAtTime(880,ctx.currentTime);
   o.frequency.exponentialRampToValueAtTime(660,ctx.currentTime+0.18);
   g.gain.setValueAtTime(0.0001,ctx.currentTime);
   g.gain.exponentialRampToValueAtTime(0.18,ctx.currentTime+0.02);
   g.gain.exponentialRampToValueAtTime(0.0001,ctx.currentTime+0.32);
   o.connect(g);g.connect(ctx.destination);
   o.start();o.stop(ctx.currentTime+0.34);
  }catch(e){}
 };

 const startBtn=document.getElementById('ride-start-btn');
 const endBtn=document.getElementById('ride-end');
 const restartBtn=document.getElementById('ride-restart');
 const collapseBtn=document.getElementById('ride-collapse');
 const soundBtn=document.getElementById('ride-sound');
 const timeBtn=document.getElementById('ride-time-toggle');
 const weatherBtn=document.getElementById('ride-weather-toggle');
 const followBtn=document.getElementById('ride-follow');
 const panel=document.getElementById('ride-panel');

 startBtn?.addEventListener('click',()=>{ if(typeof startRide==='function') startRide(); });
 endBtn?.addEventListener('click',()=>{ if(typeof endRide==='function') endRide(); });
 restartBtn?.addEventListener('click',()=>{
  if(typeof endRide==='function') endRide();
  setTimeout(()=>{ if(typeof startRide==='function') startRide(); },80);
 });
 collapseBtn?.addEventListener('click',()=>{
  panel?.classList.toggle('collapsed');
  collapseBtn.classList.toggle('rotated');
 });
 soundBtn?.addEventListener('click',()=>{
  window.rideSoundOn=!window.rideSoundOn;
  soundBtn.classList.toggle('active',window.rideSoundOn);
  const icon=soundBtn.querySelector('i');
  if(icon){ icon.className = window.rideSoundOn?'fa-solid fa-volume-high':'fa-solid fa-volume-xmark'; }
  if(window.rideSoundOn) window.playStopChime();
 });
 followBtn?.addEventListener('click',()=>{
  try{ rideFollow=!rideFollow; followBtn.classList.toggle('active',rideFollow); }catch(e){}
 });
 // výchozí stav: sledování kamery je od začátku zapnuté (viz startRide -> rideFollow=true)
 followBtn?.classList.add('active');

 const TIME_ORDER=['dawn','day','dusk','night'];
 const WEATHER_ORDER=['none','rain','snow'];
 timeBtn?.addEventListener('click',()=>{
  const active=TIME_ORDER.find(k=>document.getElementById('fx-time-'+k)?.classList.contains('fx-active'))||'day';
  const next=TIME_ORDER[(TIME_ORDER.indexOf(active)+1)%TIME_ORDER.length];
  document.getElementById('fx-time-'+next)?.click();
 });
 weatherBtn?.addEventListener('click',()=>{
  const active=WEATHER_ORDER.find(k=>document.getElementById('fx-weather-'+k)?.classList.contains('fx-active'))||'none';
  const next=WEATHER_ORDER[(WEATHER_ORDER.indexOf(active)+1)%WEATHER_ORDER.length];
  document.getElementById('fx-weather-'+next)?.click();
 });
})();
