
(function(){
 const regioNorm=value=>String(value||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\s+/g,' ').trim();
 const REGIO_BY_LINE=Object.fromEntries((window.MHD_REGIO_LINES||[]).map(line=>[String(line.num),line]));
 const REGIO_LINE_NUMBERS=(window.MHD_REGIO_LINES||[]).map(line=>String(line.num));
 const REGIO_STOP_LOOKUP=new Map();(window.MHD_REGIO_STOPS||[]).forEach((stop,index)=>{const name=String(stop.name||'').replace(/\s*\([^)]*\)\s*$/,'').trim(),key=regioNorm(name);if(!REGIO_STOP_LOOKUP.has(key))REGIO_STOP_LOOKUP.set(key,{key:'regio-'+index,name,lat:Number(stop.lat),lng:Number(stop.lon),request:!!stop.requestStop,regional:true})});
 const REGIO_BUS_IMAGE='img/ed5ffdcbb7.png';
 let regioMode=false;
 const btn=document.getElementById('btn-r');
 if(!btn)return;
 btn.title='Regio linky';btn.setAttribute('aria-label','Regio linky');
 const cityLines=()=>Object.keys(routeLayers).filter(line=>!REGIO_BY_LINE[String(line)]);
 const regioLines=()=>REGIO_LINE_NUMBERS.filter(line=>routeLayers[line]);
 function syncRegio3D(){
  try{const source=map3d?.getSource('stops-3d');if(source)source.setData(geojsonStops());
   const routeFilter=regioMode?['in',['get','line'],['literal',REGIO_LINE_NUMBERS]]:['!', ['in',['get','line'],['literal',REGIO_LINE_NUMBERS]]];
   if(map3d?.getLayer('routes-3d-line'))map3d.setFilter('routes-3d-line',routeFilter);
   if(map3d?.getLayer('routes-3d-hit'))map3d.setFilter('routes-3d-hit',routeFilter);
   const stopFilter=regioMode?['==',['get','regional'],1]:['!=',['get','regional'],1];
   if(map3d?.getLayer('stops-3d'))map3d.setFilter('stops-3d',stopFilter);
   if(map3d?.getLayer('stops-3d-label'))map3d.setFilter('stops-3d-label',stopFilter);
  }catch(_){}
 }
 const baseGeojsonStops=geojsonStops;
 geojsonStops=function(){const data=baseGeojsonStops();const seen=new Set(data.features.map(f=>regioNorm(f.properties?.name||'')));for(const stop of REGIO_STOP_LOOKUP.values()){const key=regioNorm(stop.name);if(seen.has(key)||!Number.isFinite(stop.lat)||!Number.isFinite(stop.lng))continue;seen.add(key);data.features.push({type:'Feature',properties:{name:stop.name,direction:'Regio',request:stop.request?1:0,regional:1},geometry:{type:'Point',coordinates:[stop.lng,stop.lat]}})}data.features.forEach(f=>{if(f.properties.regional!==1)f.properties.regional=0});return data};
 function paintRows(){document.querySelectorAll('.network-item.regio').forEach(item=>{const thumb=item.querySelector('.route-thumb');if(thumb)thumb.innerHTML='<img src="'+REGIO_BUS_IMAGE+'" alt="Regionální autobus">';const destination=item.querySelector('.route-destination');if(destination&&!destination.querySelector('.regio-badge'))destination.insertAdjacentHTML('beforeend','<span class="regio-badge">REGIO</span>')})}
 const baseRenderNetwork=renderNetwork;
 renderNetwork=window.renderNetwork=function(){baseRenderNetwork();paintRows();if(regioMode){document.querySelectorAll('.network-item:not(.regio),.network-cat-head,.network-regio-note').forEach(el=>{if(el.classList.contains('network-cat-head')&&el.textContent.includes('Regio'))return;if(el.classList.contains('network-regio-note'))return;el.style.display='none'});const regioHead=[...document.querySelectorAll('.network-cat-head')].find(el=>el.textContent.includes('Regio'));if(regioHead)regioHead.style.display='flex'}};
 function setRegioMode(active){regioMode=active;btn.classList.toggle('regio-active',active);btn.setAttribute('aria-pressed',String(active));
  for(const line of cityLines()){const layer=routeLayers[line],hit=routeHitLayers[line];if(active){if(map.hasLayer(layer))map.removeLayer(layer);if(map.hasLayer(hit))map.removeLayer(hit)}else{if(!map.hasLayer(layer))layer.addTo(map);if(!map.hasLayer(hit))hit.addTo(map)}}
  for(const line of regioLines()){const layer=routeLayers[line],hit=routeHitLayers[line];if(active){if(!map.hasLayer(layer))layer.addTo(map);if(!map.hasLayer(hit))hit.addTo(map)}else{if(map.hasLayer(layer))map.removeLayer(layer);if(map.hasLayer(hit))map.removeLayer(hit)}}
  if(window.regioStopLayer){if(active&&!map.hasLayer(window.regioStopLayer))window.regioStopLayer.addTo(map);if(!active&&map.hasLayer(window.regioStopLayer))map.removeLayer(window.regioStopLayer)}
  const panel=document.getElementById('network-panel');if(active){panel.classList.add('open');document.body.classList.add('network-open');renderNetwork()}else{panel.classList.remove('open');document.body.classList.remove('network-open');map.setView(OPAVA_CENTER,13,{animate:true})}
  resizeMapsAfterPanel();syncRegio3D();
 }
 btn.onclick=()=>setRegioMode(!regioMode);
 const baseToggleNetwork=toggleNetworkPanel;toggleNetworkPanel=function(){if(regioMode){setRegioMode(false);return}baseToggleNetwork()};
 document.getElementById('network-close').onclick=()=>{if(regioMode)setRegioMode(false);else toggleNetworkPanel()};
 for(const line of regioLines()){if(map.hasLayer(routeLayers[line]))map.removeLayer(routeLayers[line]);if(map.hasLayer(routeHitLayers[line]))map.removeLayer(routeHitLayers[line])}
 if(window.regioStopLayer&&map.hasLayer(window.regioStopLayer))map.removeLayer(window.regioStopLayer);
 document.getElementById('ride-collapse')?.remove();
 window.addEventListener('resize',()=>{if(rideActive&&rideBus)renderRideStopTable(true)});
 map.setView(OPAVA_CENTER,13,{animate:false});syncRegio3D();
})();
