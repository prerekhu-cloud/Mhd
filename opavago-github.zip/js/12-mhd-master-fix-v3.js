
(function(){
'use strict';

const OPAVA_STOPS = {"kylesovice, bilovecka": {"name": "Kylešovice, Bílovecká", "lat": 49.921404, "lng": 17.907091}, "kylesovice, vanickova": {"name": "Kylešovice, Vaníčkova", "lat": 49.927398, "lng": 17.906105}, "stadion": {"name": "Stadion", "lat": 49.928065, "lng": 17.910234}, "vychodni nadrazi": {"name": "Východní nádraží", "lat": 49.932101, "lng": 17.909637}, "praskova": {"name": "Praskova", "lat": 49.936278, "lng": 17.906194}, "dolni namesti": {"name": "Dolní náměstí", "lat": 49.936893, "lng": 17.904346}, "divadlo": {"name": "Divadlo", "lat": 49.935625, "lng": 17.897899}, "u soudu": {"name": "U soudu", "lat": 49.932673, "lng": 17.89217}, "horovo namesti": {"name": "Horovo náměstí", "lat": 49.931276, "lng": 17.891962}, "nemocnice": {"name": "Nemocnice", "lat": 49.930744, "lng": 17.887088}, "zem. tech. skola": {"name": "Zem. tech. škola", "lat": 49.926325, "lng": 17.891778}, "mestsky hrbitov": {"name": "Městský hřbitov", "lat": 49.927132, "lng": 17.883903}, "purkynova": {"name": "Purkyňova", "lat": 49.933611, "lng": 17.880212}, "albert hypermarket": {"name": "Albert hypermarket", "lat": 49.927124, "lng": 17.888353}, "holasicka": {"name": "Holasická", "lat": 49.940494, "lng": 17.907583}, "ratiborska": {"name": "Ratibořská", "lat": 49.94343, "lng": 17.916477}, "svedska kaple": {"name": "Švédská kaple", "lat": 49.9429, "lng": 17.921626}, "katerinky": {"name": "Kateřinky", "lat": 49.943904, "lng": 17.92238}, "male hostice, rest.": {"name": "Malé Hoštice, rest.", "lat": 49.942946, "lng": 17.931959}, "male hostice": {"name": "Malé Hoštice", "lat": 49.940914, "lng": 17.934833}, "psychiatricka lecebna": {"name": "Psychiatrická léčebna", "lat": 49.927723, "lng": 17.886427}, "globus": {"name": "Globus", "lat": 49.932911, "lng": 17.923166}, "ostroj": {"name": "Ostroj", "lat": 49.93284, "lng": 17.922756}, "jatky": {"name": "Jatky", "lat": 49.933444, "lng": 17.920573}, "tesinska": {"name": "Těšínská", "lat": 49.934925, "lng": 17.914455}, "anenska": {"name": "Anenská", "lat": 49.936672, "lng": 17.908734}, "zimni stadion": {"name": "Zimní stadion", "lat": 49.939226, "lng": 17.901834}, "sme": {"name": "SME", "lat": 49.93622, "lng": 17.891638}, "stara silnice": {"name": "Stará silnice", "lat": 49.93747, "lng": 17.888939}, "sedenkova": {"name": "Šeděnkova", "lat": 49.942244, "lng": 17.896686}, "jaktar, u jaktarky": {"name": "Jaktař, U Jaktarky", "lat": 49.94354, "lng": 17.893244}, "jaktar": {"name": "Jaktař", "lat": 49.943686, "lng": 17.892356}, "papirny": {"name": "Papírny", "lat": 49.93245, "lng": 17.922726}, "kylesovice, skola": {"name": "Kylešovice, škola", "lat": 49.924432, "lng": 17.915255}, "kylesovice, hlavni": {"name": "Kylešovice, Hlavní", "lat": 49.927587, "lng": 17.908071}, "vrchni": {"name": "Vrchní", "lat": 49.944261, "lng": 17.915416}, "u cukrovaru": {"name": "U Cukrovaru", "lat": 49.937386, "lng": 17.908698}, "pekarska": {"name": "Pekařská", "lat": 49.937072, "lng": 17.90641}, "englisova": {"name": "Englišova", "lat": 49.91896, "lng": 17.916221}, "dostojevskeho": {"name": "Dostojevského", "lat": 49.919041, "lng": 17.911086}, "komarov, oasa": {"name": "Komárov, Oasa", "lat": 49.923307, "lng": 17.948038}, "komarov, balakom": {"name": "Komárov, Balakom", "lat": 49.918171, "lng": 17.958227}, "komarov, telocvicna": {"name": "Komárov, tělocvična", "lat": 49.906799, "lng": 17.963164}, "komarov, podvihovska": {"name": "Komárov, Podvihovská", "lat": 49.887737, "lng": 17.968888}, "komarov, drub.zav.": {"name": "Komárov, Drůb.záv.", "lat": 49.882279, "lng": 17.96795}, "podvihov, kom.chal.": {"name": "Podvihov, Kom.Chal.", "lat": 49.878962, "lng": 17.968641}, "podvihov, hostinec": {"name": "Podvihov, hostinec", "lat": 49.877205, "lng": 17.973176}, "podvihov, na nove": {"name": "Podvihov, Na Nové", "lat": 49.871253, "lng": 17.968359}, "komarov, stred": {"name": "Komárov, střed", "lat": 49.911859, "lng": 17.968013}, "komarov, komas": {"name": "Komárov, Komas", "lat": 49.917769, "lng": 17.962317}, "jaktar, skola": {"name": "Jaktař, škola", "lat": 49.947103, "lng": 17.859626}, "jaktar, sts": {"name": "Jaktař, STS", "lat": 49.945329, "lng": 17.842738}, "zlatniky, stred": {"name": "Zlatníky, střed", "lat": 49.943407, "lng": 17.829811}, "milostovice, 6.kvetna": {"name": "Milostovice, 6.května", "lat": 49.949207, "lng": 17.830448}, "milostovice": {"name": "Milostovice", "lat": 49.956935, "lng": 17.832664}, "vlastovicky, luzni": {"name": "Vlaštovičky, Lužní", "lat": 49.964502, "lng": 17.827283}, "vlastovicky": {"name": "Vlaštovičky", "lat": 49.968833, "lng": 17.827035}, "zlatniky": {"name": "Zlatníky", "lat": 49.942444, "lng": 17.829268}, "vavrovice, karlovec": {"name": "Vávrovice, Karlovec", "lat": 49.913379, "lng": 17.918066}, "katerinky, stribrne jezero": {"name": "Kateřinky, Stříbrné jezero", "lat": 49.918078, "lng": 17.911392}, "dobrovskeho": {"name": "Dobrovského", "lat": 49.936022, "lng": 17.90688}, "rolnicka": {"name": "Rolnická", "lat": 49.936729, "lng": 17.906771}, "partyzanska": {"name": "Partyzánská", "lat": 49.936345, "lng": 17.908079}, "olbrichova": {"name": "Olbrichova", "lat": 49.939036, "lng": 17.905431}, "rooseveltova": {"name": "Rooseveltova", "lat": 49.933537, "lng": 17.906301}, "zukalova": {"name": "Zukalova", "lat": 49.942493, "lng": 17.908693}, "bartonickova": {"name": "Bartoníčkova", "lat": 49.94584, "lng": 17.906231}, "kylesovsky kopec": {"name": "Kylešovský kopec", "lat": 49.949585, "lng": 17.903249}, "kylesovice, gudrichova": {"name": "Kylešovice, Gudrichova", "lat": 49.952872, "lng": 17.895747}, "kylesovice, kroftova": {"name": "Kylešovice, Kroftova", "lat": 49.956507, "lng": 17.885165}, "kylesovice, sus": {"name": "Kylešovice, SÚS", "lat": 49.929716, "lng": 17.906779}, "komarov, teva 2": {"name": "Komárov, TEVA 2", "lat": 49.917105, "lng": 17.973791}, "liliova": {"name": "Liliová", "lat": 49.937414, "lng": 17.881756}, "slunecni": {"name": "Sluneční", "lat": 49.942946, "lng": 17.881972}, "vancurova": {"name": "Vančurova", "lat": 49.944004, "lng": 17.890416}, "prokopa holeho": {"name": "Prokopa Holého", "lat": 49.942342, "lng": 17.893955}, "hradecka": {"name": "Hradecká", "lat": 49.917624, "lng": 17.904106}, "hobzikova": {"name": "Hobzíkova", "lat": 49.918819, "lng": 17.915223}, "vaskovo namesti": {"name": "Vaškovo náměstí", "lat": 49.926208, "lng": 17.907313}, "kylesovice, hrbitov": {"name": "Kylešovice, hřbitov", "lat": 49.920108, "lng": 17.92351}, "kylesovice, bavaria": {"name": "Kylešovice, Bavaria", "lat": 49.921223, "lng": 17.935949}, "kylesovice, na dolni hrazi": {"name": "Kylešovice, Na Dolní hrázi", "lat": 49.922763, "lng": 17.939235}, "kylesovice, obalovna": {"name": "Kylešovice, obalovna", "lat": 49.925162, "lng": 17.940192}, "serikova": {"name": "Šeříková", "lat": 49.944709, "lng": 17.882933}, "vavrovice, drzkovice": {"name": "Vávrovice, Držkovice", "lat": 49.985199, "lng": 17.844916}, "vavrovice, skola": {"name": "Vávrovice, škola", "lat": 49.980518, "lng": 17.853459}, "vavrovice, opavia": {"name": "Vávrovice, OPAVIA", "lat": 49.979166, "lng": 17.859518}, "vavrovice, dum sluzeb": {"name": "Vávrovice, dům služeb", "lat": 49.975544, "lng": 17.858548}, "vavrovice, sokolovna": {"name": "Vávrovice, sokolovna", "lat": 49.976067, "lng": 17.860111}, "vavrovice, femont": {"name": "Vávrovice, Femont", "lat": 49.974507, "lng": 17.864801}, "vavrovice, cukrovar": {"name": "Vávrovice, Cukrovar", "lat": 49.967678, "lng": 17.865689}, "vavrovice, palhanec kaple": {"name": "Vávrovice, Palhanec kaple", "lat": 49.962936, "lng": 17.870519}, "jaktar, mrazirny": {"name": "Jaktař, mrazírny", "lat": 49.959914, "lng": 17.873842}, "jaktar, palhanecka": {"name": "Jaktař, Palhanecká", "lat": 49.956232, "lng": 17.875737}, "slavkov": {"name": "Slavkov", "lat": 49.929338, "lng": 17.854492}, "slavkov, u arealu": {"name": "Slavkov, u areálu", "lat": 49.928864, "lng": 17.858279}, "slavkov, cerna cesta": {"name": "Slavkov, Černá cesta", "lat": 49.927663, "lng": 17.861218}, "slavkov, latarna": {"name": "Slavkov, Latarna", "lat": 49.928137, "lng": 17.866054}, "otice, statek": {"name": "Otice, statek", "lat": 49.927228, "lng": 17.871439}, "otice, slavkovska": {"name": "Otice, Slavkovská", "lat": 49.927222, "lng": 17.877126}, "otice, kaple": {"name": "Otice, kaple", "lat": 49.9238, "lng": 17.876453}, "koupaliste": {"name": "Koupaliště", "lat": 49.939602, "lng": 17.873869}, "slavkov, skola": {"name": "Slavkov, škola", "lat": 49.921314, "lng": 17.852004}, "slavkov, zamecka": {"name": "Slavkov, Zámecká", "lat": 49.922031, "lng": 17.850549}, "chvalikovice": {"name": "Chvalíkovice", "lat": 49.885233, "lng": 17.910897}, "chvalikovice, obecni urad": {"name": "Chvalíkovice, Obecní úřad", "lat": 49.886026, "lng": 17.91913}, "vrsovice": {"name": "Vršovice", "lat": 49.885326, "lng": 17.92996}, "radun, skola": {"name": "Raduň, škola", "lat": 49.89059, "lng": 17.940106}, "radun, jednota": {"name": "Raduň, Jednota", "lat": 49.895833, "lng": 17.93897}, "maradkova": {"name": "Mařádkova", "lat": 49.941151, "lng": 17.896659}, "mostni": {"name": "Mostní", "lat": 49.946516, "lng": 17.894934}, "mestske sady": {"name": "Městské sady", "lat": 49.947482, "lng": 17.888184}, "kaufland": {"name": "Kaufland", "lat": 49.942631, "lng": 17.936189}, "pekarny": {"name": "Pekárny", "lat": 49.930625, "lng": 17.891005}, "otice, opavska": {"name": "Otice, Opavská", "lat": 49.920082, "lng": 17.877674}, "otice, skola": {"name": "Otice, škola", "lat": 49.916837, "lng": 17.871888}, "komarov, kravarov": {"name": "Komárov, Kravařov", "lat": 49.909141, "lng": 17.986967}, "suche lazce, dolni": {"name": "Suché Lazce, dolní", "lat": 49.903888, "lng": 17.987111}, "suche lazce, zd": {"name": "Suché Lazce, ZD", "lat": 49.901266, "lng": 17.986207}, "suche lazce, stred": {"name": "Suché Lazce, střed", "lat": 49.898772, "lng": 17.985799}, "suche lazce, horni": {"name": "Suché Lazce, horní", "lat": 49.895402, "lng": 17.988553}, "suche lazce, sedlinka": {"name": "Suché Lazce, Sedlinka", "lat": 49.890072, "lng": 17.990941}, "suche lazce, prerovec": {"name": "Suché Lazce, Přerovec", "lat": 49.886892, "lng": 17.992887}, "radun, komarovska": {"name": "Raduň, Komárovská", "lat": 49.893276, "lng": 17.949956}, "podvihov, kom.chal. vodarna": {"name": "Podvihov, Kom.Chal. vodárna", "lat": 49.890197, "lng": 17.958921}, "podvihov, kom.chal. hlavni": {"name": "Podvihov, Kom.Chal. hlavní", "lat": 49.886906, "lng": 17.958697}};
MHD41.fillOpavaStops(OPAVA_STOPS,normName);

function cleanName(n){ return String(n||'').replace(/\s*\([^)]*\)/g,'').replace(/\s*\b[DZ]\b\s*$/i,'').trim(); }
var __nnC;function normName(n){const k=String(n??'');__nnC=__nnC||new Map();let v=__nnC.get(k);if(v===undefined){v=cleanName(k).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,' ').trim();__nnC.set(k,v)}return v}

// Populate stops
for (const [k, v] of Object.entries(OPAVA_STOPS)) {
  if (!plannerStops.some(s => normName(s.name) === k)) {
    const item = { id: 'stop-' + k, name: v.name, lat: v.lat, lng: v.lng, request: false };
    plannerStops.push(item);
    if (!officialStops.some(s => normName(s.name) === k)) {
      officialStops.push(item);
    }
  }
}

function resolveStop(name) {
  const key = normName(name);
  if (OPAVA_STOPS[key]) return { name: OPAVA_STOPS[key].name, lat: OPAVA_STOPS[key].lat, lng: OPAVA_STOPS[key].lng };
  for (const [k, v] of Object.entries(OPAVA_STOPS)) {
    if (k.includes(key) || key.includes(k)) return { name: v.name, lat: v.lat, lng: v.lng };
  }
  return null;
}

function haversineDist(p1, p2) {
  const R = 6371000;
  const dLat = (p2[0] - p1[0]) * Math.PI / 180;
  const dLng = (p2[1] - p1[1]) * Math.PI / 180;
  const a = Math.sin(dLat/2)**2 + Math.cos(p1[0]*Math.PI/180) * Math.cos(p2[0]*Math.PI/180) * Math.sin(dLng/2)**2;
  return 2 * R * Math.asin(Math.sqrt(a));
}

function routeMetrics(pts) {
  const seg = [];
  let total = 0;
  for (let i = 1; i < pts.length; i++) {
    const d = haversineDist(pts[i-1], pts[i]);
    total += d;
    seg.push({ d, total });
  }
  return { seg, total: Math.max(1, total) };
}

function ptAtDist(pts, m, mtr) {
  if (!pts || !pts.length) return [49.9387, 17.9025];
  if (m <= 0) return pts[0];
  if (m >= mtr.total) return pts[pts.length - 1];
  let prev = 0;
  for (let i = 1; i < pts.length; i++) {
    const end = mtr.seg[i-1].total;
    if (m <= end) {
      const f = (m - prev) / (end - prev || 1);
      return [
        pts[i-1][0] + (pts[i][0] - pts[i-1][0]) * f,
        pts[i-1][1] + (pts[i][1] - pts[i-1][1]) * f
      ];
    }
    prev = end;
  }
  return pts[pts.length - 1];
}

function bearing(p1, p2) {
  const dLng = (p2[1] - p1[1]) * Math.PI / 180;
  const y = Math.sin(dLng) * Math.cos(p2[0] * Math.PI / 180);
  const x = Math.cos(p1[0] * Math.PI / 180) * Math.sin(p2[0] * Math.PI / 180) -
            Math.sin(p1[0] * Math.PI / 180) * Math.cos(p2[0] * Math.PI / 180) * Math.cos(dLng);
  return ((Math.atan2(y, x) * 180 / Math.PI) + 360) % 360;
}

function shiftPoint(p, meters, bearingDeg) {
  const R = 6371000;
  const rad = bearingDeg * Math.PI / 180;
  const dLat = (meters * Math.cos(rad)) / R * (180 / Math.PI);
  const dLng = (meters * Math.sin(rad)) / (R * Math.cos(p[0] * Math.PI / 180)) * (180 / Math.PI);
  return [p[0] + dLat, p[1] + dLng];
}

// ==========================================
// 1. JÍZDA VOZIDLEM (VEHICLE RIDE)
// ==========================================
let rideSpeedMultiplier = 1.0;
let cameraYaw = 0;
let cameraPitch = 69;
let joyPointerId = null;

function rideMetrics(points){
 const cumulative=[0];for(let i=1;i<points.length;i++)cumulative.push(cumulative[i-1]+haversineDist(points[i-1],points[i]));return cumulative;
}
function nearestRouteVertex(points,stop){let best=Infinity,index=0;for(let i=0;i<points.length;i++){const d=haversineDist(points[i],[stop.lat,stop.lng]);if(d<best){best=d;index=i}}return{index,distance:best}}
function monotonicStopMatch(points,rows,startVertex=0,endVertex=points.length-1){
 const n=rows.length,m=endVertex-startVertex+1;if(n<2||m<2)return null;let prev=new Float64Array(m),parents=Array.from({length:n},()=>new Int32Array(m));
 for(let j=0;j<m;j++){const idx=startVertex+j;prev[j]=haversineDist(points[idx],[rows[0].stop.lat,rows[0].stop.lng])+j*.4}
 for(let i=1;i<n;i++){const cur=new Float64Array(m);let minimum=Infinity,minIndex=0;for(let j=0;j<m;j++){if(prev[j]<minimum){minimum=prev[j];minIndex=j}const idx=startVertex+j;cur[j]=minimum+haversineDist(points[idx],[rows[i].stop.lat,rows[i].stop.lng]);parents[i][j]=minIndex}prev=cur}
 let end=0;for(let j=1;j<m;j++)if(prev[j]<prev[end])end=j;const indices=new Int32Array(n);indices[n-1]=end;for(let i=n-1;i>0;i--)indices[i-1]=parents[i][indices[i]];return Array.from(indices,x=>x+startVertex);
}
function buildRideCandidate(bus,names,direction){
 const all=names.map(name=>({name,stop:resolveStop(name)})).filter(x=>x.stop);if(all.length<2)return null;const points=bus.points||[],firstPoint=points[0],lastPoint=points.at(-1);let best=null;
 /* Hledáme souvislý úsek zadaného směru, jehož první a poslední zastávka
    odpovídají skutečným koncům konkrétního GPX. Podmíněné závleky za konečnou
    proto nejsou omylem připojeny k jízdě, která je neobsluhuje. */
 for(let i=0;i<all.length-1;i++)for(let j=i+1;j<all.length;j++){
  const startError=haversineDist(firstPoint,[all[i].stop.lat,all[i].stop.lng]),endError=haversineDist(lastPoint,[all[j].stop.lat,all[j].stop.lng]);
  const coverage=(j-i+1)/all.length,skipped=i+(all.length-1-j),score=startError+endError+skipped*90+(coverage<.95?30000:0);
  if(!best||score<best.score)best={i,j,startError,endError,coverage,score};
 }
 if(!best||best.startError>850||best.endError>850||best.coverage<.95)return null;const rows=all.slice(best.i,best.j+1),indices=monotonicStopMatch(points,rows);if(!indices)return null;const cumulative=rideMetrics(points),total=cumulative.at(-1),stops=rows.map((row,k)=>({name:row.name,lat:row.stop.lat,lng:row.stop.lng,dist:k===0?0:k===rows.length-1?total:cumulative[indices[k]],request:typeof isRequest==='function'?isRequest({name:row.name}):false}));
 /* Stejná nebo téměř stejná projekce více zastávek se rozloží mezi sousední
    známé body; pořadí zastávek se nikdy netřídí ani nemění. */
 for(let k=1;k<stops.length;k++)if(stops[k].dist<=stops[k-1].dist+1)stops[k].dist=Math.min(total,stops[k-1].dist+Math.max(2,(total-stops[k-1].dist)/(stops.length-k)));
 stops[stops.length-1].dist=total;return{direction,stops,score:best.score,coverage:best.coverage,total};
}
function prepareRideStops(bus){
 const patterns=manualPlannerPatterns[String(bus.line)]||[],plans=patterns.map((names,direction)=>buildRideCandidate(bus,names,direction)).filter(Boolean).sort((a,b)=>a.score-b.score),plan=plans[0]||null;
 bus._ridePlan=plan;bus._stopsWithDist=plan?.stops||[];bus.rideDirection=plan?.direction??0;return bus._stopsWithDist;
}
function rideStopIsRequest(stop){return !!stop.request}
function scrollRidePanelToCurrent(instant=false){
 const box=document.getElementById('ride-stops');if(!box)return;requestAnimationFrame(()=>requestAnimationFrame(()=>{const active=box.querySelector('.ride-stop-pill.current');if(!active)return;try{active.scrollIntoView({behavior:instant?'auto':'smooth',block:'center',inline:'nearest'})}catch(_){active.scrollIntoView(false)}const index=Number(active.dataset.index)||0;if(index<2)box.scrollTop=0}));
}
function renderRideStopTable(instant=false){
 if(!rideBus)return;const stops=rideBus._stopsWithDist||[],box=document.getElementById('ride-stops');if(!box)return;if(!stops.length){box.innerHTML='<div class="ride-stop-pill current"><span>Načítám zastávky…</span></div>';return}
 const next=Math.max(0,Math.min(stops.length-1,rideBus.currentStopIndex??1)),from=Math.max(0,next-1),to=Math.min(stops.length,next+4),visible=[];for(let index=from;index<to;index++)visible.push(index);if(!visible.includes(stops.length-1))visible.push(stops.length-1);
 const pill=index=>{const stop=stops[index],state=index<next?'passed':index===next?'current':'future',terminal=index===stops.length-1,label=index===next?(terminal?'Konečná zastávka':'Příští zastávka'):(terminal?'Konečná zastávka':'');return '<div class="ride-stop-pill '+state+'" data-index="'+index+'"><span class="ride-stop-icon"><i class="fa-solid '+(terminal?'fa-flag-checkered':index===next?'fa-location-dot':'fa-circle')+'"></i></span><span class="ride-stop-copy">'+(label?'<small>'+label+'</small>':'')+'<strong>'+esc(cleanName(stop.name))+'</strong></span>'+(rideStopIsRequest(stop)?'<span class="ride-request" title="Zastávka na znamení"><i class="fa-solid fa-thumbs-up"></i></span>':'')+'</div>'};
 let html='';if(from>0)html+='<div class="ride-window-note"><i class="fa-solid fa-chevron-up"></i> '+from+' projetých zastávek</div>';visible.forEach((index,position)=>{if(position&&index-visible[position-1]>1)html+='<div class="ride-window-note">'+(index-visible[position-1]-1)+' dalších zastávek <i class="fa-solid fa-ellipsis"></i></div>';html+=pill(index)});box.innerHTML=html;box.scrollTop=0;
}
let rideStarting=false,rideLoopGeneration=0;
function setRideButtonLoading(on,label='Načítám jízdu…'){const button=document.getElementById('ride-start-btn');if(!button)return;button.disabled=on;button.innerHTML=on?'<i class="fa-solid fa-spinner fa-spin"></i><span>'+esc(label)+'</span>':'<i class="fa-solid fa-bus"></i><span>Jízda vozidlem</span>'}
function waitForRide(test,timeout,message){return new Promise((resolve,reject)=>{const began=Date.now(),tick=()=>{let value;try{value=test()}catch(_){}if(value)return resolve(value);if(Date.now()-began>timeout)return reject(Error(message));setTimeout(tick,200)};tick()})}
function resetRideMap(){try{map.setView(OPAVA_CENTER,13,{animate:true})}catch(_){}try{map3d?.stop();map3d?.jumpTo({center:[OPAVA_CENTER[1],OPAVA_CENTER[0]],zoom:15.2,pitch:62,bearing:-18})}catch(_){}}
function showRideError(error){let el=document.getElementById('ride-error-message');if(!el){el=document.createElement('div');el.id='ride-error-message';el.className='ride-error-message';document.body.appendChild(el)}el.textContent=error?.message||String(error);el.classList.add('show');clearTimeout(el._timer);el._timer=setTimeout(()=>el.classList.remove('show'),6500)}
function finishRideAtTerminal(){if(!rideActive||!rideBus||rideBus._terminalReached)return;rideBus._terminalReached=true;rideBus.speed=0;rideBus.effSpeed=0;rideActive=false;rideLoopGeneration++;const terminal=rideBus._stopsWithDist.at(-1),box=document.getElementById('ride-stops');if(box){box.scrollTop=box.scrollHeight;box.innerHTML='<div class="ride-terminal"><i class="fa-solid fa-flag-checkered"></i><small>Konečná zastávka</small><strong>'+esc(cleanName(terminal.name))+'</strong></div>'}setTimeout(()=>window.endRide(),6000)}
function updateRideLoop(generation=rideLoopGeneration){
 if(generation!==rideLoopGeneration||!rideActive||!rideBus||!map3dReady)return;rideBus.speed=11.5*rideSpeedMultiplier;const stops=rideBus._stopsWithDist||[],distance=Number(rideBus.distance)||0,total=rideBus.length||rideBus._ridePlan?.total||0;
 if(stops.length){if(distance>=total-3){finishRideAtTerminal();return}let next=Math.max(1,Number(rideBus.currentStopIndex)||1);while(next<stops.length-1&&distance>=Number(stops[next].dist)+1.5)next++;while(next>1&&distance<Number(stops[next-1].dist)-8)next--;if(next!==rideBus.currentStopIndex){rideBus.currentStopIndex=next;renderRideStopTable(false);try{playStopChime()}catch(_){}}}
 if(rideBus.lngLat&&Number.isFinite(rideBus.bearing)&&rideFollow){if(!Number.isFinite(rideBus._smoothBearing))rideBus._smoothBearing=rideBus.bearing;const diff=((rideBus.bearing-rideBus._smoothBearing+540)%360)-180;rideBus._smoothBearing=(rideBus._smoothBearing+diff*.16+360)%360;const position=shiftPoint([rideBus.lngLat[1],rideBus.lngLat[0]],2.1,rideBus._smoothBearing+180);try{map3d.jumpTo({center:[position[1],position[0]],bearing:(rideBus._smoothBearing+cameraYaw+360)%360,zoom:19.35,pitch:cameraPitch})}catch(_){}}
 requestAnimationFrame(()=>updateRideLoop(generation));
}
window.startRide=async function(){
 if(rideStarting||rideActive)return;rideStarting=true;setRideButtonLoading(true,'Načítám 3D mapu…');try{show3D();await waitForRide(()=>map3d,10000,'3D mapa se nevytvořila.');await waitForRide(()=>map3dReady,60000,'3D mapa se nenačetla. Zkontrolujte připojení.');if(!busVehicles?.length)buildFleet();const source=(busVehicles?.length?busVehicles:fleet)||[],candidates=[];for(const vehicle of source){if(NIGHT_LINES.has(String(vehicle.line))||!vehicle.points?.length)continue;const stops=prepareRideStops(vehicle);if(stops.length>=2)candidates.push(vehicle)}if(!candidates.length)throw Error('Není dostupná úplná trasa se správnou konečnou zastávkou.');rideBus=candidates[Math.floor(Math.random()*candidates.length)];const stops=rideBus._stopsWithDist;rideActive=true;rideBus._terminalReached=false;rideBus.direction=rideBus.rideDirection;rideBus.distance=0;rideBus.offset=0;rideBus.start=performance.now();rideBus._poseLastT=performance.now();rideBus.effSpeed=null;rideBus.currentStopIndex=1;delete rideBus._smoothBearing;rideSpeedMultiplier=1;cameraYaw=0;cameraPitch=69;rideFollow=true;document.body.classList.add('ride-mode');['ride-panel','ride-controls'].forEach(id=>{const el=document.getElementById(id);el?.classList.add('open');el?.setAttribute('aria-hidden','false')});const badge=document.getElementById('ride-line');if(badge){badge.textContent=rideBus.line;badge.style.background=lineBadgeColor(String(rideBus.line));badge.style.color='#fff'}const title=document.getElementById('ride-title');if(title)title.textContent=cleanName(stops[0].name)+' → '+cleanName(stops.at(-1).name);renderRideStopTable(true);rideLoopGeneration++;updateRideLoop(rideLoopGeneration)}catch(error){console.error('[Jízda]',error);rideActive=false;rideBus=null;showRideError(error)}finally{rideStarting=false;setRideButtonLoading(false)}
};
window.endRide=function(){rideLoopGeneration++;rideActive=false;if(rideBus){rideBus.effSpeed=null;rideBus._terminalReached=false}rideBus=null;document.body.classList.remove('ride-mode');['ride-panel','ride-controls'].forEach(id=>{const el=document.getElementById(id);el?.classList.remove('open');el?.setAttribute('aria-hidden','true')});resetRideMap()};

document.getElementById('ride-end-top')?.addEventListener('click',()=>window.endRide());
document.getElementById('ride-end')?.addEventListener('click',()=>window.endRide());
document.getElementById('ride-speed-2x')?.addEventListener('click',e=>{rideSpeedMultiplier=rideSpeedMultiplier===1?2:1;const button=e.currentTarget;button.classList.toggle('active',rideSpeedMultiplier===2);const label=button.querySelector('span');if(label)label.textContent=rideSpeedMultiplier===2?'Zpomalit na 1×':'2× zrychlit jízdu'});
document.getElementById('ride-restart')?.addEventListener('click',()=>{window.endRide();setTimeout(()=>window.startRide(),250)});

// Joystick
const joy = document.getElementById('ride-joystick');
const knob = document.getElementById('ride-joystick-knob');

function onJoyMove(e) {
  if (joyPointerId !== e.pointerId) return;
  const rect = joy.getBoundingClientRect();
  const cx = rect.left + rect.width / 2;
  const cy = rect.top + rect.height / 2;
  const dx = e.clientX - cx;
  const dy = e.clientY - cy;
  const maxR = rect.width * 0.32;
  const len = Math.hypot(dx, dy) || 1;
  const k = Math.min(1, maxR / len);
  const kx = dx * k;
  const ky = dy * k;

  knob.style.transform = `translate(${kx}px, ${ky}px)`;
  cameraYaw = Math.max(-160, Math.min(160, cameraYaw + (dx / rect.width) * 4.5));
  cameraPitch = Math.max(28, Math.min(82, cameraPitch - (dy / rect.height) * 2.5));
}

function onJoyEnd(e) {
  if (joyPointerId !== e.pointerId) return;
  joyPointerId = null;
  knob.style.transform = 'translate(0, 0)';
  try { joy.releasePointerCapture(e.pointerId); } catch(_) {}
}

if (joy) {
  joy.addEventListener('pointerdown', e => {
    joyPointerId = e.pointerId;
    joy.setPointerCapture(e.pointerId);
    onJoyMove(e);
    e.preventDefault();
  });
  joy.addEventListener('pointermove', onJoyMove);
  joy.addEventListener('pointerup', onJoyEnd);
  joy.addEventListener('pointercancel', onJoyEnd);
}

// ==========================================
// 2. HLEDÁNÍ TRAS
// ==========================================
const ALL_STOPS_LIST = Object.entries(OPAVA_STOPS).map(([k, v]) => ({
  key: k,
  name: v.name,
  lat: v.lat,
  lng: v.lng
}));

function uniqueLogicalStops(){const map=new Map();for(const [key,stop] of Object.entries(OPAVA_STOPS)){const name=cleanName(stop.name),normalized=normName(name);if(!map.has(normalized))map.set(normalized,{key,name,lat:stop.lat,lng:stop.lng})}return[...map.values()]}
const LOGICAL_STOPS=uniqueLogicalStops();
function getNearestStops(lat,lng,n=8){return LOGICAL_STOPS.map(stop=>({...stop,distance:haversineDist([lat,lng],[stop.lat,stop.lng])})).sort((a,b)=>a.distance-b.distance).slice(0,n)}
function getPlannerPatterns(){const list=[];for(const[line,directions]of Object.entries(manualPlannerPatterns)){if(NIGHT_LINES.has(String(line)))continue;directions.forEach((names,direction)=>{const stops=names.map(name=>resolveStop(name)).filter(Boolean);if(stops.length>=2)list.push({line:String(line),direction,stops})})}return list}
const APP_PATTERNS=getPlannerPatterns();
function sameLogicalStop(a,b){return normName(a.name)===normName(b.name)}
function occurrenceIndices(stops,target,after=-1){const out=[];stops.forEach((stop,index)=>{if(index>after&&sameLogicalStop(stop,target))out.push(index)});return out}
function czechStops(count){return count===1?'1 zastávka':count>=2&&count<=4?count+' zastávky':count+' zastávek'}
function rideLeg(pattern,fromIndex,toIndex){if(toIndex<=fromIndex)return null;const stops=pattern.stops.slice(fromIndex,toIndex+1);let meters=0;for(let i=1;i<stops.length;i++)meters+=haversineDist([stops[i-1].lat,stops[i-1].lng],[stops[i].lat,stops[i].lng]);return{line:pattern.line,direction:pattern.direction,stops,meters}}
function candidateScore(candidate){
 /* Lexikografická logika v číselné podobě:
    1) co nejméně přestupů, 2) co nejméně chůze, 3) co nejméně zastávek,
    4) kratší jízda. Přesný uživatelský výběr zastávky má nulovou chůzi. */
 return candidate.walkTotal/1.25+candidate.rideMeters/6.5+candidate.stopCount*18+candidate.transfers*480;
}
function buildTransitCandidates(originStops,destinationStops){
 const output=[];
 for(const origin of originStops)for(const destination of destinationStops){
  const walkIn=origin.distance||0,walkOut=destination.distance||0,walkTotal=walkIn+walkOut;
  for(const pattern of APP_PATTERNS){for(const fromIndex of occurrenceIndices(pattern.stops,origin)){for(const toIndex of occurrenceIndices(pattern.stops,destination,fromIndex)){const leg=rideLeg(pattern,fromIndex,toIndex);if(!leg)continue;const candidate={transfers:0,from:origin,to:destination,walkIn,walkOut,walkTotal,stopCount:leg.stops.length-1,rideMeters:leg.meters,legs:[leg]};candidate.score=candidateScore(candidate);output.push(candidate)}}}
  for(const first of APP_PATTERNS){for(const fromIndex of occurrenceIndices(first.stops,origin)){for(let transferIndex=fromIndex+1;transferIndex<first.stops.length;transferIndex++){const transfer=first.stops[transferIndex];for(const second of APP_PATTERNS){if(first.line===second.line)continue;for(const secondStart of occurrenceIndices(second.stops,transfer)){for(const destinationIndex of occurrenceIndices(second.stops,destination,secondStart)){const leg1=rideLeg(first,fromIndex,transferIndex),leg2=rideLeg(second,secondStart,destinationIndex);if(!leg1||!leg2)continue;const candidate={transfers:1,from:origin,to:destination,transfer,walkIn,walkOut,walkTotal,stopCount:leg1.stops.length+leg2.stops.length-2,rideMeters:leg1.meters+leg2.meters,legs:[leg1,leg2]};candidate.score=candidateScore(candidate);output.push(candidate)}}}}}}
 }
 return output;
}
function chooseLogicalVariants(originStops,destinationStops,max=4){const generated=buildTransitCandidates(originStops,destinationStops),direct=generated.filter(x=>x.transfers===0),all=(direct.length?direct:generated).sort((a,b)=>a.score-b.score),result=[],seen=new Set();for(const candidate of all){const signature=candidate.legs.map(leg=>leg.line+':'+normName(leg.stops[0].name)+'>'+normName(leg.stops.at(-1).name)).join('|');if(seen.has(signature))continue;if(result.length&&candidate.transfers>result[0].transfers+1)continue;if(result.length&&candidate.walkTotal>result[0].walkTotal+700)continue;seen.add(signature);result.push(candidate);if(result.length>=max)break}return result}
async function resolvePlaceInput(raw){
 const text=String(raw||'').trim();if(!text)throw Error('Zadejte adresu nebo zastávku.');const exactKey=normName(text),exactData=OPAVA_STOPS[exactKey],direct=exactData?{name:exactData.name,lat:exactData.lat,lng:exactData.lng}:null;if(direct)return{lat:direct.lat,lng:direct.lng,label:cleanName(direct.name),isStop:true,stop:direct};const query=/\bOpava\b/i.test(text)?text:text+', Opava, Česko';const providers=[async()=>{const response=await fetch('https://photon.komoot.io/api/?limit=5&q='+encodeURIComponent(query));const json=await response.json();const item=json.features?.find(x=>{const c=x.geometry?.coordinates||[];return c[1]>=49.84&&c[1]<=50.03&&c[0]>=17.72&&c[0]<=18.08});if(!item)throw Error();return{lat:item.geometry.coordinates[1],lng:item.geometry.coordinates[0],label:[item.properties?.name,item.properties?.street,item.properties?.city].filter(Boolean).join(', ')||text}},async()=>{const response=await fetch('https://geocode.arcgis.com/arcgis/rest/services/World/GeocodeServer/findAddressCandidates?f=json&maxLocations=5&outFields=Match_addr&singleLine='+encodeURIComponent(query));const json=await response.json();const item=json.candidates?.find(x=>x.location?.y>=49.84&&x.location?.y<=50.03&&x.location?.x>=17.72&&x.location?.x<=18.08);if(!item)throw Error();return{lat:item.location.y,lng:item.location.x,label:item.address||text}}];for(const provider of providers){try{return await provider()}catch(_){}}throw Error('Místo se nepodařilo najít. Zadejte zastávku nebo přesnější adresu.')
}
function routeSegmentPoints(leg){
 const options=gpxRoutes[String(leg.line)]||[];let best=null;for(let routeIndex=0;routeIndex<options.length;routeIndex++){const route=options[routeIndex];if(!route.points?.length)continue;const rows=leg.stops.map(stop=>({stop})),indices=monotonicStopMatch(route.points,rows);if(!indices)continue;const first=indices[0],last=indices.at(-1),endpoint=haversineDist(route.points[first],[leg.stops[0].lat,leg.stops[0].lng])+haversineDist(route.points[last],[leg.stops.at(-1).lat,leg.stops.at(-1).lng]);if(last>first&&(!best||endpoint<best.endpoint))best={points:route.points.slice(first,last+1),endpoint,routeIndex}}
 return best?.points||leg.stops.map(stop=>[stop.lat,stop.lng]);
}
async function drawLogicalConnection(connection,origin,destination){
 searchRouteLayer.clearLayers();
 const bounds=L.latLngBounds([]);
 const line=(points,color,dash=null,weight=6)=>{if(!points||points.length<2)return false;L.polyline(points,{color,weight,opacity:.96,dashArray:dash,lineCap:'round',lineJoin:'round'}).addTo(searchRouteLayer);points.forEach(point=>bounds.extend(point));return true};
 const marker=(lat,lng,html)=>{L.marker([lat,lng],{icon:L.divIcon({className:'search-map-marker',html,iconSize:[26,26],iconAnchor:[13,13]}),zIndexOffset:850}).addTo(searchRouteLayer);bounds.extend([lat,lng])};
 marker(origin.lat,origin.lng,'<div class="rt-dot a">A</div>');
 marker(destination.lat,destination.lng,'<div class="rt-dot b">B</div>');
 // Pěší úsek: pouze skutečná pěší trasa z routovací služby. Když není dostupná,
 // úsek se raději nevykreslí jako přímá čára přes budovy.
 if(connection.walkIn>5){
  try{const walkIn=await roadPath(origin,connection.from);if(walkIn?.length>1)line(walkIn,'#4f4741','6 7',4)}catch(_){}}
 for(const leg of connection.legs){
  const pts=routeSegmentPoints(leg);
  line(pts,lineBadgeColor(leg.line),null,8);
  for(const stop of leg.stops)marker(stop.lat,stop.lng,'<div class="route-stop-dot"></div>');
  if(connection.transfers&&leg===connection.legs[0])marker(connection.transfer.lat,connection.transfer.lng,'<div class="rt-dot transfer">↔</div>');
 }
 if(connection.walkOut>5){
  try{const walkOut=await roadPath(connection.to,destination);if(walkOut?.length>1)line(walkOut,'#4f4741','6 7',4)}catch(_){}}
 if(bounds.isValid())map.fitBounds(bounds,{padding:[70,70],animate:true});
 try{push3dSearchRoute()}catch(_){}}

function renderLogicalConnection(connection,origin,destination){
 const box=document.getElementById('connection-results');if(!box)return;
 const legHTML=leg=>'<div class="connection-leg"><div class="leg-top"><span class="leg-line" style="background:'+lineBadgeColor(leg.line)+'">'+esc(leg.line)+'</span><span class="leg-text">'+esc(cleanName(leg.stops[0].name))+' → '+esc(cleanName(leg.stops.at(-1).name))+'</span><span class="leg-time">'+czechStops(leg.stops.length-1)+'</span></div><div class="leg-stops">'+leg.stops.map(stop=>esc(cleanName(stop.name))).join(' → ')+'</div></div>';
 const walkIn=Math.max(0,Math.round(connection.walkIn||0)),walkOut=Math.max(0,Math.round(connection.walkOut||0));
 let html='<div class="connection-result">';
 html+='<div class="connection-summary"><div class="conn-route-title"><span>'+esc(origin.label)+'</span><i class="fa-solid fa-arrow-right"></i><span>'+esc(destination.label)+'</span></div><div class="conn-facts"><span><i class="fa-solid '+(connection.transfers?'fa-arrow-right-arrow-left':'fa-route')+'"></i> '+(connection.transfers?'1 přestup':'Bez přestupu')+'</span><span><i class="fa-solid fa-location-dot"></i> '+connection.stopCount+' zastávek</span><span><i class="fa-solid fa-person-walking"></i> '+(walkIn+walkOut)+' m pěšky</span></div></div>';
 if(connection.walkIn>20)html+='<div class="conn-step walk"><i class="fa-solid fa-person-walking"></i><div><strong>Pěšky '+walkIn+' m</strong><div class="conn-sub">k zastávce '+esc(cleanName(connection.from.name))+'</div></div></div>';
 html+=legHTML(connection.legs[0]);
 if(connection.transfers)html+='<div class="transfer"><i class="fa-solid fa-arrow-right-arrow-left"></i><div><strong>Přestup na '+esc(cleanName(connection.transfer.name))+'</strong><div class="conn-sub">Přestup je uvnitř stejné zastávkové oblasti.</div></div></div>'+legHTML(connection.legs[1]);
 if(connection.walkOut>20)html+='<div class="conn-step walk"><i class="fa-solid fa-person-walking"></i><div><strong>Pěšky '+walkOut+' m</strong><div class="conn-sub">od '+esc(cleanName(connection.to.name))+' do cíle</div></div></div>';
 html+='<div class="connection-map-legend"><span><b class="legend-transit"></b> MHD</span><span><b class="legend-walk"></b> Pěšky</span><span><b class="legend-stop"></b> Zastávka</span></div>';
 html+='<a class="idos-button" target="_blank" rel="noopener" href="'+idosUrl()+'"><i class="fa-solid fa-clock"></i> Ověřit skutečné odjezdy v IDOS</a></div>';
 box.innerHTML=html;
}

window.runConnectionSearch=async function(){
 const button=document.getElementById('find-connection');
 document.querySelectorAll('.search-suggest-box').forEach(x=>x.remove());
 try{
  if(button){button.disabled=true;button.innerHTML='<i class="fa-solid fa-spinner fa-spin"></i> Hledám…'}
  setSearchStatus('connection-status','Hledám zastávky a ověřuji trasu…');
  const box=document.getElementById('connection-results');if(box)box.innerHTML='';
  const fromInput=document.getElementById('from-address'),toInput=document.getElementById('to-address');
  const fromText=fromInput?.value.trim(),toText=toInput?.value.trim();
  if(!fromText||!toText)throw Error('Vyplňte Odkud i Kam.');
  const[origin,destination]=await Promise.all([resolvePlaceInput(fromText),resolvePlaceInput(toText)]);
  if(haversineDist([origin.lat,origin.lng],[destination.lat,destination.lng])<70)throw Error('Výchozí místo a cíl jsou téměř stejné.');
  const originStops=origin.isStop?[{...origin.stop,name:origin.stop.name,distance:0}]:getNearestStops(origin.lat,origin.lng,6);
  const destinationStops=destination.isStop?[{...destination.stop,name:destination.stop.name,distance:0}]:getNearestStops(destination.lat,destination.lng,6);
  if(!originStops.length||!destinationStops.length)throw Error('V okolí nebyly nalezeny zastávky.');
  const variants=chooseLogicalVariants(originStops,destinationStops,4);
  if(!variants.length)throw Error('Pro tato místa nebylo nalezeno logické spojení s nejvýše jedním přestupem.');
  let selected=0;
  const renderVariantTabs=()=>{
   const result=document.getElementById('connection-results');if(!result)return;
   const old=result.querySelector('.connection-variant-tabs');old?.remove();
   if(variants.length<=1)return;
   const tabs=document.createElement('div');tabs.className='connection-variant-tabs';
   tabs.innerHTML=variants.map((variant,index)=>'<button type="button" class="connection-variant '+(index===selected?'active':'')+'" data-index="'+index+'"><strong>Varianta '+(index+1)+'</strong><span>'+variant.legs.map(leg=>leg.line).join(' → ')+'</span><small>'+(variant.transfers?'1 přestup':'přímá')+' • '+variant.stopCount+' zast.</small></button>').join('');
   result.prepend(tabs);
   tabs.querySelectorAll('button').forEach(tab=>tab.onclick=async()=>{selected=Number(tab.dataset.index);setSearchStatus('connection-status','Přepočítávám zobrazenou variantu…');const connection=variants[selected];await drawLogicalConnection(connection,origin,destination);renderLogicalConnection(connection,origin,destination);renderVariantTabs();setSearchStatus('connection-status','Varianta '+(selected+1)+' z '+variants.length+' je zobrazena.')});
  };
  const connection=variants[selected];
  renderLogicalConnection(connection,origin,destination);
  renderVariantTabs();
  await drawLogicalConnection(connection,origin,destination);
  renderLogicalConnection(connection,origin,destination);
  renderVariantTabs();
  const o=origin.isStop?'přesně zadaná zastávka':(originStops[0]?.name||'nejbližší zastávka');
  const d=destination.isStop?'přesně zadaná zastávka':(destinationStops[0]?.name||'nejbližší zastávka');
  setSearchStatus('connection-status','Používám '+o+' → '+d+'. Nalezeny '+variants.length+' variant'+(variants.length===1?'a': 'y')+'.');
 }catch(error){
  console.error('[Hledání]',error);
  setSearchStatus('connection-status',error.message||'Hledání selhalo.',true);
 }finally{
  if(button){button.disabled=false;button.innerHTML='<i class="fa-solid fa-magnifying-glass"></i> Najít spojení'}
 }
};

['from-address', 'to-address'].forEach(id => {
  document.getElementById(id)?.addEventListener('keydown', e => {
    if (e.key === 'Enter') {
      e.preventDefault();
      window.runConnectionSearch();
    }
  });
});

const findBtn = document.getElementById('find-connection');
if (findBtn) {
  findBtn.onclick = () => window.runConnectionSearch();
}

})();
