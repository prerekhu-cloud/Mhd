
(function(){
  'use strict';

  const normStop = (v)=>String(v||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\s+/g,' ').trim();
  const cleanLineName = (v)=>String(v||'').replace(/\s*\([^)]*\)\s*$/,'').trim();
  const numberListFromText = (v)=>[...new Set((String(v||'').match(/\b\d{3}\b/g)||[]))].sort((a,b)=>Number(a)-Number(b));

  /* Linky obsluhující Regio zastávku – čerpají přímo z imported MHD_REGIO_LINES. */
  const regioLinesByStop = new Map();
  try{
    for(const row of (window.MHD_REGIO_LINES||[])){
      const num=String(row?.num||'').trim();
      if(!num) continue;
      for(const raw of (row?.stops||[])){
        const key=normStop(cleanLineName(raw));
        if(!key) continue;
        const set=regioLinesByStop.get(key)||new Set();
        set.add(num);regioLinesByStop.set(key,set);
      }
    }
  }catch(_){ }

  function linesAtAnyStop(stop){
    const base = typeof linesAtOfficialStop==='function' ? (linesAtOfficialStop(stop)||[]) : [];
    const key=normStop(cleanLineName(stop?.name||''));
    const regio=[...(regioLinesByStop.get(key)||[])];
    const fromText=numberListFromText(stop?.rawName||stop?.name||'');
    return [...new Set([...base,...regio,...fromText])].sort((a,b)=>Number(a)-Number(b));
  }

  function stopPillHtml(stop, lines, regional){
    const nums=(lines||[]).length?lines:['•'];
    const chips=nums.map(n=>`<span class="stop-pill-line">${esc(String(n))}</span>`).join('');
    const request=stop?.request||stop?.requestStop;
    const req=request?'<span class="stop-pill-request" title="Zastávka na znamení"><i class="fa-solid fa-thumbs-up"></i></span>':'';
    return `<div class="${regional?'regio-stop-pill':'opava-stop-pill'} ${request?'request':''}">${chips}${req}</div>`;
  }

  /* Původní tečku na mapě nahrazujeme jednotným pill markerem s obsluhujícími linkami. */
  if(typeof renderOfficialStopMarkers==='function'){
    renderOfficialStopMarkers = function(){
      if(!stopMarkers) return;
      stopMarkers.clearLayers();
      const groups=new Map();
      for(const stop of (officialStops||[])){
        const key=normStop(stop.name);
        if(!groups.has(key)) groups.set(key,[]);
        groups.get(key).push(stop);
      }
      const all=[];
      for(const arr of groups.values()){
        arr.forEach((stop,i)=>{
          const lines=linesAtAnyStop(stop);
          const icon=L.divIcon({className:'opava-stop-marker',html:stopPillHtml(stop,lines,false),iconSize:[0,0],iconAnchor:[0,0]});
          const marker=L.marker([stop.lat,stop.lng],{icon,zIndexOffset:300});
          const badges=lines.map(n=>`<span class="line">${esc(String(n))}</span>`).join('');
          const platformNote=arr.length>1?`<div class="dir">Nástupiště ${i+1}/${arr.length}</div>`:'';
          const popup=`<div class="official-stop-popup"><h4>${esc(stop.name)}</h4><div class="dir">${stop.direction?'Směr: '+esc(stop.direction)+' · ':''}${stop.request?'Zastávka na znamení':'Zastávka MHD'}</div>${platformNote}${badges?'<div>'+badges+'</div>':''}</div>`;
          marker.bindPopup(popup);
          marker._minZoom=i===0?STOP_MARKER_MINZOOM:STOP_MARKER_MINZOOM+STOP_MARKER_PLATFORM_STEP+(i-1);
          all.push(marker);
        });
      }
      stopMarkers._allMarkers=all;
      updateStopMarkerVisibility();
    };
  }
  try{ if(Array.isArray(officialStops) && officialStops.length) renderOfficialStopMarkers(); }catch(_){ }

  /* Regio vrstva používá stejný marker; tím zmizí samostatná hnědá tečka i velká ikona autobusu. */
  function rebuildRegionalStopLayer(){
    try{
      const layer=L.layerGroup();
      const seen=new Set();
      for(const stop of (window.MHD_REGIO_STOPS||[])){
        const name=cleanLineName(stop.name);
        const key=normStop(name);
        if(!key || seen.has(key) || !Number.isFinite(Number(stop.lat)) || !Number.isFinite(Number(stop.lon))) continue;
        const lines=[...(regioLinesByStop.get(key)||[])];
        const merged=[...new Set([...lines,...numberListFromText(stop.name)])].sort((a,b)=>Number(a)-Number(b));
        const icon=L.divIcon({className:'regio-stop-marker',html:stopPillHtml({...stop,name,request:!!stop.requestStop},merged,true),iconSize:[0,0],iconAnchor:[0,0]});
        const marker=L.marker([Number(stop.lat),Number(stop.lon)],{icon,zIndexOffset:310});
        const badges=merged.map(n=>`<span class="line">${esc(String(n))}</span>`).join('');
        marker.bindPopup(`<div class="official-stop-popup"><h4>${esc(name)}</h4><div class="dir">Regio autobus${stop.requestStop?' · zastávka na znamení':''}</div>${badges?'<div>'+badges+'</div>':''}</div>`);
        marker.addTo(layer);
        seen.add(key);
      }
      window.regioStopLayer=layer;
      return layer;
    }catch(err){console.warn('Regio stop pill layer:',err);return window.regioStopLayer||L.layerGroup()}
  }
  rebuildRegionalStopLayer();

  /* Standardní miniatura autobusu/trolejbusu i pro Regio řádky. */
  function normalizeRegioRows(){
    if(window.__completeRegioRendering)return;
    document.querySelectorAll('.network-item.regio').forEach(item=>{
      const line=item.querySelector('.route-number')?.textContent?.trim()||'';
      const thumb=item.querySelector('.route-thumb');
      if(thumb && typeof lineThumbSVG==='function'){
        const desired = typeof LINE_THUMB_BUS_LIGHT!=='undefined' ? LINE_THUMB_BUS_LIGHT : '';
        const current = thumb.querySelector('.rt-light')?.getAttribute('src') || '';
        if(!desired || current!==desired){
          thumb.innerHTML=lineThumbSVG(false, typeof lineBadgeColor==='function'?lineBadgeColor(line):'#C1784F');
        }
      }
      const badge=item.querySelector('.regio-badge');
      if(badge) badge.remove();
    });
  }
  normalizeRegioRows();
  const list=document.getElementById('network-list');
  if(list){
    new MutationObserver(normalizeRegioRows).observe(list,{childList:true,subtree:true});
  }

  /* Po změně velikosti okna ponecháme chování panelu jízdy stejné jako v referenčním rozložení. */
  window.addEventListener('resize',()=>{
    if(document.body.classList.contains('ride-mode') && typeof renderRideStopTable==='function') renderRideStopTable(true);
  });
})();
