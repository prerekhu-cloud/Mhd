
(function(){
/* ==========================================================================
   MHD Opava – finální vrstva převzatá z mhd-opava(41):
   1) správná data zastávek a obsluhujících linek, 2) funkční hledání
   (zastávky, linky, adresy, spojení), 3) panel zastávek v jízdě vozidlem.
   ========================================================================== */
const D=window.MHD41;if(!D)return;
const $=id=>document.getElementById(id);
const h=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const night=n=>{try{return NIGHT_LINES.has(String(n))}catch(_){return false}};
const dist=(a,b)=>{const R=6371000,p=Math.PI/180,la1=a[0]*p,la2=b[0]*p,dl=(b[0]-a[0])*p,dn=(b[1]-a[1])*p;const x=Math.sin(dl/2)**2+Math.cos(la1)*Math.cos(la2)*Math.sin(dn/2)**2;return 2*R*Math.asin(Math.min(1,Math.sqrt(x)))};
const leave3D=()=>{try{const e=$('mapbox3d');if(e&&!e.classList.contains('hidden')&&typeof show2D==='function')show2D()}catch(_){}};
const FLOW_R=L.svg({padding:.5});
const fmtDist=m=>m<1000?Math.round(m/10)*10+' m':(m/1000).toFixed(1).replace('.',',')+' km';
const czStops=n=>n===1?'1 zastávka':n>=2&&n<=4?n+' zastávky':n+' zastávek';

/* ---------- 1. Data: barvy linek, linky u zastávek, zastávky na znamení ---------- */
const oldColor=lineBadgeColor;
window.lineBadgeColor=lineBadgeColor=function(n){return D.color(n)||oldColor(n)};
const chip=(n,cls='')=>{const l=D.line(n),reg=l&&!l.city&&!l.train;return '<span class="l41 '+(reg?'reg ':'')+(l?.train?'train ':'')+(l?.suspended?'susp ':'')+(night(n)?'night ':'')+cls+'" data-line="'+h(n)+'"'+(reg?'':' style="--lc:'+h(D.color(n)||'#777')+'"')+'>'+(l?.train?'<i class="fa-solid fa-train"></i>':'')+h(n)+'</span>'};
const chips=(arr,max=99,except)=>{const list=arr.filter(n=>n!==except);const shown=list.slice(0,max);return shown.map(n=>chip(n)).join('')+(list.length>max?'<span class="l41 more">+'+(list.length-max)+'</span>':'')};

window.linesAtOfficialStop=linesAtOfficialStop=function(s){return D.linesAt(s?.name??s)};
try{for(const k of Object.keys(STOP_LINES_OVERRIDE))delete STOP_LINES_OVERRIDE[k];for(const s of D.stops.values())if(s.lines.size)STOP_LINES_OVERRIDE[normalizePlannerName(s.name)]=s.lineList}catch(_){}
const oldIsRequest=isRequest;
window.isRequest=isRequest=function(s){if(typeof s?.request==='boolean')return s.request;const st=D.stop(s?.name);return st?st.request:oldIsRequest(s)};

/* Zastávky na mapě: nástupiště z dat (41), ne externí zdroj. */
/* body zastávek na mapu: jen aktuální nástupiště zastávky, bez duplicit (< 6 m) a bez bodů, které žádná linka
   nepoužívá, pokud je do 60 m použité nástupiště téže zastávky */
function markerPlats(){const out=[];for(const st of D.stops.values()){if(!st.city)continue;const used=st.plats.filter(p=>p.lines&&p.lines.size);
  for(const p of st.plats){if(!(p.lines&&p.lines.size)&&used.some(q=>dist([q.lat,q.lng],[p.lat,p.lng])<60))continue;if(out.some(q=>q.key===p.key&&dist([q.lat,q.lng],[p.lat,p.lng])<6))continue;out.push(p)}}return out}
window.__markerPlats41=markerPlats;
officialStops=markerPlats().map(p=>({id:p.id,name:p.name,rawName:p.name,direction:'',desc:'',lat:p.lat,lng:p.lng,request:p.request,key:p.key,lines:p.lineList}));
officialStopsPromise=Promise.resolve(officialStops);
try{plannerStops=officialStops.map(s=>({...s}));plannerStopsPromise=Promise.resolve(plannerStops)}catch(_){}
window.loadOfficialStops=loadOfficialStops=function(){return Promise.resolve(officialStops)};

/* skutečný počet sloupků: body zastávky blíž než 6 m od sebe jsou jedno nástupiště */
const distinctPlats=s=>{const out=[],used=s.plats.filter(p=>p.lines&&p.lines.size);for(const p of s.plats){if(!(p.lines&&p.lines.size)&&used.some(q=>dist([q.lat,q.lng],[p.lat,p.lng])<60))continue;if(!out.some(q=>dist([q.lat,q.lng],[p.lat,p.lng])<6))out.push(p)}return out};
function stopPopup(name,platform){
 const s=D.stop(name);if(!s)return '';
 const lines=s.lineList,city=lines.filter(n=>D.line(n)?.city),reg=lines.filter(n=>D.line(n)&&!D.line(n).city&&!D.line(n).train),trn=lines.filter(n=>D.line(n)?.train);
 const req=platform?platform.request:s.request;
 return '<div class="pop41"><div class="pop41-head"><div class="pop41-name">'+h(s.name)+'</div>'+(req?'<span class="pop41-req" title="Zastávka na znamení"><i class="fa-regular fa-hand"></i> na znamení</span>':'')+'</div>'
  +'<div class="pop41-meta">'+(distinctPlats(s).length>1&&!trn.length?distinctPlats(s).length+' nástupiště · ':'')+(trn.length&&!city.length&&!reg.length?'Železniční stanice':city.length?'Zastávka MHD Opava':'Regionální zastávka')+'</div>'
  +(city.length?'<div class="pop41-label">Linky MHD</div><div class="pop41-lines">'+city.map(n=>chip(n,'btn')).join('')+'</div>':'')
  +(reg.length?'<div class="pop41-label">Regionální linky</div><div class="pop41-lines">'+reg.map(n=>chip(n,'btn')).join('')+'</div>':'')
  +(trn.length?'<div class="pop41-label">Vlaky</div><div class="pop41-lines">'+trn.map(n=>chip(n,'btn')).join('')+'</div>':'')
  +trn.filter(n=>D.line(n).suspended).map(n=>'<div class="susp41"><i class="fa-solid fa-triangle-exclamation"></i> '+h(n)+': '+h(D.line(n).suspended)+'</div>').join('')
  +(lines.length?'':'<div class="pop41-meta">Linky nejsou v datech k dispozici.</div>')
  +'<div class="pop41-actions"><button type="button" class="pop41-nav" data-stop="'+h(s.name)+'" data-lat="'+(platform?platform.lat:s.lat)+'" data-lng="'+(platform?platform.lng:s.lng)+'" title="Vést k zastávce" aria-label="Vést k zastávce"><i class="fa-solid fa-person-walking-arrow-right"></i></button><button type="button" class="pop41-dep" data-stop="'+h(s.name)+'" title="Odjezdy" aria-label="Odjezdy"><i class="fa-regular fa-clock"></i></button></div></div>';
}
function bindPopup(el){
 if(!el)return;
 el.querySelectorAll('.l41.btn').forEach(b=>b.onclick=e=>{e.preventDefault();e.stopPropagation();try{map.closePopup()}catch(_){}window.openLine?.(String(b.dataset.line))});
 el.querySelectorAll('.pop41-dep').forEach(b=>b.onclick=e=>{e.preventDefault();e.stopPropagation();try{window.openDeparturesPanel?.(b.dataset.stop)}catch(_){}});
 el.querySelectorAll('.pop41-nav').forEach(b=>b.onclick=e=>{e.preventDefault();e.stopPropagation();try{map.closePopup()}catch(_){}document.querySelectorAll('.mapboxgl-popup.popup41-3d').forEach(p=>p.remove());window.__nav41?.start({name:b.dataset.stop,lat:Number(b.dataset.lat),lng:Number(b.dataset.lng)})});
}
window.renderOfficialStopMarkers=renderOfficialStopMarkers=function(){
 if(!stopMarkers)return;stopMarkers.clearLayers();const all=[],seen=new Map();
 const drawn=new Map();
 for(const s of officialStops){
  const dl=drawn.get(s.key)||[];if(dl.some(q=>dist(q,[s.lat,s.lng])<6))continue;dl.push([s.lat,s.lng]);drawn.set(s.key,dl);
  const order=seen.get(s.key)||0;seen.set(s.key,order+1);
  const icon=L.divIcon({className:'stop41-marker',html:'<span class="s41-dot'+(s.request?' req':'')+'"></span>',iconSize:[12,12],iconAnchor:[6,6]});
  const m=L.marker([s.lat,s.lng],{icon,zIndexOffset:300,title:s.name});
  m.bindPopup(()=>stopPopup(s.name,s),{maxWidth:320,className:'popup41',autoPanPaddingTopLeft:L.point(24,90),autoPanPaddingBottomRight:L.point(24,40)});
  m.on('popupopen',e=>bindPopup(e.popup.getElement()));
  m._minZoom=order===0?14:16;m._s41=s;all.push(m);
 }
 stopMarkers._allMarkers=all;try{updateStopMarkerVisibility()}catch(_){}
 try{const src=map3d?.getSource?.('stops-3d');if(src)src.setData(geojsonStops())}catch(_){}
};
renderOfficialStopMarkers();

/* Seznam zastávek linky v panelu Síť – přesná nástupiště a znamení dle (41). */
const oldStopsFor=window.stopsFor||stopsFor;
window.stopsFor=stopsFor=function(line,rev){const l=D.line(line);if(!l)return oldStopsFor(line,rev);return (rev?l.bp:l.fp).map(p=>({id:p.id,name:p.name,lat:p.lat,lng:p.lng,request:p.request}))};
const oldFill=window.fillStops||fillStops;
window.fillStops=fillStops=function(item,line,rev){
 oldFill(item,line,rev);
 const l=D.line(line);if(!l)return;const seq=rev?l.bp:l.fp,rows=item.querySelectorAll('.stop-list .stop-row');
 rows.forEach((r,i)=>{const p=seq[i];if(!p||r.querySelector('.row41'))return;const other=D.stop(p.name)?.lineList||[];const box=document.createElement('span');box.className='row41';box.innerHTML=chips(other.filter(n=>{const x=D.line(n);return x&&(x.city||(l.train?x.train:(!l.city&&!x.train)))}));r.appendChild(box)});
 const list=item.querySelector('.stop-list');if(list&&!list.querySelector('.jr41')){const u=timetableUrl(line);if(u)list.insertAdjacentHTML('afterbegin','<a class="jr41" href="'+h(u.href)+'" target="_blank" rel="noopener"><i class="fa-regular fa-calendar-days"></i><span><em>Jízdní řád linky <b>'+h(line)+'</b></em><small>'+h(u.src)+'</small></span><i class="fa-solid fa-arrow-up-right-from-square"></i></a>')}
};
/* Jízdní řád linky: ODIS (KODIS) má stránku každé linky včetně MHD Opava a vlaků S/R; dálkové vlaky přes IDOS. */
function timetableUrl(n){n=String(n);const l=D.line(n);
 if(/^\d{1,3}$/.test(n)||/^[SR]\d+/.test(n))return{href:'https://www.kodis.cz/lines/detail/'+encodeURIComponent(n.split('/')[0]),src:'ODIS · kodis.cz'};
 if(l&&l.train)return{href:'https://idos.cz/vlaky/odjezdy/?f='+encodeURIComponent('Opava východ'),src:'IDOS · odjezdy z Opavy východ'};
 return null}
try{renderNetwork()}catch(_){}

/* ---------- 2. Hledání ---------- */
const searchIndex=[...D.stops.values()].filter(s=>s.lines.size).map(s=>({s,f:D.fold(s.name),w:D.fold(s.name).split(/[^a-z0-9]+/).filter(Boolean)}));
function findStops(q,max=6){
 const f=D.fold(q).trim();if(!f)return[];const k=D.key(q),words=f.split(/[^a-z0-9]+/).filter(Boolean);
 return searchIndex.map(x=>{let sc=99;if(x.s.key===k)sc=0;else if(x.f.startsWith(f))sc=1;else if(x.w.some(w=>w.startsWith(f)))sc=2;else if(words.every(w=>x.w.some(v=>v.startsWith(w))))sc=3;else if(x.f.includes(f))sc=4;return{s:x.s,sc}}).filter(x=>x.sc<99).sort((a,b)=>a.sc-b.sc||(b.s.city-a.s.city)||b.s.lines.size-a.s.lines.size||a.s.name.localeCompare(b.s.name,'cs')).slice(0,max).map(x=>x.s);
}
/* Místa: místní názvy (Mendlák, Horňák…), obce a části obcí, ulice v okolních obcích */
const SX=window.MHD41_SEARCH||{local:[],places:[],streets:[]};
const PLX=[
 ...SX.local.map(([a,addr,desc,lat,lng])=>({type:'place',kind:'local',name:a,sub:desc+' · '+addr,idos:addr+', Opava',lat,lng,f:D.fold(a+' '+addr+' '+desc),fa:D.fold(a)})),
 ...SX.places.map(([n,k,lat,lng])=>({type:'place',kind:'village',name:n,sub:k,idos:n,lat,lng,f:D.fold(n),fa:D.fold(n)})),
 ...SX.streets.map(([st,city,lat,lng])=>({type:'place',kind:'street',name:st,sub:city,idos:st+', '+city,lat,lng,f:D.fold(st+' '+city),fa:D.fold(st)}))
];
/* vzdálenost od centra Opavy – adresy z Opavy a blízkých obcí mají v napovídání přednost */
const OP_C=[49.9385,17.9045],opDist=p=>dist(OP_C,[p.lat,p.lng]);
function findPlaces(q,max=6){
 const f=D.fold(q).trim();if(f.length<2)return[];const words=f.split(/[^a-z0-9]+/).filter(w=>w&&!/^\d+[a-z]?$/.test(w));if(!words.length)return[];
 const out=[];for(const p of PLX){let sc=99;const ws=p.f.split(/[^a-z0-9]+/);
  if(p.fa===f)sc=0;else if(p.fa.startsWith(f))sc=1;else if(words.every(w=>ws.some(v=>v.startsWith(w))))sc=2+(p.fa.startsWith(words[0])?0:1);
  if(sc<99)out.push({p,sc:sc+(p.kind==='local'?-0.5:p.kind==='village'?0:0.4)+opDist(p)/8000})}
 return out.sort((a,b)=>a.sc-b.sc||a.p.name.length-b.p.name.length).slice(0,max).map(x=>({...x.p,_sc:x.sc}));
}
const REGION_BB='17.35,49.68,18.35,50.15';
async function photon(q,limit=6,signal){
 const r=await fetch('https://photon.komoot.io/api/?limit='+limit+'&bbox='+REGION_BB+'&lat=49.938&lon=17.902&q='+encodeURIComponent(q),{signal});if(!r.ok)throw Error('geo');
 const j=await r.json();const seen=new Set();
 return (j.features||[]).map(x=>{const p=x.properties||{},c=x.geometry?.coordinates||[];const nm=p.name&&p.name!==p.street?p.name:[p.street,p.housenumber].filter(Boolean).join(' ')||p.name;const sub=[p.name&&p.street?[p.street,p.housenumber].filter(Boolean).join(' '):'',p.district,p.city||p.locality||p.county].filter(Boolean).join(', ');return{type:'place',kind:'online',name:nm||q,sub,idos:[p.street?[p.street,p.housenumber].filter(Boolean).join(' '):(nm||q),p.city||p.locality||p.county].filter(Boolean).join(', '),lat:c[1],lng:c[0]}}).filter(p=>Number.isFinite(p.lat)&&!seen.has(p.name+p.sub)&&seen.add(p.name+p.sub));
}
function findLines(q){const t=String(q).trim();if(!/^\d{1,3}$/.test(t))return[];return Object.keys(D.lines).filter(n=>n.startsWith(t)).sort((a,b)=>Number(a)-Number(b)).slice(0,4)}

function attachSuggest(id,{lines=false,onPick}={}){
 const old=$(id);if(!old)return null;
 const input=old.cloneNode(true);old.replaceWith(input);input.setAttribute('autocomplete','off');input.setAttribute('spellcheck','false');
 const field=input.closest('.search-field');field?.querySelectorAll('.search-suggest-box,.sug41').forEach(x=>x.remove());
 const box=document.createElement('div');box.className='sug41';box.hidden=true;(field||input.parentNode).appendChild(box);
 let items=[],active=-1;
 const close=()=>{box.hidden=true;box.innerHTML='';items=[];active=-1};
 const mark=i=>{active=i;box.querySelectorAll('.sug41-item').forEach((el,j)=>el.classList.toggle('active',j===i))};
 const pick=i=>{const it=items[i];if(!it)return;close();if(it.type==='stop'){input.value=it.s.name;input.dataset.lat=it.s.lat;input.dataset.lng=it.s.lng;input.dataset.stop=it.s.key}else if(it.type==='place'){input.value=it.name+(it.kind==='street'||it.kind==='online'?(it.sub?', '+it.sub.split(',').pop().trim():''):'');input.dataset.lat=it.lat;input.dataset.lng=it.lng;if(it.idos)input.dataset.idos=it.idos}onPick?.(it,input)};
 let ctl=null,tmr=0;
 const itemHTML=(it,i)=>it.type==='line'
   ?'<div class="sug41-item" data-i="'+i+'">'+chip(it.n,'big')+'<span class="sug41-main"><strong>Linka '+h(it.n)+'</strong><small>'+h(D.line(it.n).dir)+'</small></span></div>'
   :it.type==='place'?'<div class="sug41-item" data-i="'+i+'"><span class="sug41-ico '+it.kind+'"><i class="fa-solid '+({local:'fa-star',village:'fa-house-chimney',street:'fa-road',online:'fa-map-pin'}[it.kind])+'"></i></span><span class="sug41-main"><strong>'+h(it.name)+'</strong><small>'+h(it.sub||'')+'</small></span></div>'
   :'<div class="sug41-item" data-i="'+i+'"><span class="sug41-ico"><i class="fa-solid fa-location-dot"></i></span><span class="sug41-main"><strong>'+h(it.s.name)+'</strong><small class="sug41-lines">'+chips(it.s.lineList,8)+'</small></span>'+(it.s.request?'<span class="sug41-req" title="Na znamení"><i class="fa-regular fa-hand"></i></span>':'')+'</div>';
 const paint=()=>{if(!items.length){box.innerHTML='<div class="sug41-empty">Nic nenalezeno – stiskněte Enter pro hledání adresy</div>';box.hidden=false;return}
  box.innerHTML=items.map(itemHTML).join('');box.hidden=false;
  box.querySelectorAll('.sug41-item').forEach(el=>{el.onmousedown=e=>{e.preventDefault();pick(Number(el.dataset.i))}})};
 function render(){
  const q=input.value;delete input.dataset.lat;delete input.dataset.lng;delete input.dataset.stop;delete input.dataset.idos;
  if(q.trim().length<1){close();return}
  const places=findPlaces(q,6),fq=D.fold(q).trim(),stops41=findStops(q,places.length?5:7),exactStop=stops41.some(s=>D.fold(s.name)===fq);
  /* místní názvy a obce vždy nahoře; stejnojmenná ulice jen tehdy, když neexistuje stejnojmenná zastávka */
  const top=places.filter(p=>p.kind==='local'||(D.fold(p.name)===fq&&(p.kind==='village'||!exactStop)));
  const addr=/\d/.test(q)||!stops41.length;let rest=places.filter(p=>!top.includes(p));
  const compose=()=>{const st=stops41.map(s=>({type:'stop',s})),ln=lines?findLines(q).map(n=>({type:'line',n})):[];rest.sort((a,b)=>a._sc-b._sc);
   items=addr?[...top,...ln,...rest,...st]:[...top,...ln,...st,...rest]};
  compose();paint();
  /* online adresy (ulice s číslem, firmy, místa) z celého Opavska */
  clearTimeout(tmr);ctl?.abort();
  if(q.trim().length>=3){tmr=setTimeout(async()=>{ctl=new AbortController();try{const on=await photon(q,8,ctl.signal);if(input.value!==q)return;const have=new Set(items.map(x=>D.fold((x.name||x.s?.name||'')+(x.sub||''))));
   /* online výsledky se řadí mezi ostatní místa podle vzdálenosti od Opavy (ne na konec seznamu) */
   const add=on.filter(p=>!have.has(D.fold(p.name+p.sub))).map(p=>({...p,_sc:(/\d/.test(q)?0.9:1.6)+opDist(p)/8000}));if(add.length){rest=[...rest,...add].slice(0,10);compose();paint()}}catch(_){}},350)}
  return;
  box.innerHTML=items.map((it,i)=>it.type==='line'
   ?'<div class="sug41-item" data-i="'+i+'">'+chip(it.n,'big')+'<span class="sug41-main"><strong>Linka '+h(it.n)+'</strong><small>'+h(D.line(it.n).dir)+'</small></span></div>'
   :'<div class="sug41-item" data-i="'+i+'"><span class="sug41-ico"><i class="fa-solid fa-location-dot"></i></span><span class="sug41-main"><strong>'+h(it.s.name)+'</strong><small class="sug41-lines">'+chips(it.s.lineList,8)+'</small></span>'+(it.s.request?'<span class="sug41-req" title="Na znamení"><i class="fa-regular fa-hand"></i></span>':'')+'</div>').join('');
  box.hidden=false;
  box.querySelectorAll('.sug41-item').forEach(el=>{el.onmousedown=e=>{e.preventDefault();pick(Number(el.dataset.i))}});
 }
 input.addEventListener('input',render);
 input.addEventListener('focus',()=>{if(input.value.trim()&&!input.dataset.stop)render()});
 input.addEventListener('blur',()=>setTimeout(close,120));
 input.addEventListener('keydown',e=>{
  if(!box.hidden&&items.length&&(e.key==='ArrowDown'||e.key==='ArrowUp')){e.preventDefault();mark((active+(e.key==='ArrowDown'?1:-1)+items.length)%items.length);return}
  if(e.key==='Escape'){close();return}
  if(e.key==='Enter'){e.preventDefault();if(!box.hidden&&active>=0){pick(active);return}close();input.dispatchEvent(new CustomEvent('search41-submit'))}
 });
 return input;
}

function focusStop(s){
 if(!s)return;if(is3dOn()){focus3d(s);return}
 try{if(!map.hasLayer(stopMarkers))map.addLayer(stopMarkers)}catch(_){}
 map.setView([s.lat,s.lng],17,{animate:false});{const sh=sheetH();if(sh)map.panBy([0,sh/2],{animate:false})}
 setTimeout(()=>{const m=(stopMarkers._allMarkers||[]).find(x=>x._s41?.key===s.key);try{updateStopMarkerVisibility()}catch(_){}if(m&&m._map){m.openPopup()}else{const p=L.popup({className:'popup41',maxWidth:320}).setLatLng([s.lat,s.lng]).setContent(stopPopup(s.name)).openOn(map);bindPopup(p.getElement())}},420);
}
function stopCard(s,extra=''){return '<div class="card41 stop" data-stop="'+h(s.key)+'"><button type="button" class="card41-nav" title="Vést k zastávce" aria-label="Vést k zastávce '+h(s.name)+'"><i class="fa-solid fa-person-walking-arrow-right"></i></button><div class="card41-top"><span class="card41-ico"><i class="fa-solid fa-location-dot"></i></span><span class="card41-name">'+h(s.name)+'</span>'+(s.request?'<span class="sug41-req" title="Na znamení"><i class="fa-regular fa-hand"></i></span>':'')+extra+'</div><div class="card41-lines">'+(chips(s.lineList,14)||'<span class="muted41">bez linek</span>')+'</div></div>'}
const fromAddr=loc=>loc&&Number.isFinite(+loc.lat)&&!/moje|aktu[aá]ln[ií] poloh|m[aá] poloha/i.test(loc.label||'')?{lat:+loc.lat,lng:+loc.lng,label:String(loc.label||'').replace(/\s*\(.*\)$/,'')}:null;
function bindCards(box,loc){box.querySelectorAll('.card41.stop').forEach(c=>c.onclick=e=>{if(e.target.closest('.card41-nav')){e.stopPropagation();const s=D.stops.get(c.dataset.stop);if(s)window.__nav41?.start({name:s.name,lat:s.lat,lng:s.lng,from:fromAddr(loc)});return}const b=e.target.closest('.l41[data-line]');if(b){e.stopPropagation();window.openLine?.(String(b.dataset.line));return}focusStop(D.stops.get(c.dataset.stop))})}

function nearestStops(lat,lng,n=3){return [...D.stops.values()].filter(s=>s.city).map(s=>({s,d:Math.min(...s.plats.map(p=>dist([lat,lng],[p.lat,p.lng])))})).sort((a,b)=>a.d-b.d).slice(0,n)}

const UNKNOWN41=t=>'Toto místo neznáme'+(t?' („'+t+'“)':'')+'. Zkuste zadat zastávku, ulici nebo obec jinak.';
const userMsg41=(e,fb)=>{const m=e&&e.message||'';return !m||e instanceof ReferenceError||e instanceof TypeError||e instanceof SyntaxError||/is not defined|undefined|null|Cannot read/i.test(m)?fb:m};
async function geocode(text){
 const t=String(text||'').trim();if(!t)throw Error('Zadejte zastávku, adresu nebo místo.');
 const pl=findPlaces(t,1)[0];if(pl&&(pl.kind==='local'||D.fold(pl.name)===D.fold(t)||D.fold(t).startsWith(D.fold(pl.name))))return{lat:pl.lat,lng:pl.lng,label:pl.name+(pl.sub?' ('+pl.sub+')':''),idos:pl.idos};
 try{const on=(await photon(t,6)).sort((a,b)=>opDist(a)-opDist(b)).slice(0,1);if(on[0])return{lat:on[0].lat,lng:on[0].lng,label:[on[0].name,on[0].sub].filter(Boolean).join(', '),idos:on[0].idos}}catch(_){}
 if(pl)return{lat:pl.lat,lng:pl.lng,label:pl.name+(pl.sub?' ('+pl.sub+')':''),idos:pl.idos};
 try{const g=await geocodeAddress(t);if(g&&Number.isFinite(g.lat))return{lat:g.lat,lng:g.lng,label:String(g.label||t).split(',').slice(0,2).join(','),idos:t}}catch(_){}
 if(typeof window.resolvePlaceInput==='function'){try{const g=await window.resolvePlaceInput(t);if(g&&Number.isFinite(g.lat)&&Number.isFinite(g.lng))return{lat:g.lat,lng:g.lng,label:String(g.label||t).split(',').slice(0,2).join(',')}}catch(_){}}
 throw Error(UNKNOWN41(t));
}
async function placeFrom(input){
 const v=input.value.trim();
 if(input.dataset.stop&&D.stops.has(input.dataset.stop)){const s=D.stops.get(input.dataset.stop);return{lat:s.lat,lng:s.lng,label:s.name,stop:s}}
 const s=D.stop(v);if(s&&s.lines.size)return{lat:s.lat,lng:s.lng,label:s.name,stop:s};
 if(input.dataset.lat&&input.dataset.lng)return{lat:Number(input.dataset.lat),lng:Number(input.dataset.lng),label:v||'Moje poloha',idos:input.dataset.idos||''};
 return geocode(v);
}
const status=(id,t,err)=>{try{setSearchStatus(id,t,err)}catch(_){const e=$(id);if(e)e.textContent=t||''}};

/* Záložka Zastávky: zastávka / linka / adresa → nejbližší zastávky. */
const stopInput=attachSuggest('stop-address',{lines:true,onPick:(it,input)=>{if(it.type==='line'){input.value='';window.openLine?.(String(it.n));return}if(it.type==='place'){runNearest();return}showStop(it.s)}});
if(stopInput)stopInput.placeholder='Zastávka, linka nebo adresa';
function showStop(s){const box=$('nearest-results');if(box){box.innerHTML='<div class="list41-title">Zastávka</div>'+stopCard(s);bindCards(box)}status('nearest-status','');focusStop(s)}
async function runNearest(){
 const input=$('stop-address'),box=$('nearest-results');if(!input||!box)return;
 const v=input.value.trim();box.innerHTML='';
 try{
  if(/^\d{1,3}$/.test(v)&&D.line(v)){window.openLine?.(v);return}
  const exact=input.dataset.stop?D.stops.get(input.dataset.stop):D.stop(v);
  if(exact&&exact.lines.size){showStop(exact);return}
  status('nearest-status','Hledám místo…');
  const loc=input.dataset.lat&&input.dataset.lng?{lat:Number(input.dataset.lat),lng:Number(input.dataset.lng),label:v}:await geocode(v);
  const near=nearestStops(loc.lat,loc.lng,3);
  box.innerHTML='<div class="list41-title">Nejbližší zastávky</div>'+near.map(x=>stopCard(x.s,'<span class="card41-dist">'+fmtDist(x.d)+'</span>')).join('');bindCards(box,loc);
  status('nearest-status',loc.label?'Okolí: '+loc.label:'');
  try{clearHighlights?.()}catch(_){}
  if(is3dOn())map3d.flyTo({center:[loc.lng,loc.lat],zoom:16.2,duration:900});else map.setView([loc.lat,loc.lng],16,{animate:true});
 }catch(e){status('nearest-status',userMsg41(e,'Toto místo neznáme. Zkuste zadat zastávku, ulici nebo obec jinak.'),true)}
}
window.runNearestSearch=runNearestSearch=runNearest;
stopInput?.addEventListener('search41-submit',runNearest);
const nearBtn=$('find-nearest');if(nearBtn){nearBtn.onclick=e=>{e.preventDefault();runNearest()};nearBtn.innerHTML='<i class="fa-solid fa-magnifying-glass"></i> Hledat'}
$('stop-my-location')&&($('stop-my-location').onclick=()=>{try{useMyLocation('stop-address','nearest-status')}catch(_){}});

/* ---------- Plánovač spojení nad daty (41) ---------- */
const PAT=[];const byKey=new Map();
for(const l of Object.values(D.lines)){if(night(l.num)||l.suspended)continue;[l.fp,l.bp,...(l.variants||[])].forEach((seq,dir)=>{if(seq.length<2)return;const cum=[0];for(let i=1;i<seq.length;i++)cum.push(cum[i-1]+dist([seq[i-1].lat,seq[i-1].lng],[seq[i].lat,seq[i].lng]));const P={id:PAT.length,line:l.num,dir,seq,keys:seq.map(p=>p.key),cum};PAT.push(P);P.keys.forEach((k,i)=>{if(!byKey.has(k))byKey.set(k,[]);byKey.get(k).push([P,i])})})}
/* Pěší přestupy mezi blízkými zastávkami (např. Východní nádraží ↔ Opava východ) */
const NEAR=new Map();{const grid=new Map(),cell=0.004,ks=[...byKey.keys()].map(k=>D.stops.get(k)).filter(Boolean);
 for(const s of ks)for(const p of s.plats){const g=Math.floor(p.lat/cell)+':'+Math.floor(p.lng/cell);if(!grid.has(g))grid.set(g,new Set());grid.get(g).add(s)}
 for(const s of ks){const out=new Map();for(const p of s.plats){const gi=Math.floor(p.lat/cell),gj=Math.floor(p.lng/cell);for(let a=-1;a<=1;a++)for(let b=-1;b<=1;b++)for(const t of grid.get((gi+a)+':'+(gj+b))||[]){if(t===s)continue;const d=Math.min(...t.plats.map(q=>dist([p.lat,p.lng],[q.lat,q.lng])));if(d<=350&&(!out.has(t.key)||out.get(t.key)>d))out.set(t.key,d)}}if(out.size)NEAR.set(s.key,[...out.entries()])}}
const RIDE_V=6.2,DWELL=25,TRANSFER=240;
const SPEED={city:[6.2,25],regional:[9.5,25],train:[16,50]},walkSec=m=>m*1.25/1.3,rideSec=(P,a,b)=>{const sp=SPEED[D.line(P.line)?.kind]||SPEED.city;return (P.cum[b]-P.cum[a])*1.12/sp[0]+(b-a)*sp[1]};
/* Řídké linky (málo spojů za den) dostanou penalizaci, aby nevytlačily běžné linky. */
const RARE=P=>{const t=D.line(P.line)?.trips||0;return t&&t<12?900:0};
/* Ve městě mají přednost linky MHD: regionální autobus a vlak dostanou penalizaci, takže je planner nabídne
   jen tam, kde MHD nejede nebo je výrazně pomalejší. */
const KINDPEN=P=>{const l=D.line(P.line);return !l||l.city?0:l.train?1200:900};
function plan(origins,dests,maxT){
 const destW=new Map(dests.map(d=>[d.key,d.walk])),destO=new Map(dests.map(d=>[d.key,d])),best=new Map();
 /* chůze se počítá k nástupišti ve směru dané linky (ne k nejbližšímu sloupku zastávky, který může být přes silnici) */
 const wk=(o,p)=>o&&o.pl&&p?dist(o.pl,[p.lat,p.lng])*1.15:null;
 const add=(legs,o,dKey)=>{const L0=legs[0],Ln=legs.at(-1),walkIn=wk(o,L0.P.seq[L0.a])??o.walk,walkOut=wk(destO.get(dKey),Ln.P.seq[Ln.b])??destW.get(dKey);let t=walkSec(walkIn)+walkSec(walkOut)+(legs.length-1)*TRANSFER+legs.reduce((a,g)=>a+walkSec(g.walk||0),0);for(const g of legs)t+=rideSec(g.P,g.a,g.b);const cost=t+legs.reduce((a,g)=>a+RARE(g.P)+KINDPEN(g.P),0);const sig=legs.map(g=>g.P.line+':'+g.P.keys[g.a]+'>'+g.P.keys[g.b]).join('|');const lineSig=legs.map(g=>g.P.line).join('>');const c={legs,walkIn,walkOut,time:t,cost,transfers:legs.length-1,stops:legs.reduce((a,g)=>a+g.b-g.a,0),origin:o,destKey:dKey,sig,lineSig};const prev=best.get(lineSig);if(!prev||prev.cost>cost)best.set(lineSig,c)};
 function extend(legs,o,depth,used){
  const last=legs.at(-1),P=last.P;
  if(depth>=maxT)return;
  for(let t=last.a+1;t<P.seq.length;t++){
   const tk=P.keys[t];if(destW.has(tk))continue;
   for(const [k2,w] of [[tk,0],...(NEAR.get(tk)||[])])for(const [Q,qi] of byKey.get(k2)||[]){if(used.has(Q.line))continue;
    for(let j=qi+1;j<Q.seq.length;j++)if(destW.has(Q.keys[j]))add([...legs.slice(0,-1),{...last,b:t},{P:Q,a:qi,b:j,walk:w}],o,Q.keys[j]);
    if(depth+1<maxT){const nu=new Set(used);nu.add(Q.line);extend([...legs.slice(0,-1),{...last,b:t},{P:Q,a:qi,b:qi,walk:w}],o,depth+1,nu)}
   }
  }
 }
 for(const o of origins)for(const [P,i] of byKey.get(o.key)||[]){
  for(let j=i+1;j<P.seq.length;j++)if(destW.has(P.keys[j]))add([{P,a:i,b:j}],o,P.keys[j]);
  if(maxT>0)extend([{P,a:i,b:i}],o,0,new Set([P.line]));
 }
 return [...best.values()].filter(c=>c.legs.every(g=>g.b>g.a));
}
function variants(origins,dests){
 let all=plan(origins,dests,1);
 if(!all.length)all=plan(origins,dests,2);
 all.sort((a,b)=>a.cost-b.cost);
 const out=[],seen=new Set();
 for(const c of all){const k=c.legs.map(g=>g.P.line).join('>');if(seen.has(k))continue;if(out.length&&c.cost>out[0].cost*1.9+300)continue;seen.add(k);out.push(c);if(out.length>=4)break}
 return out;
}
function candidates(place){
 if(place.stop)return[{key:place.stop.key,walk:0,s:place.stop}];
 const pl=[place.lat,place.lng];
 return [...D.stops.values()].filter(s=>byKey.has(s.key)).map(s=>({key:s.key,s,pl,walk:Math.min(...s.plats.map(p=>dist([place.lat,place.lng],[p.lat,p.lng])))})).filter(x=>x.walk<1500).sort((a,b)=>a.walk-b.walk).slice(0,8);
}

function routeSlice(line,seg){
 /* Úsek trasy mezi zastávkami. Zastávky se promítají na úsečky trasy (zjednodušené regio a vlakové trasy mají
    vrcholy daleko od sebe); pořadí po trase hlídá dynamické programování přes kandidátní průměty, takže smyčky
    ani dvojí průjezd stejným místem úsek nezamotají. Zastávku, která na trase v daném pořadí není, lze vynechat.
    Chybí-li trasa v daném směru, použije se obrácená. */
 const routes=(typeof gpxRoutes!=='undefined'&&gpxRoutes[String(line)])||[];if(seg.length<2)return seg.map(p=>[p.lat,p.lng]);
 const K=111320,cl=Math.cos(seg[0].lat*Math.PI/180),XY=q=>[q[1]*K*cl,q[0]*K],SKIP=350,maxSkip=Math.max(1,Math.floor(seg.length/4));
 const chord=[0];for(let k=1;k<seg.length;k++)chord.push(chord[k-1]+dist([seg[k-1].lat,seg[k-1].lng],[seg[k].lat,seg[k].lng]));
 let best=null;
 const tryRoute=(pts,extra)=>{const n=pts.length;if(n<2)return;const xy=pts.map(XY),cum=[0];for(let i=1;i<n;i++)cum.push(cum[i-1]+Math.hypot(xy[i][0]-xy[i-1][0],xy[i][1]-xy[i-1][1]));
  const C=seg.map(p=>{const [px,py]=XY([p.lat,p.lng]);const E=[];
   for(let i=0;i<n-1;i++){const [ax,ay]=xy[i],dx=xy[i+1][0]-ax,dy=xy[i+1][1]-ay,l2=dx*dx+dy*dy;let t=l2?((px-ax)*dx+(py-ay)*dy)/l2:0;t=Math.max(0,Math.min(1,t));E.push({i,t,d:Math.hypot(ax+dx*t-px,ay+dy*t-py),pos:cum[i]+t*Math.sqrt(l2)})}
   return E.filter((x,i)=>x.d<260&&(i===0||x.d<=E[i-1].d)&&(i===E.length-1||x.d<=E[i+1].d)).sort((a,b)=>a.d-b.d).slice(0,6)});
  /* stav: kandidát posledně umístěné zastávky (k = její index) */
  let st=C[0].map(c=>({c,k:0,cost:c.d,skip:0,back:null}));if(!st.length)return;
  for(let k=1;k<seg.length;k++){const nx=[];
   for(const c of C[k]){let b=null;for(const q of st){if(c.pos<q.c.pos-5)continue;const run=c.pos-q.c.pos,want=chord[k]-chord[q.k],cost=q.cost+c.d+0.15*Math.max(0,run-1.4*want-150);if(!b||cost<b.cost)b={c,k,cost,skip:q.skip,back:q}}if(b)nx.push(b)}
   for(const q of st)if(q.skip<maxSkip)nx.push({...q,cost:q.cost+SKIP,skip:q.skip+1,back:q.back,c:q.c,k:q.k,self:q});
   st=nx.map(x=>x.self?{c:x.c,k:x.k,cost:x.cost,skip:x.skip,back:x.self.back,first:x.self.first}:x).sort((a,b)=>a.cost-b.cost).slice(0,24);if(!st.length)return}
  const e=st[0],total=e.cost+extra;if(best&&total>=best.score)return;
  let a=e;while(a.back)a=a.back;if(e.c.pos<=a.c.pos)return;
  const at=c=>[pts[c.i][0]+(pts[c.i+1][0]-pts[c.i][0])*c.t,pts[c.i][1]+(pts[c.i+1][1]-pts[c.i][1])*c.t];
  const out=[at(a.c)];for(let i=a.c.i+1;i<=e.c.i;i++)out.push(pts[i]);out.push(at(e.c));
  if(a.k>0)out.unshift([seg[0].lat,seg[0].lng]);if(e.k<seg.length-1)out.push([seg.at(-1).lat,seg.at(-1).lng]);
  best={score:total,pts:out}};
 for(const r of routes)tryRoute(r.points||[],0);
 if(!best||best.score>seg.length*60)for(const r of routes)tryRoute([...(r.points||[])].reverse(),120+seg.length*20);
 return best?best.pts:seg.map(p=>[p.lat,p.lng]);
}
window.__plan41={PAT,variants,candidates,routeSlice:(...a)=>routeSlice(...a)};
/* ---------- Spojení podle jízdních řádů (Connection Scan nad spoji daného dne) ---------- */
/* linky, které na sebe na zastávce čekají (garantovaný přestup) */
const GUAR41=(l1,l2,key)=>key==='divadlo'&&((l1==='201'&&l2==='203')||(l1==='203'&&l2==='201'));
window.__guar41=GUAR41;
const CSA=(function(){
 const days=new Map();
 const fmtT=m=>{m=Math.round(m);const d=Math.floor(m/1440);m=((m%1440)+1440)%1440;return Math.floor(m/60)+':'+String(m%60).padStart(2,'0')+(d>0?' (+'+d+')':'')};
 /* spoje dne di (a přes půlnoc ze sousedních dnů) jako seřazený seznam přípojů */
 function conns(di){if(days.has(di))return days.get(di);const TT=window.__tt41;const sIdx=new Map(),keys=[];const si=k=>{let i=sIdx.get(k);if(i==null){i=keys.length;sIdx.set(k,i);keys.push(k)}return i};
  const C=[];const trips=[];
  for(const T of TT.trips)for(const [d,off] of [[di-1,-1440],[di,0],[di+1,1440]]){if(D.line(T.line)?.suspended)break;if(!TT.on(T.si,d))continue;if(off<0&&T.t1<1440)continue;const ti=trips.length;trips.push({T,off,city:!!D.line(T.line)?.city});
   for(let i=0;i<T.keys.length-1;i++)C.push([T.dep[i]+off,T.arr[i+1]+off,si(T.keys[i]),si(T.keys[i+1]),ti,i])}
  C.sort((a,b)=>a[0]-b[0]||a[1]-b[1]);
  const n=C.length,cDep=new Float64Array(n),cArr=new Float64Array(n),cFrom=new Int32Array(n),cTo=new Int32Array(n),cTrip=new Int32Array(n),cIdx=new Int32Array(n);
  C.forEach((c,i)=>{cDep[i]=c[0];cArr[i]=c[1];cFrom[i]=c[2];cTo[i]=c[3];cTrip[i]=c[4];cIdx[i]=c[5]});
  const foot=keys.map(k=>(NEAR.get(k)||[]).map(([k2,d])=>[sIdx.get(k2),d]).filter(x=>x[0]!=null));
  const r={n,cDep,cArr,cFrom,cTo,cTrip,cIdx,keys,sIdx,trips,foot};days.set(di,r);return r}
 const walkMin=m=>walkSec(m)/60;
 /* nejdřívější příjezd z t0; cityOnly = jen MHD */
 function scan(G,origins,dests,t0,cityOnly){
  const S=new Float64Array(G.keys.length).fill(Infinity),J=new Array(G.keys.length),enter=new Int32Array(G.trips.length).fill(-1);
  const relax=(s,t,via)=>{if(t<S[s]){S[s]=t;J[s]=via}};
  for(const o of origins){const s=G.sIdx.get(o.key);if(s!=null)relax(s,t0+walkMin(o.walk),{origin:o})}
  for(const o of origins){const s=G.sIdx.get(o.key);if(s==null||!isFinite(S[s]))continue;for(const [s2,d] of G.foot[s])relax(s2,S[s]+walkMin(d)+1,{walk:s,d})}
  const dIdx=dests.map(d=>[G.sIdx.get(d.key),walkMin(d.walk),d]).filter(x=>x[0]!=null);
  let best=Infinity;
  let lo=0,hi=G.n;while(lo<hi){const mid=(lo+hi)>>1;if(G.cDep[mid]<t0)lo=mid+1;else hi=mid}
  for(let i=lo;i<G.n;i++){const dep=G.cDep[i];if(dep>best)break;if(dep>t0+600)break;const tr=G.cTrip[i];if(cityOnly&&!G.trips[tr].city)continue;
   if(enter[tr]<0){const f=G.cFrom[i];if(!(S[f]<=dep))continue;if(J[f]?.ride&&J[f].trip!==tr&&S[f]+1>dep){if(!(S[f]<=dep+3&&GUAR41(G.trips[J[f].trip].T.line,G.trips[tr].T.line,G.keys[f])))continue}enter[tr]=i}
   const to=G.cTo[i],a=G.cArr[i];
   if(a<S[to]){S[to]=a;J[to]={ride:true,trip:tr,from:enter[tr],to:i};for(const [s2,d] of G.foot[to])relax(s2,a+walkMin(d)+1,{walk:to,d});for(const [s,w] of dIdx)if(s===to&&a+w<best)best=a+w}}
  let bs=-1,bt=Infinity,bd=null;for(const [s,w,d] of dIdx)if(S[s]+w<bt){bt=S[s]+w;bs=s;bd=d}
  if(bs<0||!isFinite(bt))return null;
  /* zpětné sestavení cesty */
  const legs=[];let s=bs,guard=0,walkIn=0;
  while(J[s]&&guard++<40){const j=J[s];if(j.origin){walkIn=j.origin.walk;break}
   if(j.walk!=null){legs.unshift({walk:j.d,fromS:j.walk,toS:s});s=j.walk;continue}
   const c0=j.from,c1=j.to,T=G.trips[j.trip];legs.unshift({ride:true,T:T.T,off:T.off,i:G.cIdx[c0],j:G.cIdx[c1]+1,dep:G.cDep[c0],arr:G.cArr[c1]});s=G.cFrom[c0]}
  return{legs,walkIn,walkOut:bd.walk,arrival:bt,G}}
 /* úsek spoje -> vzor linky s nástupišti ve správném směru (pro kreslení a seznam zastávek) */
 function patFor(T,i,j){const ks=T.keys.slice(i,j+1);let best=null;
  for(const P of PAT){if(P.line!==T.line)continue;for(let a=0;a<P.keys.length;a++){if(P.keys[a]!==ks[0])continue;let b=a,k=1,match=1;
    for(let x=a+1;x<P.keys.length&&k<ks.length;x++){if(P.keys[x]===ks[k]){k++;match++;b=x}}
    if(k===ks.length){const sc=match-(b-a+1-ks.length)*0.5;if(!best||sc>best.sc)best={sc,P,a,b}}}}
  if(best)return best;
  const seq=ks.map(k=>{const st=D.stops.get(k);return st?st.plats[0]:null}).filter(Boolean);const cum=[0];for(let x=1;x<seq.length;x++)cum.push(cum[x-1]+dist([seq[x-1].lat,seq[x-1].lng],[seq[x].lat,seq[x].lng]));
  return{P:{line:T.line,seq,keys:seq.map(p=>p.key),cum,dir:0},a:0,b:seq.length-1}}
 /* zbytečné přestupy pěšky: když další spoj projíždí zastávkou, kterou už předchozí spoj projel
    (a stihne se), přestoupí se tam – bez chůze a bez zajížďky tam a zpět */
 function tidyLegs(L){
  const out=[...L];
  for(let changed=true,guard=0;changed&&guard<6;guard++){changed=false;
   const rides=out.map((x,i)=>x.ride?i:-1).filter(i=>i>=0);
   for(let r=1;r<rides.length;r++){const ia=rides[r-1],ib=rides[r],A=out[ia],B=out[ib];
    let best=null;
    for(let k=B.i;k<B.j;k++){const key=B.T.keys[k],bd=B.T.dep[k]+B.off;
     for(let m=A.j;m>A.i;m--){if(A.T.keys[m]!==key)continue;if(k===B.i&&m===A.j)continue;const aa=A.T.arr[m]+A.off;if(aa>bd)continue;
      const sc=k*1000-m;if(!best||sc>best.sc)best={sc,k,m};break}}
    if(best){out[ia]={...A,j:best.m,arr:A.T.arr[best.m]+A.off};out[ib]={...B,i:best.k,dep:B.T.dep[best.k]+B.off};out.splice(ia+1,ib-ia-1);changed=true;break}
   }}
  return out}
 function toPlan(r,from,to){
  try{r={...r,legs:tidyLegs(r.legs)}}catch(_){}
  const legs=[];let pendingWalk=0,stops=0;
  for(const L of r.legs){if(!L.ride){pendingWalk+=L.walk;continue}const pf=patFor(L.T,L.i,L.j);legs.push({P:pf.P,a:pf.a,b:pf.b,walk:pendingWalk,dep:L.dep,arr:L.arr,trip:L.T});pendingWalk=0;stops+=pf.b-pf.a}
  if(!legs.length)return null;
  const first=legs[0].P.seq[legs[0].a],last=legs.at(-1).P.seq[legs.at(-1).b];
  /* pěší úseky stejně jako při hledání (k nástupišti ve směru linky) */
  const walkIn=r.walkIn||0,walkOut=(r.walkOut||0)+pendingWalk;
  for(let k=1;k<legs.length;k++)if(legs[k].P.line===legs[k-1].P.line)return null;
  const leave=legs[0].dep-walkMin(walkIn),arrive=legs.at(-1).arr+walkMin(walkOut);
  return{legs,walkIn,walkOut,time:(arrive-leave)*60,cost:(arrive-leave)*60,transfers:legs.length-1,stops,leave,arrive,timed:true,sig:legs.map(g=>g.trip.id+':'+g.a).join('|'),lineSig:legs.map(g=>g.P.line).join('>')}}
 /* až 4 nejbližší spojení od času t0 (minuty dne di); ve městě přednost MHD */
 function search(origins,dests,from,to,date,count=4){
  const TT=window.__tt41;if(!TT||!TT.valid(date))return null;
  const di=TT.dayIdx(date),G=conns(di);let t=TT.mins(date);let out=[];const seen=new Set();
  const dom=o=>o.filter(c=>!o.some(x=>x!==c&&x.leave>=c.leave&&x.arrive<=c.arrive&&x.transfers<=c.transfers&&(x.leave>c.leave||x.arrive<c.arrive||x.transfers<c.transfers)));
  for(let k=0;k<count*4&&out.length<count;k++){
   const raw=[scan(G,origins,dests,t,false),scan(G,origins,dests,t,true)].filter(Boolean);
   if(!raw.length)break;
   const cand=raw.map(r=>toPlan(r,from,to)).filter(Boolean);cand.forEach(c=>c.di=di);
   if(!cand.length){t=Math.min(...raw.map(r=>(r.legs.find(l=>l.ride)?.dep??t)))+1;continue}
   /* MHD má přednost, pokud přijede nejvýš o 10 min později */
   cand.sort((a,b)=>(a.arrive+(a.legs.some(g=>!D.line(g.P.line)?.city)?10:0))-(b.arrive+(b.legs.some(g=>!D.line(g.P.line)?.city)?10:0)));
   for(const c of cand)if(!seen.has(c.sig)){seen.add(c.sig);out.push(c)}
   out=dom(out);
   t=Math.min(...cand.map(c=>c.legs[0].dep))+1-walkMin(cand[0].walkIn)+0.01;
   t=Math.max(t,Math.min(...cand.map(c=>c.leave))+1)}
  /* vyřadit spojení, která jsou v odjezdu, příjezdu i přestupech horší než jiné */
  let keep=dom(out);const minT=Math.min(...keep.map(c=>c.time));
  /* bez zbytečných objížděk (víc než 2× delší) a nejvýš 2 přestupy */
  const ok=keep.filter(c=>c.transfers<=2&&c.time<=minT*2+15*60);if(ok.length)keep=ok;
  keep.sort((a,b)=>a.leave-b.leave||a.arrive-b.arrive);
  return keep.slice(0,count)}
 return{search,fmtT,conns,patFor};
})();
window.__csa41=CSA;
let lastPlan=null,drawToken=0;
async function draw(c,from,to){
 const token=++drawToken;try{searchRouteLayer.clearLayers()}catch(_){}try{hideBaseNetworkForSearch()}catch(_){}S3={lines:[],stops:[],pins:[]};
 const bounds=L.latLngBounds([]);
 const line=(pts,color,dash,w)=>{if(!pts||pts.length<2)return;S3.lines.push({pts,color,walk:!!dash});L.polyline(pts,{color,weight:w,opacity:.95,dashArray:dash,lineCap:'round',lineJoin:'round',walk41:!!dash}).addTo(searchRouteLayer);
  /* pohyblivé bílé tečky ve směru jízdy / chůze */
  L.polyline(pts,{renderer:FLOW_R,color:'#ffffff',weight:dash?3:4,opacity:.95,dashArray:dash?'7 10':'10 14',lineCap:'butt',interactive:false,className:dash?'flow41 walk':'flow41',walk41:!!dash}).addTo(searchRouteLayer);
  pts.forEach(p=>bounds.extend(p))};
 const dot=(lat,lng,html,z=800)=>{if(/rt41-stop/.test(html))S3.stops.push({lat,lng,color:(html.match(/--lc:([^"]+)"/)||[])[1]||'#555'});else S3.pins.push({lat,lng,html});L.marker([lat,lng],{icon:L.divIcon({className:'rt41',html,iconSize:[24,24],iconAnchor:[12,12]}),zIndexOffset:z}).addTo(searchRouteLayer);bounds.extend([lat,lng])};
 const first=c.legs[0].P.seq[c.legs[0].a],last=c.legs.at(-1).P.seq[c.legs.at(-1).b];
 c.legs.forEach((g,i)=>{const seg=g.P.seq.slice(g.a,g.b+1);line(routeSlice(g.P.line,seg),D.color(g.P.line)||'#555',null,7);seg.forEach((p,k)=>{if(k&&k<seg.length-1)dot(p.lat,p.lng,'<span class="rt41-stop" style="--lc:'+h(D.color(g.P.line)||'#555')+'"></span>',700)});if(i){dot(seg[0].lat,seg[0].lng,'<span class="rt41-pin x"><i class="fa-solid fa-arrow-right-arrow-left"></i></span>',900);if(g.walk){const pv=c.legs[i-1].P.seq[c.legs[i-1].b];line([[pv.lat,pv.lng],[seg[0].lat,seg[0].lng]],'#6b6b70','2 9',4)}}});
 dot(from.lat,from.lng,'<span class="rt41-pin a">A</span>',1000);dot(to.lat,to.lng,'<span class="rt41-pin b">B</span>',1000);
 const walkLine=(a,b)=>line([[a.lat,a.lng],[b.lat,b.lng]],'#6b6b70','2 9',4);
 if(c.walkIn>15)walkLine(from,first);if(c.walkOut>15)walkLine(last,to);
 if(bounds.isValid()){if(is3dOn())fit3d(bounds);else map.fitBounds(bounds,{...fitPad(),animate:true})}
 push3d();
 /* Pěší úseky po skutečných ulicích, pokud je routovací služba dostupná. */
 /* stejná pěší služba jako navigace (Valhalla → OSRM), záložně původní roadPath; i pro pěší přestupy */
 const real=async(a,b)=>{try{const r=await navRoute([a.lat,a.lng],[b.lat,b.lng]);if(token===drawToken&&r&&!r.approx&&r.pts?.length>1)return r.pts}catch(_){}
  try{const p=await roadPath(a,b);if(token===drawToken&&p?.length>1)return p}catch(_){}return null};
 const xf=c.legs.map((g,i)=>i&&g.walk?[c.legs[i-1].P.seq[c.legs[i-1].b],g.P.seq[g.a]]:null).filter(Boolean);
 const[pin,pout,...px]=await Promise.all([c.walkIn>15?real(from,first):null,c.walkOut>15?real(last,to):null,...xf.map(([a,b])=>real(a,b))]);
 if(token!==drawToken||(!pin&&!pout&&!px.some(Boolean)))return;
 searchRouteLayer.eachLayer(l=>{if(l instanceof L.Polyline&&l.options.walk41)searchRouteLayer.removeLayer(l)});S3.lines=S3.lines.filter(x=>!x.walk);
 xf.forEach(([a,b],k)=>line(px[k]||[[a.lat,a.lng],[b.lat,b.lng]],'#6b6b70','2 9',4));
 line(pin||[[from.lat,from.lng],[first.lat,first.lng]],'#6b6b70','2 9',4);line(pout||[[last.lat,last.lng],[to.lat,to.lng]],'#6b6b70','2 9',4);
 push3d();
}
function legHTML(g,i){
 const seg=g.P.seq.slice(g.a,g.b+1),l=D.line(g.P.line),head=g.trip?(D.stops.get(g.trip.keys.at(-1))?.name||g.P.seq.at(-1).name):g.P.seq.at(-1).name,tm=x=>g.dep!=null?'<span class="t41">'+CSA.fmtT(x)+'</span>':'';
 return '<div class="step41 ride" style="--lc:'+h(D.color(g.P.line)||'#555')+'"><div class="step41-rail"></div><div class="step41-body">'
  +'<div class="step41-top">'+chip(g.P.line,'big')+'<span class="step41-dir">směr '+h(head)+'</span>'+(g.trip&&g.dep!=null?'<span class="sh41"><button type="button" class="sh41-b" data-k="'+i+'" data-d="-1" title="Předchozí spoj odsud" aria-label="Předchozí spoj"><i class="fa-solid fa-angles-left"></i></button><button type="button" class="sh41-b" data-k="'+i+'" data-d="1" title="Následující spoj odsud" aria-label="Následující spoj"><i class="fa-solid fa-angles-right"></i></button></span>':'')+'</div>'
  +'<div class="step41-stop board">'+tm(g.dep)+'<strong>'+h(seg[0].name)+'</strong><button type="button" class="step41-dep" data-stop="'+h(seg[0].name)+'"><i class="fa-regular fa-clock"></i> odjezdy</button></div>'
  +(seg.length>2?'<details class="step41-mid"><summary>'+czStops(seg.length-1)+' · '+(l&&!l.city?'regionální linka':(l?.mode==='trolleybus'?'trolejbus':'autobus'))+'</summary>'+seg.slice(1,-1).map(p=>'<div>'+h(p.name)+(p.request?' <i class="fa-regular fa-hand" title="na znamení"></i>':'')+'</div>').join('')+'</details>':'<div class="step41-mid plain">'+czStops(seg.length-1)+'</div>')
  +'<div class="step41-stop">'+tm(g.arr)+'<strong>'+h(seg.at(-1).name)+'</strong>'+(seg.at(-1).request?' <span class="sug41-req" title="Na znamení – dejte znamení řidiči"><i class="fa-regular fa-hand"></i></span>':'')+'</div></div></div>';
}
function walkHTML(m,text,nav){return '<div class="step41 walk"><div class="step41-rail"></div><div class="step41-body"><i class="fa-solid fa-person-walking"></i> '+h(text)+' · '+fmtDist(m)+' · ~'+Math.max(1,Math.round(walkSec(m)/60))+' min'+(nav?' <button type="button" class="step41-nav" data-stop="'+h(nav.name)+'" data-lat="'+nav.lat+'" data-lng="'+nav.lng+'"'+(nav.from?' data-flat="'+nav.from.lat+'" data-flng="'+nav.from.lng+'" data-flabel="'+h(nav.from.label||'')+'"':'')+'><i class="fa-solid fa-location-arrow"></i> Navigovat</button>':'')+'</div></div>'}
/* Odkaz do IDOS: všechny druhy dopravy (nejen MHD), zadává se výchozí a cílová adresa, ne zastávky. */
const idosUrl=(from,to)=>'https://idos.cz/vlakyautobusymhdvse/spojeni/?f='+encodeURIComponent(idosText(from))+'&t='+encodeURIComponent(idosText(to))+'&submit=true';
function idosText(p){if(p.idos)return p.idos;if(p.stop){const n=p.stop.name;return /,/.test(n)?n:'Opava, '+n}return String(p.label||'').replace(/\s*\(.*\)$/,'')}
const revCache=new Map();
async function revAddr(p){const k=(+p.lat).toFixed(5)+','+(+p.lng).toFixed(5);if(revCache.has(k))return revCache.get(k);
 const r=await fetch('https://photon.komoot.io/reverse?limit=1&lat='+p.lat+'&lon='+p.lng);if(!r.ok)throw Error('rev');const f=(await r.json()).features?.[0]?.properties;if(!f)return null;
 const city=f.city||f.locality||f.county||'',street=f.street?[f.street,f.housenumber].filter(Boolean).join(' '):(f.name||'');const t=[street,city].filter(Boolean).join(', ')||null;revCache.set(k,t);return t}
async function idosFix(a,from,to){if(!a||(from.idos&&to.idos))return;try{const [f,t]=await Promise.all([from,to].map(p=>p.idos?p.idos:revAddr(p).catch(()=>null)));
 if(f&&!from.idos)from.idos=f;if(t&&!to.idos)to.idos=t;if(a.isConnected)a.href=idosUrl(from,to)}catch(_){}}
/* celková délka cesty: úseky jízdy po trase linky + pěší úseky */
function planDist(c){if(c._dist!=null)return c._dist;let m=(c.walkIn||0)+(c.walkOut||0);
 for(const g of c.legs){m+=g.walk||0;const pts=routeSlice(g.P.line,g.P.seq.slice(g.a,g.b+1));for(let i=1;i<pts.length;i++)m+=dist(pts[i-1],pts[i])}
 return c._dist=m}
function renderPlan(list,sel,from,to){
 const box=$('connection-results');if(!box)return;const c=list[sel];
 const tline=v=>'<button type="button" class="var41 t41'+(list.indexOf(v)===sel?' active':'')+'" data-i="'+list.indexOf(v)+'"><span class="t41-tm"><b>'+CSA.fmtT(v.leave)+'</b><i>–</i><span>'+CSA.fmtT(v.arrive)+'</span></span><span class="var41-lines">'+v.legs.map(g=>chip(g.P.line)).join('<i class="fa-solid fa-chevron-right"></i>')+'</span>'+(connOk41(v)?'<span class="t41-dur"><b>'+Math.round(v.time/60)+' min</b><small>'+(v.transfers?v.transfers+'× přestup':'přímo')+'</small></span>':'<span class="t41-dur bad"><b><i class="fa-solid fa-triangle-exclamation"></i></b><small>nenavazuje</small></span>')+'</button>';
 let html=list[0]?.timed?'<div class="vars41 t41s"><button type="button" class="less41-conn"><i class="fa-solid fa-angles-up"></i> Dřívější spoje</button>'+list.map(tline).join('')+'<button type="button" class="more41-conn"><i class="fa-solid fa-angles-down"></i> Další spoje</button></div>':'<div class="vars41">'+list.map((v,i)=>'<button type="button" class="var41'+(i===sel?' active':'')+'" data-i="'+i+'"><span class="var41-time">'+(v.timed?CSA.fmtT(v.leave)+'<small class="var41-km">→ '+CSA.fmtT(v.arrive)+' · '+Math.round(v.time/60)+' min</small>':'~'+Math.round(v.time/60)+' min<small class="var41-km">'+fmtDist(planDist(v))+'</small>')+'</span><span class="var41-lines">'+v.legs.map(g=>chip(g.P.line)).join('<i class="fa-solid fa-chevron-right"></i>')+'</span><span class="var41-meta">'+(v.transfers?v.transfers+'× přestup':'přímo')+' · '+(v.timed?fmtDist(planDist(v)):czStops(v.stops))+'</span></button>').join('')+'</div>';
 html+='<div class="plan41"><div class="plan41-head"><span>'+h(from.label)+'</span><i class="fa-solid fa-arrow-right"></i><span>'+h(to.label)+'</span>'+(c.timed?'<button type="button" class="bell41-btn'+(window.__bell41?.isFor(c)?' on':'')+'" title="Upozornit na odjezd" aria-label="Upozornit na odjezd"><i class="fa-'+(window.__bell41?.isFor(c)?'solid':'regular')+' fa-bell"></i></button>':'')+'</div>';
 const first=c.legs[0].P.seq[c.legs[0].a],last=c.legs.at(-1).P.seq[c.legs.at(-1).b];
 if(c.walkIn>15)html+=walkHTML(c.walkIn,'Pěšky na zastávku '+first.name+(c.timed?' · vyjděte v '+CSA.fmtT(c.leave):''),{name:first.name,lat:first.lat,lng:first.lng,from:fromAddr(from)});
 c.legs.forEach((g,i)=>{if(i){const pg=c.legs[i-1],pe=pg.P.seq[pg.b].name,ns=g.P.seq[g.a].name;let extra='';
  if(c.timed&&pg.arr!=null&&g.dep!=null){const guar=!g.walk&&GUAR41(pg.P.line,g.P.line,g.P.seq[g.a].key)&&g.dep-pg.arr<=3,wk=g.walk?walkSec(g.walk)/60:0,wait=Math.round(g.dep-pg.arr-wk),ok=guar?pg.arr<=g.dep+3:g.dep>=pg.arr+wk+(g.walk?0:1)-0.01;
   extra=!ok?'<b class="xf41-bad"><i class="fa-solid fa-triangle-exclamation"></i> Nenavazuje – linka '+h(g.P.line)+' odjíždí v '+CSA.fmtT(g.dep)+', ale '+h(pg.P.line)+' přijede až v '+CSA.fmtT(pg.arr)+'</b>':guar?'<span class="xf41-ok"><i class="fa-solid fa-handshake"></i> linky 201 a 203 na sebe čekají</span>':(wait>0?'<span class="xf41-wait">čekání '+wait+' min</span>':'')}
  html+='<div class="step41 xfer'+(extra.includes('xf41-bad')?' bad':'')+'"><div class="step41-rail"></div><div class="step41-body"><i class="fa-solid '+(g.walk?'fa-person-walking':'fa-arrow-right-arrow-left')+'"></i> Přestup – '+(g.walk?h(pe)+' → pěšky '+fmtDist(g.walk)+' → '+h(ns):h(ns))+(extra?' '+extra:'')+'</div></div>'}html+=legHTML(g,i)});
 if(c.walkOut>15)html+=walkHTML(c.walkOut,'Pěšky do cíle');
 html+='<div class="plan41-note">'+(c.timed?'Časy podle jízdního řádu – bez aktuálních zpoždění.':'Doba je orientační (bez jízdního řádu).')+' Aktuální odjezdy ověřte v IDOS.</div><a class="idos41" target="_blank" rel="noopener" href="'+h(idosUrl(from,to))+'"><i class="fa-solid fa-arrow-up-right-from-square"></i> Ověřit v IDOS</a></div>';
 box.innerHTML=html;
 idosFix(box.querySelector('.idos41'),from,to);
 box.querySelectorAll('.var41').forEach(b=>b.onclick=()=>{const i=Number(b.dataset.i);renderPlan(list,i,from,to);draw(list[i],from,to)});
 box.querySelectorAll('.step41-dep').forEach(b=>b.onclick=()=>{try{window.openDeparturesPanel?.(b.dataset.stop)}catch(_){}});
 box.querySelectorAll('.step41-nav').forEach(b=>b.onclick=()=>window.__nav41?.start({name:b.dataset.stop,lat:Number(b.dataset.lat),lng:Number(b.dataset.lng),from:b.dataset.flat?fromAddr({lat:b.dataset.flat,lng:b.dataset.flng,label:b.dataset.flabel}):null}));
 box.querySelectorAll('.l41[data-line]').forEach(b=>b.onclick=e=>{e.stopPropagation()});
 box.querySelector('.more41-conn')?.addEventListener('click',()=>moreConn());
 box.querySelector('.less41-conn')?.addEventListener('click',()=>earlierConn());
 box.querySelector('.bell41-btn')?.addEventListener('click',e=>{e.preventDefault();window.__bell41?.panel(c,e.currentTarget)});
 box.querySelectorAll('.sh41-b').forEach(b=>b.onclick=e=>{e.preventDefault();e.stopPropagation();const n=shiftLeg(list[sel],Number(b.dataset.k),Number(b.dataset.d));
  if(!n){b.classList.add('none');b.title='Žádný další spoj';setTimeout(()=>b.classList.remove('none'),900);return}
  const L=[...list];L[sel]=n;const y=box.scrollTop;renderPlan(L,sel,from,to);try{draw(n,from,to)}catch(_){}box.scrollTop=y;try{window.__lastPlan41=L}catch(_){}});
}
function connOk41(c){if(!c?.timed)return true;for(let i=1;i<c.legs.length;i++){const p=c.legs[i-1],g=c.legs[i];if(p.arr==null||g.dep==null)continue;const guar=!g.walk&&GUAR41(p.P.line,g.P.line,g.P.seq[g.a].key),wk=g.walk?walkSec(g.walk)/60:0;if(guar?p.arr>g.dep+3:g.dep<p.arr+wk+(g.walk?0:1)-0.01)return false}return true}
/* posun jednoho spoje na předchozí / další spoj stejné linky mezi stejnými zastávkami */
function shiftLeg(c,k,dir){const TT=window.__tt41,g=c?.legs?.[k];if(!TT||!g||!g.trip||g.dep==null)return null;
 const bk=g.P.seq[g.a].key,ak=g.P.seq[g.b].key,di=c.di??TT.dayIdx(new Date()),cand=[];
 for(const T of TT.trips){if(D.line(T.line)?.suspended)continue;const i=T.keys.indexOf(bk);if(i<0||i===T.keys.length-1)continue;const j=T.keys.indexOf(ak,i+1);if(j<0)continue;
  for(const off of [-1440,0,1440]){if(!TT.on(T.si,di+off/1440))continue;cand.push({T,i,j,dep:T.dep[i]+off,arr:T.arr[j]+off})}}
 cand.sort((a,b)=>a.dep-b.dep||a.arr-b.arr);
 const pick=dir>0?cand.find(x=>x.dep>g.dep+0.01):[...cand].reverse().find(x=>x.dep<g.dep-0.01);if(!pick)return null;
 let P=g.P,a=g.a,b=g.b;if(pick.T.line!==g.P.line){try{const pf=CSA.patFor(pick.T,pick.i,pick.j);P=pf.P;a=pf.a;b=pf.b}catch(_){return null}}
 const legs=c.legs.map((x,n)=>n===k?{...x,P,a,b,dep:pick.dep,arr:pick.arr,trip:pick.T}:x);
 const leave=legs[0].dep-walkSec(c.walkIn||0)/60,arrive=legs.at(-1).arr+walkSec(c.walkOut||0)/60;
 return {...c,legs,leave,arrive,time:Math.max(0,(arrive-leave)*60),cost:Math.max(0,(arrive-leave)*60),shifted:true}}

let searching=false;
async function runConnection(){
 if(searching)return;searching=true;const btn=$('find-connection'),box=$('connection-results');
 try{
  if(btn){btn.disabled=true;btn.innerHTML='<i class="fa-solid fa-spinner fa-spin"></i> Hledám…'}
  if(box)box.innerHTML='';status('connection-status','Hledám…');
  const fi=$('from-address'),ti=$('to-address');if(!fi.value.trim()||!ti.value.trim())throw Error('Vyplňte Odkud i Kam.');
  const[from,to]=await Promise.all([placeFrom(fi),placeFrom(ti)]);
  const direct=dist([from.lat,from.lng],[to.lat,to.lng]);
  if(direct<60)throw Error('Výchozí místo a cíl jsou téměř stejné.');
  const O=candidates(from),T=candidates(to);
  if(!O.length||!T.length)throw Error('V okolí ('+(O.length?to.label:from.label)+') není žádná zastávka MHD.');
  /* podle jízdního řádu (výchozí); bez dat nebo bez spoje v příštích 10 h orientačně */
  if(ttUse()){const date=whenDate(),tl=CSA.search(O,T,from,to,date,6);
   if(tl&&tl.length){lastPlan={list:tl,from,to,timed:true,O,T};renderPlan(tl,0,from,to);await draw(tl[0],from,to);
    status('connection-status','Podle jízdního řádu · '+(tl.length===1?'1 spojení':tl.length+' spojení')+' od '+CSA.fmtT(window.__tt41.mins(date)));return}
   if(tl)status('connection-status','V příštích hodinách podle jízdního řádu nic nejede – ukazuji orientační spojení.')}
  const list=variants(O,T);
  if(!list.length){if(direct<1500){status('connection-status','Spojení MHD nenalezeno – cíl je '+fmtDist(direct)+' daleko, doporučujeme jít pěšky.');return}throw Error('Spojení s nejvýše dvěma přestupy nebylo nalezeno.')}
  lastPlan={list,from,to};renderPlan(list,0,from,to);await draw(list[0],from,to);
  status('connection-status',list.length===1?'Nalezena 1 varianta.':'Nalezeny '+list.length+' varianty.');
 }catch(e){console.warn('[Hledání spojení]',e);status('connection-status',userMsg41(e,'Toto místo neznáme nebo se spojení nepodařilo najít. Zkuste zadání upravit.'),true)}
 finally{searching=false;if(btn){btn.disabled=false;btn.innerHTML='<i class="fa-solid fa-route"></i> Najít spojení'}}
}
window.runConnectionSearch=runConnectionSearch=runConnection;
/* čas odjezdu: teď / zvolený čas a den */
const ttUse=()=>!!window.__tt41&&$('tt41-use')?.checked!==false;
function whenDate(){const d=new Date();if($('tt41-mode')?.value==='at'){const [hh,mm]=String($('tt41-time')?.value||'').split(':').map(Number);const dv=String($('tt41-date')?.value||'').split('-').map(Number);if(dv.length===3&&dv[0])d.setFullYear(dv[0],dv[1]-1,dv[2]);if(Number.isFinite(hh)){d.setHours(hh,mm||0,0,0)}}return d}
/* dřívější spoje: hledat od dřívějšího času a vzít ty, které odjíždějí před prvním zobrazeným */
function earlierConn(){if(!lastPlan?.timed)return;const L=lastPlan.list,first=L[0].leave,seen=new Set(L.map(c=>c.sig));let add=[];
 for(const back of [40,90,180]){const d=new Date(whenDate());d.setHours(0,0,0,0);d.setMinutes(Math.max(0,first-back));const r=(CSA.search(lastPlan.O,lastPlan.T,lastPlan.from,lastPlan.to,d,8)||[]).filter(c=>c.leave<first&&!seen.has(c.sig));if(r.length){add=r.slice(-3);break}}
 if(!add.length){status('connection-status','Dřívější spoje podle jízdního řádu nenalezeny.');return}
 lastPlan.list=[...add,...L];renderPlan(lastPlan.list,add.length-1,lastPlan.from,lastPlan.to);draw(lastPlan.list[add.length-1],lastPlan.from,lastPlan.to)}
function moreConn(){if(!lastPlan?.timed)return;const L=lastPlan.list,t=L.at(-1).leave+1,TT=window.__tt41;const base=whenDate();const d=new Date(base);d.setHours(0,0,0,0);d.setMinutes(t);
 const more=CSA.search(lastPlan.O,lastPlan.T,lastPlan.from,lastPlan.to,d,6)||[];const seen=new Set(L.map(c=>c.sig));const add=more.filter(c=>!seen.has(c.sig));
 if(!add.length){status('connection-status','Další spoje dnes podle jízdního řádu už nejedou.');return}
 lastPlan.list=[...L,...add];renderPlan(lastPlan.list,L.length,lastPlan.from,lastPlan.to);draw(lastPlan.list[L.length],lastPlan.from,lastPlan.to)}
{const fc=$('find-connection');if(fc&&!$('tt41-when')&&window.MHD41_TT){const w=document.createElement('div');w.id='tt41-when';w.className='tt41-when';
 const p2=n=>String(n).padStart(2,'0'),now=new Date();
 const iso=d=>d.getFullYear()+'-'+p2(d.getMonth()+1)+'-'+p2(d.getDate());
 w.innerHTML='<button type="button" id="tt41-chip" class="tt41-chip" aria-expanded="false"><i class="fa-regular fa-clock"></i><span id="tt41-sum">Odjezd teď</span><i class="fa-solid fa-chevron-down tt41-chev"></i></button>'
  +'<div class="tt41-pop" hidden><div class="tt41-seg"><button type="button" data-m="now" class="on">Teď</button><button type="button" data-m="at">Zvolit čas</button></div>'
  +'<div class="tt41-row"><label>Čas<input id="tt41-time" type="time" value="'+p2(now.getHours())+':'+p2(now.getMinutes())+'"></label><label>Datum<input id="tt41-date" type="date" value="'+iso(now)+'"></label></div>'
  +'<label class="tt41-use" title="Hledat podle jízdního řádu"><input id="tt41-use" type="checkbox" checked><span>Podle jízdního řádu</span></label>'
  +'<select id="tt41-mode" hidden aria-hidden="true"><option value="now">now</option><option value="at">at</option></select></div>';
 fc.before(w);
 const pop=w.querySelector('.tt41-pop'),chip=$('tt41-chip'),sum=$('tt41-sum');
 const sync=()=>{const at=$('tt41-mode').value==='at';w.classList.toggle('at',at);w.querySelectorAll('.tt41-seg button').forEach(b=>b.classList.toggle('on',b.dataset.m===(at?'at':'now')));
  if(!at){sum.textContent='Odjezd teď';return}const dd=whenDate(),t0=new Date();t0.setHours(0,0,0,0);const diff=Math.round((new Date(dd.getFullYear(),dd.getMonth(),dd.getDate())-t0)/864e5);
  sum.textContent='Odjezd '+dd.getHours()+':'+p2(dd.getMinutes())+' · '+(diff===0?'dnes':diff===1?'zítra':diff===-1?'včera':dd.getDate()+'. '+(dd.getMonth()+1)+'.')};
 chip.onclick=()=>{pop.hidden=!pop.hidden;chip.setAttribute('aria-expanded',pop.hidden?'false':'true');w.classList.toggle('open',!pop.hidden)};
 w.querySelectorAll('.tt41-seg button').forEach(b=>b.onclick=()=>{$('tt41-mode').value=b.dataset.m;sync()});
 $('tt41-mode').onchange=sync;$('tt41-time').oninput=()=>{$('tt41-mode').value='at';sync()};$('tt41-date').oninput=()=>{$('tt41-mode').value='at';sync()};sync()}}
const fromInput=attachSuggest('from-address'),toInput=attachSuggest('to-address');
if(fromInput)fromInput.placeholder='Odkud – zastávka nebo adresa';if(toInput)toInput.placeholder='Kam – zastávka nebo adresa';
[fromInput,toInput].forEach(i=>i?.addEventListener('search41-submit',runConnection));
const findBtn=$('find-connection');if(findBtn)findBtn.onclick=e=>{e.preventDefault();runConnection()};
const swap=$('swap-search');if(swap)swap.onclick=e=>{e.preventDefault();const a=$('from-address'),b=$('to-address');if(!a||!b)return;const va={v:a.value,...a.dataset},vb={v:b.value,...b.dataset};for(const[el,src]of[[a,vb],[b,va]]){el.value=src.v;['lat','lng','stop'].forEach(k=>{if(src[k]!=null)el.dataset[k]=src[k];else delete el.dataset[k]})}if(lastPlan)runConnection()};
$('from-my-location')&&($('from-my-location').onclick=()=>{try{useMyLocation('from-address','connection-status')}catch(_){}});
$('to-my-location')&&($('to-my-location').onclick=()=>{try{useMyLocation('to-address','connection-status')}catch(_){}});
/* Zastávka z popupu → rychlé „Odsud / Sem“. */
document.addEventListener('keydown',e=>{if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==='k'){e.preventDefault();try{openSearch();setSearchTab('stops')}catch(_){}setTimeout(()=>$('stop-address')?.focus(),60)}});
const sb=$('btn-search');if(sb)sb.addEventListener('click',()=>setTimeout(()=>{const v=$('search-stops-view');(v&&v.style.display!=='none'?$('stop-address'):$('from-address'))?.focus()},80));

/* ---------- 3. Jízda vozidlem: přesné zastávky a panel zastávek ---------- */
function monotone(points,stops){
 const n=stops.length,m=points.length;if(n<2||m<2)return null;let prev=new Float64Array(m);const par=Array.from({length:n},()=>new Int32Array(m));
 for(let j=0;j<m;j++)prev[j]=dist(points[j],[stops[0].lat,stops[0].lng])+j*.4;
 for(let i=1;i<n;i++){const cur=new Float64Array(m);let mn=Infinity,mi=0;for(let j=0;j<m;j++){if(prev[j]<mn){mn=prev[j];mi=j}cur[j]=mn+dist(points[j],[stops[i].lat,stops[i].lng]);par[i][j]=mi}prev=cur}
 let end=0;for(let j=1;j<m;j++)if(prev[j]<prev[end])end=j;const idx=new Array(n);idx[n-1]=end;for(let i=n-1;i>0;i--)idx[i-1]=par[i][idx[i]];return idx;
}
function refineRide(bus){
 const l=D.line(bus?.line),cur=bus?._stopsWithDist;if(!l||!cur?.length)return;
 const keys=cur.map(s=>D.key(s.name));let seq=null,off=-1;
 for(const cand of [bus._ridePlan?.direction===1?l.bp:l.fp,l.fp,l.bp]){for(let k=0;k+keys.length<=cand.length;k++){if(keys.every((x,i)=>cand[k+i].key===x)){seq=cand;off=k;break}}if(seq)break}
 const plats=seq?seq.slice(off,off+keys.length):cur.map(s=>{const st=D.stop(s.name);return st?.plats.find(p=>p.lines.has(String(bus.line)))||st?.plats[0]||{name:s.name,lat:s.lat,lng:s.lng,request:!!s.request,lineList:[]}});
 const pts=bus.points||[];const idx=monotone(pts,plats);const cum=[0];for(let i=1;i<pts.length;i++)cum.push(cum[i-1]+dist(pts[i-1],pts[i]));const total=cum.at(-1)||cur.at(-1).dist||1;
 const out=plats.map((p,i)=>({name:p.name,lat:p.lat,lng:p.lng,dist:idx?(i===0?0:i===plats.length-1?total:cum[idx[i]]):cur[i].dist,request:night(bus.line)?(()=>{try{return isRequestForLine({name:p.name},String(bus.line))}catch(_){return !!p.request}})():!!p.request,lines:D.stop(p.name)?.lineList||[]}));
 for(let k=1;k<out.length;k++)if(out[k].dist<=out[k-1].dist+1)out[k].dist=Math.min(total,out[k-1].dist+Math.max(2,(total-out[k-1].dist)/(out.length-k)));
 out[out.length-1].dist=total;bus._stopsWithDist=out;bus._ride41=true;
}
const panel=$('ride-panel');let panelEl=null,panelSig='';
if(panel){panelEl=document.createElement('div');panelEl.id='ride41';panelEl.innerHTML='<div class="r41-next"><div class="r41-next-label">Příští zastávka</div><div class="r41-next-row"><span id="r41-next-name">–</span><span id="r41-next-dist">–</span></div><div class="r41-bar"><i id="r41-bar"></i></div></div><div class="r41-list" id="r41-list"></div>';const anchor=$('ride-stops');anchor?anchor.parentNode.insertBefore(panelEl,anchor):panel.appendChild(panelEl)}
function nextIndex(stops,d){let n=stops.findIndex((s,i)=>i>0&&s.dist>d+1);return n<0?stops.length-1:n}
function renderPanel(force){
 if(!panelEl||!rideBus)return;const stops=rideBus._stopsWithDist||[];if(!stops.length)return;
 const d=Number(rideBus.distance)||0,next=nextIndex(stops,d),done=rideBus._terminalReached||d>=(stops.at(-1).dist-3);
 const sig=rideBus.line+'|'+stops.length+'|'+stops[0].name+'|'+next+'|'+done;
 if(force||sig!==panelSig){
  panelSig=sig;const list=$('r41-list');
  const JR=null;
  list.innerHTML=stops.map((s,i)=>{const st=i<next?'passed':i===next?(done?'passed':'next'):'future',term=i===stops.length-1;return '<div class="r41-stop '+st+(term?' term':'')+(i===0?' first':'')+'" data-i="'+i+'"><span class="r41-node"></span><span class="r41-copy"><span class="r41-name">'+h(s.name)+(s.request?' <i class="fa-regular fa-hand r41-req" title="Zastávka na znamení"></i>':'')+'</span>'+(s.lines?.length?'<span class="r41-lines">'+chips(s.lines.filter(n=>{const x=D.line(n),r=D.line(rideBus.line);return x&&(x.city||(r&&!r.city&&(r.train?x.train:(!x.train&&!x.city))))}))+'</span>':'')+'</span>'+((()=>{const ac=String(rideBus.line)==='204'&&window.__poleAction41?window.__poleAction41(stops,i):null;return ac?'<span class="r41-pole '+ac+'"><i class="fa-solid fa-bolt"></i>'+(ac==='down'?'troleje dolů':'troleje nahoru')+'</span>':''})())+(JR&&JR.times[i]!=null?'<span class="r41-time">'+CSA.fmtT(JR.times[i]).replace(/ \(\+\d\)/,'')+'</span>':'')+(term?'<span class="r41-flag"><i class="fa-solid fa-flag-checkered"></i></span>':'')+'</div>'}).join('');
  list.style.setProperty('--lc',D.color(rideBus.line)||'#c1784f');
  const cur=list.querySelector('.r41-stop.next')||list.querySelector('.r41-stop.term');
  if(cur){const top=cur.offsetTop-list.clientHeight*.3;list.scrollTo({top:Math.max(0,top),behavior:force?'auto':'smooth'})}
  const title=$('ride-title');if(title)title.textContent=stops[0].name+' → '+stops.at(-1).name;
  const badge=$('ride-line');if(badge){badge.style.background=D.color(rideBus.line)||'';badge.textContent=rideBus.line}
 }
 const nx=stops[next],rem=Math.max(0,(nx?.dist||0)-d),pct=Math.min(100,d/Math.max(1,stops.at(-1).dist)*100);
 const nn=$('r41-next-name'),nd=$('r41-next-dist'),bar=$('r41-bar');
 if(nn)nn.innerHTML=done?'Konečná – '+h(stops.at(-1).name):h(nx.name)+(nx.request?' <i class="fa-regular fa-hand r41-req" title="Na znamení"></i>':'');
 if(nd)nd.textContent=done?'':fmtDist(rem);
 if(bar)bar.style.width=pct.toFixed(1)+'%';
 panelEl.querySelector('.r41-next-label').textContent=done?'Cíl':(next===stops.length-1?'Konečná zastávka':'Příští zastávka');
}
(function loop(){try{if(typeof rideActive!=='undefined'&&(rideActive||rideBus)&&rideBus&&document.body.classList.contains('ride-mode')){if(!rideBus._ride41)refineRide(rideBus);renderPanel(false)}else panelSig=''}catch(_){}requestAnimationFrame(loop)})();
window.renderRideStopTable=function(force){if(rideBus){const a=rideBus._stopsWithDist||[],d=Number(rideBus.distance)||0;const n=a.findIndex((s,i)=>i>0&&Number(s.dist)>d-1);rideBus._shownStop=n<0?a.length-1:n}renderPanel(force===true)};

/* ==========================================================================
   4. 3D mapa: zastávky jako ve 2D, ovládání (zoom, joystick, vycentrovat),
      klik na vozidlo → jízda z místa kliknutí, hledání ve 3D, měřítko,
      spolehlivé načtení 3D mapy (budovy).
   ========================================================================== */
const shell=document.querySelector('.map-shell');
function is3dOn(){const e=$('mapbox3d');return !!e&&!e.classList.contains('hidden')}
const has3d=()=>typeof map3d!=='undefined'&&!!map3d&&map3dReady;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const RIDE_VIEW={pitch:66,zoom:19.1};
let rideYaw=0,ridePitch=RIDE_VIEW.pitch,rideZoom=RIDE_VIEW.zoom,rideMult=1,smoothB=null,rideGen=0,starting=false;

/* --- 3D zastávky: stejná tečka i stejná cedulka (popup) jako ve 2D --- */
let stop3d=[],stop3dMap=null,pop3d=null;
/* Zastávky ve 3D jako vrstva mapy (ne stovky HTML značek, které Mapbox přepočítává při každém pohybu) */
let S41=[];const STOP_GROUPS=[['city0',14],['city1',16],['regio0',12],['regio1',15],['train0',10],['train1',14]];
function stopPaint(){const dk=document.body.classList.contains('dark'),fg=dk?'#f2f2f5':'#2a2b31',bg=dk?'#1a1a1d':'#ffffff';
 return{'circle-radius':['interpolate',['linear'],['zoom'],10,['case',['get','req'],2.6,3.4],15,['case',['get','req'],3.6,5],18,['case',['get','req'],4.6,6.5]],
  'circle-color':['case',['get','req'],fg,bg],'circle-stroke-color':['case',['get','req'],bg,['case',['==',['get','k'],'train'],dk?'#e8eef7':'#1d2a3a',fg]],
  'circle-stroke-width':['interpolate',['linear'],['zoom'],10,1.6,16,2.4],'circle-emissive-strength':1}}
function build3dStops(){
 if(!has3d())return;stop3d=[true];stop3dMap=map3d;S41=[];const seen=new Map(),F=[];
 const add=(s,k,order)=>{F.push({type:'Feature',geometry:{type:'Point',coordinates:[s.lng,s.lat]},properties:{i:S41.length,g:k+(order?1:0),k,req:!!s.request}});S41.push(s)};
 const drawn=new Map();for(const s of officialStops){const dl=drawn.get(s.key)||[];if(dl.some(q=>dist(q,[s.lat,s.lng])<6))continue;dl.push([s.lat,s.lng]);drawn.set(s.key,dl);const order=seen.get(s.key)||0;seen.set(s.key,order+1);add(s,'city',order)}
 for(const s of REGIO_PLATS)add(s,'regio',s._order);
 for(const s of TRAIN_PLATS)add(s,'train',s._order);
 const fc={type:'FeatureCollection',features:F};
 try{const src=map3d.getSource('stops41');if(src)src.setData(fc);else map3d.addSource('stops41',{type:'geojson',data:fc});
  for(const [g,mz] of STOP_GROUPS){const id='stops41-'+g;if(!map3d.getLayer(id))map3d.addLayer({id,type:'circle',source:'stops41',slot:'top',minzoom:mz,filter:['==',['get','g'],g],paint:stopPaint()});
   if(!map3d['__st41'+g]){map3d['__st41'+g]=true;map3d.on('click',id,e=>{const f=e.features?.[0];if(!f)return;e.originalEvent?.stopPropagation?.();open3dStop(S41[f.properties.i])});
    map3d.on('mouseenter',id,()=>{map3d.getCanvas().style.cursor='pointer'});map3d.on('mouseleave',id,()=>{map3d.getCanvas().style.cursor=''})}}
  if(!map3d.__st41style){map3d.__st41style=true;map3d.on('style.load',()=>{try{build3dStops()}catch(_){}})}
 }catch(e){console.warn('[zastávky 3D]',e)}
 update3dStops();
}
window.__stops3d41={list:()=>S41,open:s=>open3dStop(s)};
function update3dStops(){if(!has3d())return;try{for(const [g] of STOP_GROUPS){const id='stops41-'+g;if(!map3d.getLayer(id))continue;const vis=g.startsWith('regio')?regioOn:g.startsWith('train')?trainOn:true;map3d.setLayoutProperty(id,'visibility',vis?'visible':'none')}}catch(_){}}
{let dk=document.body.classList.contains('dark');new MutationObserver(()=>{const d=document.body.classList.contains('dark');if(d===dk)return;dk=d;try{for(const [g] of STOP_GROUPS){const id='stops41-'+g;if(map3d?.getLayer(id))for(const [k,v] of Object.entries(stopPaint()))map3d.setPaintProperty(id,k,v)}}catch(_){}}).observe(document.body,{attributes:true,attributeFilter:['class']})}
/* --- Regio a Vlaky: k MHD jen přidají své trasy a zastávky (stejný design) --- */
let regioOn=false,trainOn=false;
const REGIO_NUMS=Object.values(D.lines).filter(l=>!l.city&&!l.train).map(l=>l.num);
const TRAIN_NUMS=Object.values(D.lines).filter(l=>l.train).map(l=>l.num);
const platList=test=>{const seen=new Map();return D.plats.filter(test).map(p=>{const o=seen.get(p.key)||0;seen.set(p.key,o+1);return{id:p.id,name:p.name,lat:p.lat,lng:p.lng,request:p.request,key:p.key,lines:p.lineList,regional:true,_order:o}})};
/* NAD (xS11, xS12) patří k vlakům – zobrazuje se tlačítkem V a ve vlakové barvě */
const NAD_NUMS=REGIO_NUMS.filter(n=>/^x/.test(n)),REGIO_VIS=REGIO_NUMS.filter(n=>!/^x/.test(n)),TRAIN_VIS=[...TRAIN_NUMS,...NAD_NUMS];
const nadOnly=p=>p.lines&&p.lines.size&&[...p.lines].every(n=>/^x/.test(n)||D.line(n)?.train);
const REGIO_PLATS=platList(p=>p.regional&&!D.stops.get(p.key).city&&!nadOnly(p));
const TRAIN_PLATS=platList(p=>p.train||(p.regional&&!D.stops.get(p.key).city&&nadOnly(p)));
const markersFor=(list,cls,minZ)=>list.map(s=>{
 const m=L.marker([s.lat,s.lng],{icon:L.divIcon({className:'stop41-marker '+cls,html:'<span class="s41-dot'+(s.request?' req':'')+'"></span>',iconSize:[12,12],iconAnchor:[6,6]}),zIndexOffset:cls==='train'?295:290,title:s.name});
 m.bindPopup(()=>stopPopup(s.name,s),{maxWidth:320,className:'popup41',autoPanPaddingTopLeft:L.point(24,90),autoPanPaddingBottomRight:L.point(24,40)});
 m.on('popupopen',e=>bindPopup(e.popup.getElement()));m._minZoom=minZ(s);return m});
const regio41=L.layerGroup(),regioMarkers=markersFor(REGIO_PLATS,'regio',s=>s._order?15:12);
const train41=L.layerGroup(),trainMarkers=markersFor(TRAIN_PLATS,'train',s=>s._order?14:10);
function updRegioStops(){regio41.clearLayers();train41.clearLayers();const z=map.getZoom();if(regioOn)for(const m of regioMarkers)if(z>=m._minZoom)regio41.addLayer(m);if(trainOn)for(const m of trainMarkers)if(z>=m._minZoom)train41.addLayer(m)}
try{map.on('zoomend',updRegioStops)}catch(_){}
/* Geometrie: regio varianty a vlakové tratě (OSM trasy dle jízdních řádů CIS JŘ) */
const XP=window.MHD41_PATHS||{};
/* Nová vozidla: Z-Group na vybraných regio linkách, vlaky na nejkratších tratích */
const EXTRA_FLEET=[
 ['262','f','zgroupvelky'],['253','b','zgroupvelky'],['261','f','zgroupvelky'],['241','b','zgroupvelky'],
 ['246','f','zgroupmaly'],['249','b','zgroupmaly'],['252','f','zgroupmaly'],['248','b','zgroupmaly'],
 /* Vlaky: jednokolejné tratě – vždy jen jeden vlak na trati, jezdí tam a zpět (kyvadlově).
    Na S13 se RegioNova a Motorák střídají po každé zpáteční jízdě. */
 ['R61','loop','regioshark',1],
 ['S13','loop','regionova',1,'S13'],['S13','loop','motorak',1,'S13']
];
/* Vozidla na vyžádání: každá regio/vlaková linka bez vlastního vozidla dostane skryté vozidlo,
   které se objeví jen při jízdě vybranou linkou (tlačítko + u Jízdy vozidlem). */
{const have=new Set(EXTRA_FLEET.map(x=>x[0]));let k=0;
 for(const n of REGIO_NUMS)if(!have.has(n))EXTRA_FLEET.push([n,'f',(k++%2)?'zgroupmaly':'zgroupvelky',0,null,1]);
 for(const n of TRAIN_NUMS)if(!have.has(n))EXTRA_FLEET.push([n,'f',/^R|Opavan|RegioJet/.test(n)?'regioshark':'regionova',1,null,1]);
 /* městské linky, které v základní flotile vozidlo nemají */
 for(const n of ['222','223'])if(typeof gpxRoutes!=='undefined'&&gpxRoutes[n]?.[0]?.points?.length>1)EXTRA_FLEET.push([n,'gpx',n==='222'?'iveco10m':'irisbus',0,null,1]);}
/* ---------- Jízdní řády (CIS JŘ 9. 10. 2026): spoje, kalendář, poloha spoje v čase ---------- */
const TT=(function(){const R=window.MHD41_TT;if(!R)return null;
 const [by,bm,bd]=R.base.split('-').map(Number),base=new Date(by,bm-1,bd);
 const svc=R.svc.map(x=>BigInt('0x'+x));
 const dayIdx=d=>Math.round((new Date(d.getFullYear(),d.getMonth(),d.getDate())-base)/864e5);
 const on=(si,di)=>di>=0&&di<R.days&&((svc[si]>>BigInt(di))&1n)===1n;
 const trips=R.trips.map(([li,pi,fi,si,t0],id)=>{const pr=R.profs[fi],dep=pr[0].map(x=>x+t0),arr=(pr[1]||pr[0]).map(x=>x+t0);return{id,line:R.lines[li],pi,keys:R.pats[pi].map(k=>R.stops[k]),dep,arr,si,t0,t1:arr.at(-1)}});
 const byLine={};for(const T of trips)(byLine[T.line]=byLine[T.line]||[]).push(T);
 const mins=d=>d.getHours()*60+d.getMinutes()+d.getSeconds()/60+d.getMilliseconds()/6e4;
 /* spoje, které právě jedou (i spoje ze včerejšího služebního dne po půlnoci) */
 function active(date){const di=dayIdx(date),m0=mins(date),out=[];
  for(const T of trips)for(const [d,off] of [[di,0],[di-1,1440]]){const m=m0+off;if(m>=T.t0-0.5&&m<=T.t1+0.25&&on(T.si,d)){out.push({T,m,key:T.id+'@'+d});break}}return out}
 /* nejvyšší počet současně jedoucích spojů linky (velikost fondu vozidel) */
 function maxConc(line,dis){let mx=0;for(const di of dis){const ev=[];for(const T of byLine[line]||[]){if(on(T.si,di)){ev.push([T.t0,1],[T.t1+1,-1])}if(on(T.si,di-1)&&T.t1>1440){ev.push([0,1],[T.t1-1440+1,-1])}}ev.sort((a,b)=>a[0]-b[0]||a[1]-b[1]);let c=0;for(const [,x] of ev){c+=x;if(c>mx)mx=c}}return mx}
 /* poloha ve spoji: index úseku a podíl (dwell = stojí v zastávce) */
 function where(T,m){const A=T.arr,Dp=T.dep;if(m<=Dp[0])return{i:0,f:0,dwell:true};
  for(let i=0;i<A.length-1;i++){if(m<=Dp[i])return{i,f:0,dwell:true};if(m<A[i+1])return{i,f:(m-Dp[i])/Math.max(.25,A[i+1]-Dp[i]),dwell:false}}
  return{i:A.length-1,f:0,dwell:true}}
 const valid=d=>{const i=dayIdx(d);return i>=0&&i<R.days};
 const until=new Date(base.getTime()+(R.days-1)*864e5);
 return{R,trips,byLine,dayIdx,on,active,maxConc,where,valid,mins,until};
})();
window.__tt41=TT;
/* fond vozidel pro polohy podle jízdního řádu: každá linka tolik vozidel, kolik spojů jede současně */
const TT_TYPES={troll:['26tr','32tr','36tr'],bus:['iveco10m','irisbus','sorbus','sorelektro','iveco12m'],reg:['zgroupvelky','zgroupmaly']};
if(TT){const di=TT.dayIdx(new Date());let k=0;
 for(const n of Object.keys(D.lines)){const l=D.line(n);if(l.suspended)continue;const has=(typeof gpxRoutes!=='undefined'&&gpxRoutes[n]?.some(r=>r.points?.length>1))||XP[n];if(!has)continue;
  const c=TT.maxConc(n,[di,di+1]);for(let j=0;j<c;j++){
   const type=l.train?(n==='S13'?(j%2?'motorak':'regionova'):/^R|Opavan|RegioJet/.test(n)?'regioshark':'regionova'):l.city?(l.mode==='trolleybus'?(n==='204'?'32tr':TT_TYPES.troll[k++%3]):TT_TYPES.bus[k++%5]):TT_TYPES.reg[k++%2];
   EXTRA_FLEET.push([n,'tt',type,l.train?1:0,null,0,1])}}}
window.__extraFleet41=EXTRA_FLEET.filter(([n,dir])=>(XP[n]||dir==='gpx'||dir==='tt')&&!D.line(n)?.suspended).map(([n,dir,type,rail,alt,pick,tt])=>{
 if(dir==='gpx')return{pick:true,line:n,dir:0,type,rail:false,kind:'regional',points:gpxRoutes[n][0].points};
 if(dir==='tt'){const r=(gpxRoutes[n]||[]).find(r=>r.points?.length>1);const l=D.line(n);return{tt:true,line:n,dir:0,type,rail:!!rail,kind:l.train?'train':l.city?'city':'regional',points:r?r.points:XP[n].f}}
 if(dir==='loop'){const f=XP[n].f,b=XP[n].b&&XP[n].b.length>1?XP[n].b:[...f].reverse();return{line:n,dir:0,type,rail:!!rail,kind:'train',loop:true,alt:alt||null,mid:f.length-1,points:[...f,...b.slice(1)]}}
 return{pick:!!pick,line:n,dir:dir==='f'?0:1,type,rail:!!rail,kind:rail?'train':'regional',points:XP[n][dir]&&XP[n][dir].length>1?XP[n][dir]:XP[n].f}});
for(const n of REGIO_NUMS){const p=XP[n];if(!p)continue;const g=routeLayers[n]||(routeLayers[n]=L.layerGroup());if(!routeHitLayers[n])routeHitLayers[n]=L.layerGroup();
 (p.v||[]).forEach((pts,i)=>{if(pts.length<2)return;L.polyline(pts,{color:/^x/.test(n)?(document.body.classList.contains('dark')?'#C27A52':'#99553A'):'#b3886b',weight:3.5,opacity:.78,interactive:false,lineCap:'round',lineJoin:'round'}).addTo(g);(gpxRoutes[n]=gpxRoutes[n]||[]).push({file:'regio-'+n+'-v'+i,direction:'V'+i,points:pts,noDrive:true,_regional:true})})}
/* Vlakové tratě na mapě jednotnou barvou (o něco tmavší než MHD); vlastní barva linky jen v síti a ve vyhledávání. */
const TRAIN_POLYS={};const trainMapColor=()=>document.body.classList.contains('dark')?'#C27A52':'#99553A';
function recolorTrains(only){for(const n of TRAIN_NUMS)for(const pl of TRAIN_POLYS[n]||[])pl.setStyle({color:n===only?D.color(n):trainMapColor()});
 try{for(const n of REGIO_NUMS)if(/^x/.test(n))routeLayers[n]?.eachLayer(l=>l.setStyle?.({color:n===only?D.color(n):trainMapColor()}))}catch(_){}}
for(const n of TRAIN_NUMS){const p=XP[n];if(!p)continue;const g=routeLayers[n]=L.layerGroup();TRAIN_POLYS[n]=[];routeHitLayers[n]=L.layerGroup();routeHitLayers[n].onAdd=function(){};gpxRoutes[n]=[];
 [['A',p.f],['B',p.b],...(p.v||[]).map((x,i)=>['V'+i,x])].forEach(([dir,pts])=>{if(!pts||pts.length<2)return;
  TRAIN_POLYS[n].push(L.polyline(pts,{color:trainMapColor(),weight:4.5,opacity:.9,interactive:false,lineCap:'round',lineJoin:'round'}).addTo(g));
  L.polyline(pts,{color:'#ffffff',weight:1.6,opacity:.9,dashArray:'7 9',interactive:false}).addTo(g);
  gpxRoutes[n].push({file:'train-'+n+'-'+dir,direction:dir,points:pts,noDrive:true,_train:true})});
 try{routePoints[n]=gpxRoutes[n].map(d=>d.points)}catch(_){}}
try{const src=map3d?.getSource?.('routes-3d');if(src)src.setData(geojsonRoutes())}catch(_){}
function apply3dRegio(){if(!has3d())return;try{if(map3d.getLayer('routes-3d-line')){const hide=[...(regioOn?[]:REGIO_VIS),...(trainOn?[]:TRAIN_VIS)];map3d.setFilter('routes-3d-line',hide.length?['!',['in',['get','line'],['literal',hide]]]:null);
 const m=['match',['get','line'],REGIO_VIS,'#b3886b'];for(const x of NAD_NUMS)m.push(x,trainMapColor());for(const n of TRAIN_NUMS)m.push(n,trainMapColor());m.push(document.body.classList.contains('dark')?'#E39A70':'#C1784F');map3d.setPaintProperty('routes-3d-line','line-color',m);
 try{const src=map3d.getSource('routes-3d');if(src&&!src.__train41){src.setData(geojsonRoutes());src.__train41=true}}catch(_){}}}catch(_){}update3dStops()}
function applyRegio(){
 const hidden=typeof searchHidBaseLayers!=='undefined'&&searchHidBaseLayers;
 const show=(nums,on)=>{for(const n of nums){const g=routeLayers[n];if(!g)continue;if(on&&!hidden){if(!map.hasLayer(g))g.addTo(map);g.eachLayer(l=>l.bringToBack?.())}else if(map.hasLayer(g))map.removeLayer(g);const hl=routeHitLayers[n];if(hl&&map.hasLayer(hl))map.removeLayer(hl)}};
 show(REGIO_VIS,regioOn);show(TRAIN_VIS,trainOn);recolorTrains(null);
 if(regioOn&&!hidden){if(!map.hasLayer(regio41))regio41.addTo(map)}else if(map.hasLayer(regio41))map.removeLayer(regio41);
 if(trainOn&&!hidden){if(!map.hasLayer(train41))train41.addTo(map)}else if(map.hasLayer(train41))map.removeLayer(train41);
 updRegioStops();
 try{if(window.regioStopLayer&&map.hasLayer(window.regioStopLayer))map.removeLayer(window.regioStopLayer)}catch(_){}
 const b=$('btn-r');if(b){b.classList.toggle('regio-active',regioOn);b.setAttribute('aria-pressed',String(regioOn))}
 const v=$('btn-v');if(v){v.classList.toggle('train-active',trainOn);v.setAttribute('aria-pressed',String(trainOn))}
 apply3dRegio();
 try{applySpeeds()}catch(_){}
}
function open3dStop(s){
 if(!has3d())return;pop3d?.remove();
 pop3d=new mapboxgl.Popup({className:'popup41-3d',maxWidth:'320px',offset:12,closeButton:true,focusAfterOpen:false}).setLngLat([s.lng,s.lat]).setHTML(stopPopup(s.name,s)).addTo(map3d);
 bindPopup(pop3d.getElement());
}
function focus3d(s){
 if(!has3d())return;map3d.flyTo({center:[s.lng,s.lat],zoom:17.3,duration:900,essential:true,padding:{top:0,left:0,right:0,bottom:sheetH()}});
 map3d.once('moveend',()=>{const p=s.plats?(s.plats.find(x=>x.city)||s.plats[0]):s;open3dStop({...p,name:s.name})});
}
/* Původní kruhy, popisky a 3D sloupky zastávek nahrazuje jednotný styl. */
window.sync3dStops=sync3dStops=function(){try{for(const g of stopMeshes)threeLayer?.scene?.remove(g);stopMeshes=[]}catch(_){}};

/* --- Hledání ve 3D: stejné barvy linek, pěší úseky, A/B a přestupy --- */
let S3={lines:[],stops:[],pins:[]},pins3d=[];
function push3d(){
 if(!has3d())return;
 try{
  const fc={type:'FeatureCollection',features:[]};
  for(const l of S3.lines)fc.features.push({type:'Feature',properties:{color:l.color,walk:l.walk?1:0},geometry:{type:'LineString',coordinates:l.pts.map(p=>[p[1],p[0]])}});
  for(const p of S3.stops)fc.features.push({type:'Feature',properties:{color:p.color},geometry:{type:'Point',coordinates:[p.lng,p.lat]}});
  const src=map3d.getSource('search41');
  if(src)src.setData(fc);else{
   map3d.addSource('search41',{type:'geojson',data:fc});
   map3d.addLayer({id:'search41-walk',type:'line',source:'search41',slot:'top',filter:['all',['==',['geometry-type'],'LineString'],['==',['get','walk'],1]],layout:{'line-cap':'round','line-join':'round'},paint:{'line-color':'#6b6b70','line-width':['interpolate',['linear'],['zoom'],12,3,17,5,20,9],'line-dasharray':[0.4,2.2],'line-emissive-strength':1}});
   map3d.addLayer({id:'search41-line',type:'line',source:'search41',slot:'top',filter:['all',['==',['geometry-type'],'LineString'],['==',['get','walk'],0]],layout:{'line-cap':'round','line-join':'round'},paint:{'line-color':['get','color'],'line-width':['interpolate',['linear'],['zoom'],12,4,16,8,19,16],'line-opacity':.96,'line-emissive-strength':1}});
   map3d.addLayer({id:'search41-stop',type:'circle',source:'search41',slot:'top',filter:['==',['geometry-type'],'Point'],paint:{'circle-radius':['interpolate',['linear'],['zoom'],12,3,17,6],'circle-color':'#ffffff','circle-stroke-color':['get','color'],'circle-stroke-width':2.5,'circle-pitch-alignment':'map','circle-emissive-strength':1}});
  }
  pins3d.forEach(m=>m.remove());pins3d=S3.pins.map(p=>{const el=document.createElement('div');el.className='rt41-3d';el.innerHTML=p.html;return new mapboxgl.Marker({element:el,anchor:'center'}).setLngLat([p.lng,p.lat]).addTo(map3d)});
  if(map3d.getLayer('routes-3d-line'))map3d.setPaintProperty('routes-3d-line','line-opacity',S3.lines.length?.22:.92);
  ['search-route-3d-line','search-route-3d-point'].forEach(id=>{if(map3d.getLayer(id))map3d.setLayoutProperty(id,'visibility','none')});
 }catch(e){console.warn('[3D hledání]',e)}
}
window.push3dSearchRoute=push3dSearchRoute=push3d;
function fit3d(b){if(!has3d())return;try{map3d.fitBounds([[b.getWest(),b.getSouth()],[b.getEast(),b.getNorth()]],{padding:{top:90,bottom:60+sheetH(),left:60,right:60},pitch:45,duration:900,maxZoom:17})}catch(_){}}
function clear3dSearch(){S3={lines:[],stops:[],pins:[]};push3d()}
const closePrev=closeSearch;window.closeSearch=closeSearch=function(){const r=closePrev.apply(this,arguments);clear3dSearch();return r};
['search-close-1','search-close-2'].forEach(id=>$(id)?.addEventListener('click',clear3dSearch));

/* --- Ovládání 3D mapy: + / − vlevo nahoře, joystick nad „Vycentrovat“ --- */
const zoom41=document.createElement('div');zoom41.id='zoom41';zoom41.innerHTML='<button type="button" data-z="1" aria-label="Přiblížit">+</button><button type="button" data-z="-1" aria-label="Oddálit">−</button>';shell?.appendChild(zoom41);
zoom41.querySelectorAll('button').forEach(b=>b.addEventListener('click',()=>{const dz=Number(b.dataset.z);if(rideActive&&rideBus){rideZoom=clamp(rideZoom+dz*.8,15.5,20.8);return}if(has3d())map3d.easeTo({zoom:map3d.getZoom()+dz,duration:250})}));
const joy=document.createElement('div');joy.id='joy41';joy.title='Otáčet pohledem o 360°';joy.setAttribute('aria-label','Joystick – otáčení pohledu');joy.innerHTML='<i class="fa-solid fa-rotate"></i><span class="joy41-knob"></span>';shell?.appendChild(joy);
const knob=joy.querySelector('.joy41-knob');let jid=null,jv=[0,0],jlast=0,jraf=0;
function joyTick(t){
 const dt=Math.min(.05,(t-(jlast||t))/1000);jlast=t;
 if(jid!==null){
  if(rideActive&&rideBus){rideYaw=(rideYaw+jv[0]*140*dt+360)%360;ridePitch=clamp(ridePitch-jv[1]*55*dt,20,84)}
  else if(has3d()){map3d.setBearing((map3d.getBearing()+jv[0]*140*dt+360)%360);map3d.setPitch(clamp(map3d.getPitch()-jv[1]*55*dt,0,84))}
  jraf=requestAnimationFrame(joyTick);
 }else{jraf=0;jlast=0}
}
function joyMove(e){if(e.pointerId!==jid)return;const r=joy.getBoundingClientRect(),max=r.width*.32;let dx=e.clientX-(r.left+r.width/2),dy=e.clientY-(r.top+r.height/2);const k=Math.min(1,max/(Math.hypot(dx,dy)||1));dx*=k;dy*=k;knob.style.transform='translate('+dx+'px,'+dy+'px)';jv=[dx/max,dy/max]}
joy.addEventListener('pointerdown',e=>{jid=e.pointerId;joy.setPointerCapture(jid);joy.classList.add('active');joyMove(e);if(!jraf)jraf=requestAnimationFrame(joyTick);e.preventDefault()});
joy.addEventListener('pointermove',joyMove);
['pointerup','pointercancel','lostpointercapture'].forEach(t=>joy.addEventListener(t,e=>{if(e.pointerId!==jid)return;jid=null;jv=[0,0];knob.style.transform='';joy.classList.remove('active')}));

/* --- Vycentrovat: 2D celé město, 3D výchozí pohled, v jízdě základní pohled na vozidlo --- */
function fresh(id){const el=$(id);if(!el)return null;const c=el.cloneNode(true);el.replaceWith(c);return c}
function recenter(){
 if(rideActive&&rideBus){rideYaw=0;ridePitch=RIDE_VIEW.pitch;rideZoom=RIDE_VIEW.zoom;rideFollow=true;smoothB=null;return}
 if(is3dOn()){try{reset3dView(true)}catch(_){}}else{try{map.setView(OPAVA_CENTER,13,{animate:true})}catch(_){}}
}
const rec=fresh('btn-recenter');if(rec)rec.onclick=e=>{e.preventDefault();recenter()};
const follow=fresh('ride-follow');if(follow)follow.onclick=e=>{e.preventDefault();recenter()};

/* --- Měřítko: jen 2D, vždy přepočtené z aktuálního výřezu --- */
const info=$('complete-map-info');let scaleEl=null;
if(info){scaleEl=document.createElement('div');scaleEl.className='scale41';scaleEl.innerHTML='<span class="scale41-label">100 m</span><span class="scale41-bar"></span>';info.appendChild(scaleEl)}
function updScale(){
 if(!scaleEl)return;if(is3dOn()){scaleEl.style.display='none';return}scaleEl.style.display='';
 try{const sz=map.getSize();if(!sz.x||!sz.y)return;const y=sz.y/2,x=Math.max(0,Math.min(sz.x-120,20)),m=map.containerPointToLatLng([x,y]).distanceTo(map.containerPointToLatLng([x+100,y]));if(!(m>0))return;const p=Math.pow(10,Math.floor(Math.log10(m))),n=m/p,nice=(n>=5?5:n>=2?2:1)*p;scaleEl.querySelector('.scale41-bar').style.width=(100*nice/m).toFixed(1)+'px';scaleEl.querySelector('.scale41-label').textContent=nice>=1000?(nice/1000).toLocaleString('cs-CZ')+' km':nice+' m'}catch(_){}
}
try{map.on('move zoom zoomend moveend resize viewreset',updScale)}catch(_){}
setInterval(updScale,1000);updScale();

/* --- Jízda vozidlem: zastávky podle skutečné trasy vozidla --- */
function along(pts,cum,i,p){
 /* přesná projekce zastávky na úseky kolem nalezeného vrcholu trasy */
 let best={d:cum[i],off:dist(pts[i],[p.lat,p.lng])};
 const kx=Math.cos(p.lat*Math.PI/180)*111320,ky=110540;
 for(let j=Math.max(1,i);j<=Math.min(pts.length-1,i+1);j++){
  const a=pts[j-1],b=pts[j],ax=(a[1]-p.lng)*kx,ay=(a[0]-p.lat)*ky,bx=(b[1]-p.lng)*kx,by=(b[0]-p.lat)*ky,vx=bx-ax,vy=by-ay,L2=vx*vx+vy*vy||1;
  const t=clamp(-(ax*vx+ay*vy)/L2,0,1),off=Math.hypot(ax+vx*t,ay+vy*t);
  if(off<best.off)best={d:cum[j-1]+(cum[j]-cum[j-1])*t,off};
 }
 return best;
}
function planOn(v,pts,seqs,offset,scale){
 const cum=[0];for(let i=1;i<pts.length;i++)cum.push(cum[i-1]+dist(pts[i-1],pts[i]));
 let best=null;
 seqs.forEach((seq,dir)=>{if(!seq)return;
  const idx=monotone(pts,seq);if(!idx)return;
  const rows=seq.map((p,i)=>({p,...along(pts,cum,idx[i],p)})),good=rows.filter(r=>r.off<170);
  const err=good.reduce((a,r)=>a+r.off,0)/(good.length||1),score=good.length*1000-err;
  if(good.length>=2&&(!best||score>best.score))best={dir,score,rows:good};
 });
 if(!best)return null;
 const stops=best.rows.map(r=>({name:r.p.name,lat:r.p.lat,lng:r.p.lng,dist:offset+r.d*scale,request:night(v.line)?(()=>{try{return isRequestForLine({name:r.p.name},String(v.line))}catch(_){return !!r.p.request}})():!!r.p.request,lines:D.stop(r.p.name)?.lineList||[]}));
 for(let k=1;k<stops.length;k++)if(stops[k].dist<=stops[k-1].dist+1)stops[k].dist=stops[k-1].dist+2;
 return{dir:best.dir,stops,head:stops.at(-1).name,cumEnd:offset+cum.at(-1)*scale};
}
function planFor(v,d){
 const l=D.line(v.line),pts=v.points||[];if(!l||pts.length<2)return null;
 if(!v._plans41||v._plans41.pts!==v.points){
  const cumAll=[0];for(let i=1;i<pts.length;i++)cumAll.push(cumAll[i-1]+dist(pts[i-1],pts[i]));
  const total=Number(v.length)||cumAll.at(-1),scale=total/(cumAll.at(-1)||1);
  const plans=[];
  if(v.loop41&&v.mid41>0&&v.mid41<pts.length-1){
   /* kyvadlová trasa: tam (fp) a zpět (bp) */
   const a=planOn(v,pts.slice(0,v.mid41+1),[l.fp],0,scale),b=planOn(v,pts.slice(v.mid41),[null,l.bp],cumAll[v.mid41]*scale,scale);
   if(a){a.start=0;a.end=Math.min(total-1,a.stops.at(-1).dist+2);plans.push(a)}
   if(b){b.start=cumAll[v.mid41]*scale;b.end=Math.min(total-1,b.stops.at(-1).dist+2);plans.push(b)}
  }else{const a=planOn(v,pts,[l.fp,l.bp],0,scale);if(a){a.start=0;a.end=Math.min(total-1,a.stops.at(-1).dist+2);plans.push(a)}}
  v._plans41={pts:v.points,plans};
 }
 const P=v._plans41.plans;if(!P.length)return null;
 const x=Number.isFinite(d)?d:(Number(v.distance)||0);
 return P.find(p=>x>=p.start-1&&x<p.end)||P[0];
}
const waitFor=(test,ms,msg)=>new Promise((res,rej)=>{const t0=Date.now();(function tick(){let v;try{v=test()}catch(_){}if(v)return res(v);if(Date.now()-t0>ms)return rej(Error(msg));setTimeout(tick,200)})()});
function rideErr(e){let el=$('ride-error-message');if(!el){el=document.createElement('div');el.id='ride-error-message';el.className='ride-error-message';document.body.appendChild(el)}el.textContent=e?.message||String(e);el.classList.add('show');clearTimeout(el._t);el._t=setTimeout(()=>el.classList.remove('show'),6000)}
function rideBtn(on){const b=$('ride-start-btn');if(!b)return;b.disabled=on;b.innerHTML=on?'<i class="fa-solid fa-spinner fa-spin"></i><span>Načítám jízdu…</span>':'<i class="fa-solid fa-bus"></i><span>Jízda vozidlem</span>'}
const vehicles=()=>{try{return (fleet&&fleet.length?fleet:busVehicles)||[]}catch(_){return busVehicles||[]}};
async function startRide41(v,from){
 if(starting)return;starting=true;rideBtn(true);
 try{
  if(!is3dOn())show3D();
  await waitFor(()=>has3d(),60000,'3D mapa se nenačetla. Zkontrolujte připojení a zkuste to znovu.');
  if(!vehicles().length){try{make3dVehicles()}catch(_){}}
  await waitFor(()=>vehicles().some(x=>x.ls&&x.length),10000,'Vozidla ještě nejsou připravena.');
  if(rideActive)endRideBase();
  if(!v){const pool=vehicles().filter(x=>x.ls&&x.length&&!night(x.line)&&!x.hidden41&&(planFor(x)?.stops.length||0)>=3);if(!pool.length)throw Error('Není dostupné žádné vozidlo s úplnou trasou.');v=pool[Math.floor(Math.random()*pool.length)];from=null}
  const plan=planFor(v,from==null?undefined:Number(from));if(!plan||plan.stops.length<2)throw Error('Pro linku '+v.line+' nejsou k dispozici zastávky.');
  let d=from==null?Math.max(0,plan.stops[0].dist-5):Number(from);if(!Number.isFinite(d)||d>plan.end-40)d=Math.max(0,plan.stops[0].dist-5);
  rideBus=v;rideActive=true;rideFollow=true;
  v.distance=d;v._poseLastT=performance.now();v.effSpeed=null;v.speed=11.5*rideMult;v._terminalReached=false;
  v._stopsWithDist=plan.stops;v._ride41=true;v._ridePlan={direction:plan.dir,total:plan.end};v.currentStopIndex=nextIndex(plan.stops,d);
  rideYaw=0;ridePitch=RIDE_VIEW.pitch;rideZoom=RIDE_VIEW.zoom;smoothB=null;
  hideVB();document.body.classList.add('ride-mode');
  ['ride-panel','ride-controls'].forEach(id=>{const el=$(id);el?.classList.add('open');el?.setAttribute('aria-hidden','false')});
  const mv=$('ride-preview-model'),nm=$('ride-preview-name');const uri=v.type?.uri||v.uri;if(mv&&uri&&mv.getAttribute('src')!==uri)mv.setAttribute('src',uri);if(nm)nm.textContent=v.type?.label||v.type?.name||'3D vozidlo';
  panelSig='';renderPanel(true);
  const gen=++rideGen;requestAnimationFrame(()=>rideLoop(gen));
  setTimeout(()=>{try{map3d.resize()}catch(_){}},360);
 }catch(e){console.warn('[Jízda]',e);rideErr(e)}
 finally{starting=false;rideBtn(false)}
}
function rideLoop(gen){
 if(gen!==rideGen||!rideActive||!rideBus)return;
 const v=rideBus,stops=v._stopsWithDist||[],d=Number(v.distance)||0,end=v._ridePlan?.total||v.length;
 if(!v._terminalReached){v.speed=11.5*rideMult;v._next41=nextIndex(stops,d);}
 if(d>=end&&!v._terminalReached){v._terminalReached=true;v.distance=end;v.speed=0;v.effSpeed=0;renderPanel(true);setTimeout(()=>{if(gen===rideGen&&rideActive)window.endRide()},6000)}
 if(v.lngLat&&Number.isFinite(v.bearing)&&rideFollow&&has3d()){
  if(smoothB==null)smoothB=v.bearing;const diff=((v.bearing-smoothB+540)%360)-180;smoothB=(smoothB+diff*.12+360)%360;
  try{map3d.jumpTo({center:v.lngLat,bearing:(smoothB+rideYaw)%360,pitch:ridePitch,zoom:rideZoom})}catch(_){}
 }
 requestAnimationFrame(()=>rideLoop(gen));
}
const endRidePrev=window.endRide;
function endRideBase(){rideGen++;hideVB();setRideMult(1);const v=rideBus;if(v){v.speed=BASE_SPEED;v.effSpeed=null;v._terminalReached=false;v._ride41=false}try{endRidePrev.apply(window)}catch(_){rideActive=false;rideBus=null;document.body.classList.remove('ride-mode')}}
window.endRide=endRide=function(){endRideBase();setTimeout(()=>{try{map3d?.resize()}catch(_){}},360)};
window.startRide=startRide=function(){return startRide41()};
const sbtn=fresh('ride-start-btn');if(sbtn)sbtn.onclick=e=>{e.preventDefault();startRide41()};
const rbtn=fresh('ride-restart');if(rbtn)rbtn.onclick=e=>{e.preventDefault();startRide41()};
const fast=fresh('ride-speed-2x');if(fast)fast.onclick=e=>{e.preventDefault();setRideMult(rideMult===1?2:1)};
/* Všechna vozidla jedou stejnou rychlostí; 2× v jízdě zrychlí celou flotilu. */
const BASE_SPEED=11.5;
/* Střídání vlaků na jedné jednokolejné trati (např. S13): jezdí vždy jen jeden. */
function syncAlt(){
 const groups=new Map();for(const v of vehicles())if(v.alt41){if(!groups.has(v.alt41))groups.set(v.alt41,[]);groups.get(v.alt41).push(v)}
 for(const g of groups.values()){
  let lead=g.find(v=>v._altLead)||g[0];g.forEach(v=>v._altLead=v===lead);
  const d=Number(lead.distance);
  if(Number.isFinite(lead._altLastD)&&Number.isFinite(d)&&d<lead._altLastD-200&&lead!==rideBus){
   const next=g[(g.indexOf(lead)+1)%g.length];next.distance=d;next._poseLastT=lead._poseLastT;lead._altLead=false;next._altLead=true;lead=next;
  }
  lead._altLastD=Number(lead.distance);
  for(const v of g)if(v!==lead&&v!==rideBus){v.distance=lead.distance;v._poseLastT=lead._poseLastT;v._altLastD=lead._altLastD}
 }
}
setInterval(syncAlt,100);
function applySpeeds(){for(const v of vehicles()){if(v.tt41&&v!==rideBus)continue;if(v.extra41)v.hidden41=v!==rideBus&&(v.pick41||(v.extra41==='regional'&&!regioOn)||(v.extra41==='train'&&!trainOn)||(v.alt41&&!v._altLead));if(v===rideBus&&v._terminalReached)continue;v.speed=BASE_SPEED*rideMult}}
function setRideMult(m){rideMult=m;const f=$('ride-speed-2x');if(f){f.classList.toggle('active',m===2);const s=f.querySelector('span');if(s)s.textContent=m===2?'Zpomalit na 1×':'2× zrychlit jízdu';const i=f.querySelector('i');if(i)i.className='fa-solid '+(m===2?'fa-backward':'fa-forward')}applySpeeds()}
setInterval(applySpeeds,250);
['ride-end','ride-end-top'].forEach(id=>{const b=fresh(id);if(b)b.onclick=e=>{e.preventDefault();window.endRide()}});

/* --- Klik na jedoucí vozidlo → štítek linky → jízda z místa kliknutí --- */
const vb=document.createElement('div');vb.id='veh41';vb.hidden=true;shell?.appendChild(vb);let selV=null,selD=0;
function hideVB(){selV=null;vb.hidden=true}
function pickVehicle(pt){
 const z=map3d.getZoom(),pitch=map3d.getPitch()*Math.PI/180,mpp=156543.03*Math.cos(49.94*Math.PI/180)/Math.pow(2,z),hpx=3.4/mpp*Math.sin(pitch);
 let best=null,bd=30+Math.max(0,z-15)*6;
 for(const v of vehicles()){
  if(!v.lngLat||night(v.line)||v.hidden41||(rideActive&&v===rideBus))continue;const p=map3d.project(v.lngLat);
  const dx=pt.x-p.x,dy=pt.y-p.y,up=clamp(-dy,0,hpx),d=Math.hypot(dx,dy+up);
  if(d<bd){bd=d;best=v}
 }
 return best;
}
function showVB(v){
 selV=v;selD=Number(v.distance)||0;const plan=planFor(v),l=D.line(v.line);
 vb.innerHTML='<button type="button" class="veh41-go" title="Jet tímto vozidlem odsud">'+chip(v.line,'big')+'<span class="veh41-txt"><strong>'+(l?.train?'Vlak':l?.mode==='trolleybus'?'Trolejbus':l&&!l.city?'Regio autobus':'Autobus')+' '+h(v.line)+'</strong><small>'+(plan?'směr '+h(plan.head):'')+'</small></span><span class="veh41-cta"><i class="fa-solid fa-play"></i> Jet</span></button><button type="button" class="veh41-x" aria-label="Zavřít">×</button>';
 vb.querySelector('.veh41-go').onclick=e=>{e.stopPropagation();const v0=selV;if(!v0)return;const d=Number(v0.distance)||selD;hideVB();startRide41(v0,d)};
 vb.querySelector('.veh41-x').onclick=e=>{e.stopPropagation();hideVB()};
 vb.hidden=false;placeVB();
}
function placeVB(){if(!selV||vb.hidden)return;if(!has3d()||!is3dOn()||selV===rideBus||!selV.lngLat){hideVB();return}const p=map3d.project(selV.lngLat);vb.style.transform='translate('+Math.round(p.x)+'px,'+Math.round(p.y)+'px) translate(-50%,calc(-100% - 34px))'}
function onMap3dClick(e){
 const t=e.originalEvent?.target;if(t?.closest?.('.stop41-3d,#veh41,.mapboxgl-popup,.rt41-3d'))return;
 const v=pickVehicle(e.point);if(!v){if(!rideActive)hideVB();return}
 if(v===selV&&!vb.hidden){hideVB();return}
 setTimeout(()=>document.querySelectorAll('.mapboxgl-popup:not(.popup41-3d)').forEach(p=>p.remove()),0);
 pop3d?.remove();showVB(v);
}

/* --- Spolehlivé načtení 3D mapy (styl, budovy, velikost plátna) --- */
let hookedMap=null,loadTimer=null;
function prepStyle(){
 if(!has3d())return;
 try{map3d.setConfigProperty?.('basemap','show3dObjects',true)}catch(_){}
 ['stops-3d','stops-3d-label'].forEach(id=>{try{if(map3d.getLayer(id))map3d.setLayoutProperty(id,'visibility','none')}catch(_){}});
 try{if(map3d.getLayer('routes-3d-hit'))map3d.removeLayer('routes-3d-hit')}catch(_){}
 apply3dRegio();
 sync3dStops();
 if(stop3dMap!==map3d||!stop3d.length)build3dStops();
 push3d();
 try{map3d.resize()}catch(_){}
}
function hookMap(){
 if(typeof map3d==='undefined'||!map3d||map3d===hookedMap)return;hookedMap=map3d;const m=map3d;
 m.on('style.load',()=>setTimeout(prepStyle,200));
 m.on('zoom',update3dStops);
 m.on('click',onMap3dClick);
 m.on('render',placeVB);
 m.on('dragstart',()=>{try{if(window.__nav41?.state.on&&window.__nav41.state.follow){window.__nav41.state.follow=false}}catch(_){}});
 m.on('webglcontextrestored',()=>{try{window.__fleetReset?.()}catch(_){}prepStyle()});
 m.once('idle',prepStyle);
 if(map3dReady)prepStyle();
}
setInterval(hookMap,400);
function ensure3d(){
 /* Watchdog: když se styl/budovy do 15 s nenačtou, styl se znovu nastaví;
    když ani pak ne, mapa se vytvoří znovu (bez nutnosti obnovit stránku). */
 clearTimeout(loadTimer);let tries=0;
 const check=()=>{
  if(!is3dOn())return;
  if(typeof map3d!=='undefined'&&map3d){try{map3d.resize()}catch(_){}}
  if(has3d()&&map3d.isStyleLoaded?.()!==false){prepStyle();return}
  tries++;
  if(tries===3&&map3d){try{map3d.setStyle('mapbox://styles/mapbox/standard',{config:{basemap:{show3dObjects:true}}})}catch(_){}}
  if(tries===6&&map3d){try{map3d.remove()}catch(_){}map3d=null;map3dReady=false;threeLayer=null;stopMeshes=[];stop3d=[];hookedMap=null;try{initMapbox3D()}catch(e){console.warn(e)}}
  if(tries<10)loadTimer=setTimeout(check,5000);
 };
 loadTimer=setTimeout(check,5000);
 [80,300,800].forEach(t=>setTimeout(()=>{try{map3d?.resize()}catch(_){}},t));
}
const show3dPrev=window.show3D||show3D;
window.show3D=show3D=function(){const r=show3dPrev.apply(this,arguments);const fx=$('fx3d-control');if(fx)fx.style.display='flex';ensure3d();setTimeout(hookMap,0);setTimeout(()=>{update3dStops();updScale()},50);return r};
const show2dPrev=window.show2D||show2D;
window.show2D=show2D=function(){hideVB();const r=show2dPrev.apply(this,arguments);const fx=$('fx3d-control');if(fx)fx.style.display='none';setTimeout(()=>{try{map.invalidateSize()}catch(_){}updScale()},60);return r};
/* Přepínač 3D v hlavičce volá show3D přes původní odkaz – navážeme kontrolu i na něj. */
$('btn-model-3d')?.addEventListener('click',()=>{ensure3d();setTimeout(hookMap,0)});
/* Po změně velikosti okna (otočení telefonu) přepočítat obě mapy. */
let rsT=null;window.addEventListener('resize',()=>{clearTimeout(rsT);rsT=setTimeout(()=>{try{map.invalidateSize()}catch(_){}try{map3d?.resize()}catch(_){}updScale()},150)});
window.addEventListener('orientationchange',()=>setTimeout(()=>{try{map.invalidateSize()}catch(_){}try{map3d?.resize()}catch(_){}},400));
/* Panel jízdy jako samostatný boční panel (stejná mezera jako u Dopravní sítě). */
if(panel&&panel.parentElement!==document.body)document.body.appendChild(panel);

/* --- Odjezdy: tlačítko u zastávky otevře panel s konkrétní zastávkou --- */
const depPrev=window.openDeparturesPanel;
if(typeof depPrev==='function'){
 window.openDeparturesPanel=function(name){
  const r=depPrev.apply(this,arguments),panelD=$('departures-panel');if(!panelD)return r;
  let box=$('dep41');if(!box){box=document.createElement('div');box.id='dep41';const tb=panelD.querySelector('.departures-toolbar');tb?tb.after(box):panelD.prepend(box)}
  if(!name){box.hidden=true;box.innerHTML='';return r}
  const s=D.stop(name),nm=s?.name||D.canon(name);
  const inp=$('departures-stop-input');if(inp)inp.value=nm;
  const paired=/stopNum=/.test($('departures-frame')?.getAttribute('src')||'');
  const sub=$('departures-subtitle');if(sub)sub.textContent=paired?'Živá odjezdová tabule ODIS':'Odjezdy ze zastávky';
  const idos='https://idos.cz/opava/odjezdy/?f='+encodeURIComponent(nm);
  box.hidden=false;
  box.innerHTML='<div class="dep41-top"><span class="card41-ico"><i class="fa-solid fa-location-dot"></i></span><div class="dep41-name">'+h(nm)+'</div></div>'+(s?'<div class="dep41-lines">'+chips(s.lineList)+'</div>':'')
   +(paired?'':'<div class="dep41-note">Pro tuto zastávku zatím nemáme číslo živé tabule ODIS – otevřete odjezdy v IDOS (zastávka je předvyplněná), nebo ji vyhledejte v tabuli níže.</div>')
   +'<a class="dep41-btn" target="_blank" rel="noopener" href="'+idos+'"><i class="fa-regular fa-clock"></i> Odjezdy v IDOS</a>';
  box.querySelectorAll('.l41[data-line]').forEach(b=>b.onclick=()=>window.openLine?.(String(b.dataset.line)));
  return r;
 };
}
/* --- Spodní panel na výšku: mapa zůstává vidět nad ním --- */
function sheetH(){if(!matchMedia('(max-width:700px) and (orientation:portrait)').matches)return 0;for(const id of ['search-panel','network-panel']){const p=$(id);if(p?.classList.contains('open'))return p.getBoundingClientRect().height}return 0}
function fitPad(){const sh=sheetH();return sh?{paddingTopLeft:[30,30],paddingBottomRight:[30,sh+24]}:{padding:[60,60]}}

/* --- Regio tlačítko: jednoduchý přepínač, nic dalšího nemění --- */
const rb=fresh('btn-r');if(rb){rb.title='Regio trasy a zastávky';rb.setAttribute('aria-label',rb.title);rb.onclick=e=>{e.preventDefault();e.stopPropagation();regioOn=!regioOn;applyRegio()}}
/* --- Tlačítko V: vlakové tratě a stanice (stejně jako R pro regio) --- */
if(rb&&!$('btn-v')){const vbtn=rb.cloneNode(true);vbtn.id='btn-v';vbtn.textContent='V';vbtn.title='Vlaky – tratě a stanice';vbtn.setAttribute('aria-label',vbtn.title);vbtn.classList.remove('regio-active');rb.after(vbtn);vbtn.onclick=e=>{e.preventDefault();e.stopPropagation();trainOn=!trainOn;applyRegio()}}
/* --- Dopravní síť: kategorie Vlaky pod regio linkami --- */
const TRAIN_IMG='img/58bcd19019.webp';
const TRAIN_SVG='<svg class="train41-thumb" viewBox="0 0 64 34" aria-hidden="true"><rect x="2" y="5" width="60" height="22" rx="7" fill="currentColor"/><rect x="8" y="10" width="9" height="7" rx="2" fill="#fff" opacity=".9"/><rect x="21" y="10" width="9" height="7" rx="2" fill="#fff" opacity=".9"/><rect x="34" y="10" width="9" height="7" rx="2" fill="#fff" opacity=".9"/><path d="M48 10h7a3 3 0 0 1 3 3v4h-10z" fill="#fff" opacity=".9"/><circle cx="14" cy="29" r="3" fill="currentColor"/><circle cx="50" cy="29" r="3" fill="currentColor"/></svg>';
const renderPrev=window.renderNetwork;
window.renderNetwork=renderNetwork=function(){const r=renderPrev.apply(this,arguments);const list=$('network-list');if(!list)return r;
 const heads=[...list.querySelectorAll('.network-cat-head')];if(heads[2]){const t=heads[2].querySelector('span');if(t)t.textContent='REGIONÁLNÍ AUTOBUSY'}
 if(!list.querySelector('.network-cat-head.train41')){const hd=document.createElement('div');hd.className='network-cat-head train41';hd.innerHTML='<span>VLAKY</span><span class="network-cat-count">• '+TRAIN_NUMS.length+' LINEK · přes Opava východ</span>';list.appendChild(hd);
  for(const n of TRAIN_NUMS){try{const item=makeItem(n,false);item.classList.add('train41-item');item.style.setProperty('--lc',D.color(n));const th=item.querySelector('.route-thumb');if(th)th.innerHTML='<span class="route-thumb-imgwrap"><img class="train41-img" src="'+TRAIN_IMG+'" alt="Vlak"></span>';const num=item.querySelector('.route-number');if(num){num.style.background=D.color(n);num.classList.add('train41-num')}if(D.line(n).suspended){const note=document.createElement('div');note.className='susp41 info41';note.innerHTML='<i class="fa-solid fa-bus"></i> '+h(D.line(n).suspended);item.querySelector('.network-route-head')?.after(note)}list.appendChild(item)}catch(e){console.warn('[Vlaky síť]',n,e)}}
  /* NAD (náhradní autobusy za S11/S12) patří k vlakům – hned pod S12 */
  let anchor=[...list.querySelectorAll('.train41-item')].find(x=>x.querySelector('.route-number')?.textContent.trim()==='S12');
  for(const n of ['xS11','xS12']){const old=[...list.querySelectorAll('.network-item:not(.train41-item)')].find(x=>x.querySelector('.route-number')?.textContent.trim()===n);
   if(!old||!anchor)continue;old.classList.add('nad41-item');const num=old.querySelector('.route-number');if(num){num.style.background=D.color(n)||'#8e24aa';num.classList.add('nad41-num');old.style.setProperty('--nadc',D.color(n)||'#8e24aa')}
   anchor.after(old);anchor=old}
  const rc=heads[2]?.querySelector('.network-cat-count');if(rc){const k=[...list.querySelectorAll('.network-item')].filter(x=>{const t=x.querySelector('.route-number')?.textContent.trim();const L=D.line(t);return L&&!L.city&&!L.train&&!x.classList.contains('nad41-item')}).length;rc.textContent='• '+k+' LINEK'}
  const tc=list.querySelector('.network-cat-head.train41 .network-cat-count');if(tc)tc.textContent='• '+TRAIN_NUMS.length+' LINEK + NAD · přes Opava východ'}
 return r};

['btn-model-3d','btn-map-2d'].forEach(id=>$(id)?.addEventListener('click',()=>[200,900,2100].forEach(t=>setTimeout(applyRegio,t))));
for(const fn of ['restoreBaseNetworkAfterSearch','showAllLinesOnMap']){const prev=window[fn];if(typeof prev==='function')window[fn]=function(){const r=prev.apply(this,arguments);applyRegio();return r}}
try{restoreBaseNetworkAfterSearch=window.restoreBaseNetworkAfterSearch;showAllLinesOnMap=window.showAllLinesOnMap}catch(_){}
/* --- Klik na trasu už neotevírá seznam linek (2D) --- */
for(const g of Object.values(routeHitLayers)){try{if(map.hasLayer(g))map.removeLayer(g);g.eachLayer(l=>l.off('click'));g.onAdd=function(){}}catch(_){}}
/* Rozbalení vlakové/regio linky v síti přiblíží mapu na celou trasu */
document.getElementById('network-list')?.addEventListener('click',e=>{const head=e.target.closest('.network-route-head');if(!head)return;const item=head.closest('.network-item');const n=item?.querySelector('.route-number')?.textContent.trim();if(!n||!D.line(n)||D.line(n).city)return;
 setTimeout(()=>{if(!item.classList.contains('expanded'))return;const pts=(gpxRoutes[n]||[]).flatMap(d=>d.points||[]);if(pts.length){try{if(is3dOn()&&has3d()){const b=L.latLngBounds(pts);map3d.fitBounds([[b.getWest(),b.getSouth()],[b.getEast(),b.getNorth()]],{padding:60,duration:800})}else map.fitBounds(L.latLngBounds(pts),{...fitPad(),animate:true})}catch(_){}}try{item.scrollIntoView({block:'nearest',behavior:'smooth'})}catch(_){}},80)});
try{renderNetwork()}catch(_){}
/* Vlakové a regio trasy smí na mapu jen při zapnutém V / R (starší kód přidává všechny routeLayers). */
{const G=new Map();for(const n of TRAIN_NUMS){if(routeLayers[n])G.set(routeLayers[n],['t',n]);if(routeHitLayers[n])G.set(routeHitLayers[n],['t',n])}
 for(const n of REGIO_NUMS){const t=/^x/.test(n)?'t':'r';if(routeLayers[n])G.set(routeLayers[n],[t,n]);if(routeHitLayers[n])G.set(routeHitLayers[n],[t,n])}
 let only=null;const add0=map.addLayer;map.addLayer=function(l){const k=G.get(l);if(k&&k[1]!==only&&!(k[0]==='t'?trainOn:regioOn))return this;return add0.apply(this,arguments)};
 const so=window.showOnlyLineOnMap;if(typeof so==='function')window.showOnlyLineOnMap=showOnlyLineOnMap=function(n){only=String(n);try{return so.apply(this,arguments)}finally{only=null;recolorTrains(String(n))}}}
{let dk=document.body.classList.contains('dark');new MutationObserver(()=>{const d=document.body.classList.contains('dark');if(d===dk)return;dk=d;recolorTrains(null);apply3dRegio()}).observe(document.body,{attributes:true,attributeFilter:['class']})}
applyRegio();

/* ==========================================================================
   v6: směr tras ve 3D, jas nových modelů, 3D PLUS, navigace k zastávce
   ========================================================================== */
/* --- Pohyblivé bílé tečky ve směru trasy (Mapbox) --- */
const DASH_SEQ=[[0,4,3],[0.5,4,2.5],[1,4,2],[1.5,4,1.5],[2,4,1],[2.5,4,0.5],[3,4,0],[0,0.5,3,3.5],[0,1,3,3],[0,1.5,3,2.5],[0,2,3,2],[0,2.5,3,1.5],[0,3,3,1],[0,3.5,3,0.5]];
const FLOW3D=new Set();let dashStep=0;
function addFlow3d(src,id,filter,width){
 if(!has3d()||!map3d.getSource(src))return;
 try{if(!map3d.getLayer(id))map3d.addLayer({id,type:'line',source:src,slot:'top',filter:filter||['==',['geometry-type'],'LineString'],layout:{'line-cap':'butt','line-join':'round'},paint:{'line-color':'#ffffff','line-width':width||3,'line-opacity':.95,'line-dasharray':DASH_SEQ[0],'line-emissive-strength':1}});FLOW3D.add(id)}catch(e){console.warn('[flow3d]',e)}
}
setInterval(()=>{if(!has3d()||!FLOW3D.size||!is3dOn())return;dashStep=(dashStep+1)%DASH_SEQ.length;for(const id of FLOW3D){try{if(map3d.getLayer(id))map3d.setPaintProperty(id,'line-dasharray',DASH_SEQ[dashStep])}catch(_){}}},70);
const push3dBase=push3d;
push3d=function(){push3dBase();addFlow3d('search41','search41-flow',['all',['==',['geometry-type'],'LineString']],3)};
window.push3dSearchRoute=push3dSearchRoute=push3d;

/* --- Jas nových modelů: zapečená textura bez dalšího osvětlení, ztlumená podle denní doby --- */
const TIME_LIGHT={day:.9,dawn:.72,dusk:.62,night:.38};
function applyModelLight(preset){const f=TIME_LIGHT[preset]??(document.body.classList.contains('dark')?TIME_LIGHT.night:TIME_LIGHT.day);for(const m of window.__basicMats41||[]){try{m.color.setScalar(f)}catch(_){}}try{map3d?.triggerRepaint()}catch(_){}}
{const prev=window.__fx3dSetTime;window.__fx3dSetTime=function(p){const r=prev?.apply(this,arguments);applyModelLight(p);return r}}
setInterval(()=>{const n=(window.__basicMats41||[]).length;if(n!==applyModelLight._n){applyModelLight._n=n;applyModelLight(document.body.classList.contains('dark')?'night':'day')}},1000);

/* --- 3D PLUS: další 3D mapa na místě mapy (bez horního panelu claude.ai) --- */
const PLUS_URL='https://prerekhu-cloud.github.io/Mhd/3dplus/index.html',PLUS_FALLBACK='https://claude.ai/artifact/5MM9qkXQTNEHoRf1Lz6wxF';
const b3=$('btn-model-3d');let plusBtn=null,plusBox=null;
if(b3&&!$('btn-plus3d')){
 plusBtn=b3.cloneNode(true);plusBtn.id='btn-plus3d';plusBtn.className='h-7 px-3 rounded-full text-gray-700 text-xs font-medium flex items-center gap-1.5 plus41-btn';
 plusBtn.innerHTML='<i class="fa-solid fa-cubes text-xs"></i><span>3D PLUS</span>';plusBtn.title='3D PLUS – podrobný 3D model Opavy';b3.after(plusBtn);
 plusBtn.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();document.body.classList.contains('plus-open')?closePlus():openPlus()});
 ['btn-map-2d','btn-model-3d'].forEach(id=>$(id)?.addEventListener('click',()=>closePlus(),true));
}
async function openPlus(){
 if(rideActive)try{window.endRide()}catch(_){}
 if(!plusBox){plusBox=document.createElement('div');plusBox.id='plus41';plusBox.innerHTML='<div class="plus41-msg" hidden></div><iframe title="3D PLUS" loading="eager"></iframe><div class="plus41-bar"><a class="plus41-link" target="_blank" rel="noopener"><i class="fa-solid fa-up-right-from-square"></i><span>Nová karta</span></a><button type="button" class="plus41-close"><i class="fa-solid fa-xmark"></i><span>Zpět na mapu</span></button></div>';shell.appendChild(plusBox);plusBox.querySelector('.plus41-close').onclick=()=>closePlus()}
 document.body.classList.add('plus-open');plusBtn?.classList.add('plus-active');
 const fr=plusBox.querySelector('iframe'),msg=plusBox.querySelector('.plus41-msg'),link=plusBox.querySelector('.plus41-link');
 if(fr.dataset.ok==='1'){fr.hidden=false;return}
 let ok=false;try{const r=await fetch(PLUS_URL,{method:'HEAD',cache:'no-store'});ok=r.ok}catch(_){}
 if(ok){fr.hidden=false;msg.hidden=true;fr.src=PLUS_URL;fr.dataset.ok='1';link.href=PLUS_URL}
 else{fr.hidden=true;link.href=PLUS_FALLBACK;msg.hidden=false;msg.innerHTML='<div class="plus41-card"><i class="fa-solid fa-cubes"></i><strong>3D PLUS</strong><p>Podrobný 3D model Opavy se zde zobrazí po nahrání složky <b>3dplus</b> do repozitáře <b>prerekhu-cloud/Mhd</b> (GitHub Pages).</p><a class="plus41-open" target="_blank" rel="noopener" href="'+PLUS_FALLBACK+'"><i class="fa-solid fa-up-right-from-square"></i> Otevřít 3D PLUS v nové kartě</a></div>'}
}
function closePlus(){document.body.classList.remove('plus-open');plusBtn?.classList.remove('plus-active')}

/* --- Navigace pěšky k zastávce (2D i 3D) --- */
/* ---------- Navigace k zastávce (styl navigace: manévry, hlas, sledování, náhled trasy) ---------- */
const NAV={origin:null,on:false,dest:null,pos:null,heading:null,route:null,cum:null,steps:[],watch:null,follow:true,lastRoute:0,routing:false,layer:L.layerGroup(),userM:null,u3:null,d3:null,o3:null,arrived:false,preview:-1,spoken:new Set(),off:0,err:null,approx:false,proj:null};
let navVoice=true;try{navVoice=localStorage.getItem('nav41-voice')!=='0'}catch(_){}
const navEl=document.createElement('div');navEl.id='nav41';navEl.hidden=true;document.body.appendChild(navEl);
const navTop=document.createElement('div');navTop.id='nav41-top';navTop.hidden=true;document.body.appendChild(navTop);
const WALK_V=1.3;
function navDecode(shape){try{return decodeValhallaPolyline(shape)}catch(_){return null}}
const OSRM_CZ={turn:'Odbočte',continue:'Pokračujte','new name':'Pokračujte',depart:'Vyjděte',arrive:'Cíl',merge:'Pokračujte',fork:'Držte se',roundabout:'Na kruhovém objezdu',rotary:'Na kruhovém objezdu','end of road':'Na konci cesty odbočte'};
const MOD_CZ={left:'vlevo',right:'vpravo','slight left':'mírně vlevo','slight right':'mírně vpravo','sharp left':'ostře vlevo','sharp right':'ostře vpravo',straight:'rovně',uturn:'otočte se'};
const MOD_KIND={left:'left',right:'right','slight left':'slight-left','slight right':'slight-right','sharp left':'sharp-left','sharp right':'sharp-right',straight:'straight',uturn:'uturn'};
const VAL_KIND={1:'depart',2:'depart',3:'depart',4:'arrive',5:'arrive',6:'arrive',7:'straight',8:'straight',9:'slight-right',10:'right',11:'sharp-right',12:'uturn',13:'uturn',14:'sharp-left',15:'left',16:'slight-left',17:'straight',18:'slight-right',19:'slight-left',20:'slight-right',21:'slight-left',22:'straight',23:'slight-right',24:'slight-left',25:'straight',26:'roundabout',27:'roundabout'};
const COMPASS=b=>['na sever','na severovýchod','na východ','na jihovýchod','na jih','na jihozápad','na západ','na severozápad'][Math.round(((b%360)+360)%360/45)%8];
function brg(a,b){const p=Math.PI/180,y=Math.sin((b[1]-a[1])*p)*Math.cos(b[0]*p),x=Math.cos(a[0]*p)*Math.sin(b[0]*p)-Math.sin(a[0]*p)*Math.cos(b[0]*p)*Math.cos((b[1]-a[1])*p);return(Math.atan2(y,x)/p+360)%360}
/* šipky manévrů (SVG, tah) */
const NAV_ICON={
 straight:'<path d="M12 21V4M6 10l6-6 6 6"/>',
 right:'<path d="M7 21v-8a4 4 0 0 1 4-4h9M16 5l4 4-4 4"/>',
 left:'<path d="M17 21v-8a4 4 0 0 0-4-4H4M8 5L4 9l4 4"/>',
 'slight-right':'<path d="M9 21v-7l8-8M11 5.5h6.5V12"/>',
 'slight-left':'<path d="M15 21v-7L7 6M13 5.5H6.5V12"/>',
 'sharp-right':'<path d="M8 3v9l9 7M17 12.5v6.5h-6.5"/>',
 'sharp-left':'<path d="M16 3v9l-9 7M7 12.5v6.5h6.5"/>',
 uturn:'<path d="M8 21V9a4 4 0 0 1 8 0v8M12 13l4 4 4-4"/>',
 roundabout:'<circle cx="12" cy="10" r="4"/><path d="M12 21v-7M16 10h5M18 7l3 3-3 3"/>',
 depart:'<circle cx="12" cy="5" r="2"/><path d="M12 8v6l-3 7M12 14l3 7M8 11l4-3 4 3"/>',
 arrive:'<path d="M6 21V4M6 4h11l-2 4 2 4H6"/>'};
const navIcon=k=>'<svg class="nav41-arrow" viewBox="0 0 24 24" aria-hidden="true">'+(NAV_ICON[k]||NAV_ICON.straight)+'</svg>';
async function navRoute(a,b){
 try{const r=await fetch('https://valhalla1.openstreetmap.de/route',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({locations:[{lat:a[0],lon:a[1]},{lat:b[0],lon:b[1]}],costing:'pedestrian',directions_options:{language:'cs-CZ',units:'kilometers'}})});
  if(r.ok){const j=await r.json(),leg=j.trip?.legs?.[0],pts=leg?.shape&&navDecode(leg.shape);if(pts?.length>1)return{pts,steps:(leg.maneuvers||[]).map(m=>({text:m.instruction,voice:m.verbal_pre_transition_instruction||m.instruction,kind:VAL_KIND[m.type]||'straight',street:(m.street_names||[])[0]||'',at:pts[Math.min(pts.length-1,m.begin_shape_index||0)]}))}}}catch(_){}
 try{const r=await fetch('https://router.project-osrm.org/route/v1/foot/'+a[1]+','+a[0]+';'+b[1]+','+b[0]+'?overview=full&geometries=geojson&steps=true');
  if(r.ok){const j=await r.json(),rt=j.routes?.[0];if(rt){const pts=rt.geometry.coordinates.map(c=>[c[1],c[0]]);const steps=rt.legs[0].steps.map(st=>{const m=st.maneuver||{},t=OSRM_CZ[m.type]||'Pokračujte',mod=MOD_CZ[m.modifier]||'';
   const kind=m.type==='arrive'?'arrive':m.type==='depart'?'depart':(m.type==='roundabout'||m.type==='rotary')?'roundabout':(MOD_KIND[m.modifier]||'straight');
   const text=m.type==='arrive'?'Jste u zastávky':((m.type==='depart'?'Vyjděte '+COMPASS(m.bearing_after||0):t+(mod?' '+mod:''))+(st.name?' na '+st.name:''));
   return{text,voice:text,kind,street:st.name||'',at:[m.location[1],m.location[0]]}});return{pts,steps}}}}catch(_){}
 return{pts:[a,b],steps:[{text:'Jděte přímo '+COMPASS(brg(a,b))+' k zastávce',voice:'Jděte přímo '+COMPASS(brg(a,b))+' k zastávce',kind:'depart',at:a},{text:'Jste u zastávky',kind:'arrive',at:b}],approx:true};
}
function projectOn(pts,cum,p){let best={d:1e9,s:0,i:1};const kx=Math.cos(p[0]*Math.PI/180)*111320,ky=110540;
 for(let i=1;i<pts.length;i++){const a=pts[i-1],b=pts[i],ax=(a[1]-p[1])*kx,ay=(a[0]-p[0])*ky,vx=(b[1]-a[1])*kx,vy=(b[0]-a[0])*ky,L2=vx*vx+vy*vy||1,t=clamp(-(ax*vx+ay*vy)/L2,0,1),d=Math.hypot(ax+vx*t,ay+vy*t);if(d<best.d)best={d,s:cum[i-1]+(cum[i]-cum[i-1])*t,i,t}}return best}
function pointAt(s){const R=NAV.route,C=NAV.cum;if(!R)return null;s=clamp(s,0,C.at(-1));let i=1;while(i<C.length-1&&C[i]<s)i++;const f=(s-C[i-1])/((C[i]-C[i-1])||1);return[R[i-1][0]+(R[i][0]-R[i-1][0])*f,R[i-1][1]+(R[i][1]-R[i-1][1])*f]}
/* poloha na trase: živá (GPS na trase) nebo náhled (začátek trasy / zvolený krok) */
function navProgress(){
 if(!NAV.route)return null;
 if(NAV.preview>=0){const st=NAV.steps[NAV.preview];return{s:st?st.s:0,d:0,live:false}}
 if(NAV.pos){const pr=projectOn(NAV.route,NAV.cum,[NAV.pos.lat,NAV.pos.lng]);return{...pr,live:true}}
 return{s:0,d:0,live:false};
}
function speak(t){if(!navVoice||!t||!window.speechSynthesis)return;try{speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(t);u.lang='cs-CZ';u.rate=1.02;const v=speechSynthesis.getVoices().find(v=>/^cs/i.test(v.lang));if(v)u.voice=v;speechSynthesis.speak(u)}catch(_){}}
const czM=m=>m<1000?Math.max(10,Math.round(m/10)*10)+' metrů':(m/1000).toFixed(1).replace('.',',')+' kilometru';
function navDraw(){
 NAV.layer.clearLayers();if(!NAV.on)return;
 const pr=navProgress();
 if(NAV.route){
  const done=pr&&pr.live?[...NAV.route.slice(0,pr.i),pointAt(pr.s)]:null,rest=pr&&pr.live?[pointAt(pr.s),...NAV.route.slice(pr.i)]:NAV.route;
  if(done&&done.length>1)L.polyline(done,{color:'#8d96a3',weight:7,opacity:.75,lineCap:'round',lineJoin:'round',interactive:false}).addTo(NAV.layer);
  L.polyline(rest,{color:'#1a1d22',weight:11,opacity:.18,lineCap:'round',lineJoin:'round',interactive:false}).addTo(NAV.layer);
  L.polyline(rest,{color:'#1d6fe8',weight:8,opacity:.95,lineCap:'round',lineJoin:'round',interactive:false}).addTo(NAV.layer);
  L.polyline(rest,{renderer:FLOW_R,color:'#fff',weight:3.5,dashArray:'9 12',lineCap:'butt',className:'flow41 nav',interactive:false}).addTo(NAV.layer);
  /* body manévrů */
  NAV.steps.forEach((st,i)=>{if(!i||st.kind==='arrive'||!st.at)return;L.circleMarker(st.at,{radius:4.5,color:'#1d6fe8',weight:2.5,fillColor:'#fff',fillOpacity:1,interactive:false}).addTo(NAV.layer)});
 }
 if(NAV.origin)L.marker([NAV.origin.lat,NAV.origin.lng],{icon:L.divIcon({className:'rt41',html:'<span class="rt41-pin a">A</span>',iconSize:[24,24],iconAnchor:[12,12]}),zIndexOffset:1100,interactive:false}).addTo(NAV.layer);
 L.marker([NAV.dest.lat,NAV.dest.lng],{icon:L.divIcon({className:'rt41',html:'<span class="nav41-dest"><i class="fa-solid fa-bus-simple"></i></span>',iconSize:[30,30],iconAnchor:[15,15]}),zIndexOffset:1200,interactive:false}).addTo(NAV.layer);
 if(NAV.preview>=0&&NAV.steps[NAV.preview]?.at)L.marker(NAV.steps[NAV.preview].at,{icon:L.divIcon({className:'rt41',html:'<span class="nav41-pv">'+navIcon(NAV.steps[NAV.preview].kind)+'</span>',iconSize:[34,34],iconAnchor:[17,17]}),zIndexOffset:1250,interactive:false}).addTo(NAV.layer);
 if(!map.hasLayer(NAV.layer))NAV.layer.addTo(map);
 if(NAV.userM&&NAV.pos)NAV.userM.addTo(NAV.layer);
 if(has3d()){try{
  const line=c=>c&&c.length>1?{type:'Feature',properties:{},geometry:{type:'LineString',coordinates:c.map(p=>[p[1],p[0]])}}:null;
  const pr2=navProgress(),rest=NAV.route?(pr2&&pr2.live?[pointAt(pr2.s),...NAV.route.slice(pr2.i)]:NAV.route):null,done=NAV.route&&pr2&&pr2.live?[...NAV.route.slice(0,pr2.i),pointAt(pr2.s)]:null;
  const fc={type:'FeatureCollection',features:[line(rest)].filter(Boolean)},fd={type:'FeatureCollection',features:[line(done)].filter(Boolean)};
  const src=map3d.getSource('nav41');if(src)src.setData(fc);else{map3d.addSource('nav41',{type:'geojson',data:fc});map3d.addLayer({id:'nav41-line',type:'line',source:'nav41',slot:'top',layout:{'line-cap':'round','line-join':'round'},paint:{'line-color':'#1d6fe8','line-width':['interpolate',['linear'],['zoom'],13,5,18,11],'line-opacity':.95,'line-emissive-strength':1}})}
  const sd=map3d.getSource('nav41-done');if(sd)sd.setData(fd);else{map3d.addSource('nav41-done',{type:'geojson',data:fd});map3d.addLayer({id:'nav41-done-line',type:'line',source:'nav41-done',slot:'top',layout:{'line-cap':'round','line-join':'round'},paint:{'line-color':'#8d96a3','line-width':['interpolate',['linear'],['zoom'],13,4,18,9],'line-opacity':.8,'line-emissive-strength':1}})}
  addFlow3d('nav41','nav41-flow',null,3);
  if(!NAV.d3){const el=document.createElement('div');el.className='rt41-3d';el.innerHTML='<span class="nav41-dest"><i class="fa-solid fa-bus-simple"></i></span>';NAV.d3=new mapboxgl.Marker({element:el,anchor:'center'})}NAV.d3.setLngLat([NAV.dest.lng,NAV.dest.lat]).addTo(map3d);
  try{NAV.o3?.remove()}catch(_){}NAV.o3=null;if(NAV.origin){const eo=document.createElement('div');eo.className='rt41-3d';eo.innerHTML='<span class="rt41-pin a">A</span>';NAV.o3=new mapboxgl.Marker({element:eo,anchor:'center'}).setLngLat([NAV.origin.lng,NAV.origin.lat]).addTo(map3d)}
 }catch(e){console.warn('[nav3d]',e)}}
}
function navHeading(){
 const pr=navProgress();
 if(pr&&pr.live&&NAV.route&&pr.d<30){const i=Math.min(pr.i,NAV.route.length-1);return brg(NAV.route[i-1]||NAV.route[0],NAV.route[i])}
 return NAV.heading;
}
function navUser(){
 if(!NAV.pos)return;const ll=[NAV.pos.lat,NAV.pos.lng],hd=navHeading();
 if(!NAV.userM)NAV.userM=L.marker(ll,{icon:L.divIcon({className:'rt41',html:'<span class="nav41-me"><i></i></span>',iconSize:[26,26],iconAnchor:[13,13]}),zIndexOffset:1300,interactive:false});
 NAV.userM.setLatLng(ll);if(!NAV.layer.hasLayer(NAV.userM))NAV.userM.addTo(NAV.layer);
 const el=NAV.userM.getElement?.();if(el){el.classList.toggle('has-hd',hd!=null);if(hd!=null)el.style.setProperty('--hd',hd+'deg')}
 if(has3d()){if(!NAV.u3){const e3=document.createElement('div');e3.className='rt41-3d';e3.innerHTML='<span class="nav41-me"><i></i></span>';NAV.u3=new mapboxgl.Marker({element:e3,anchor:'center',rotationAlignment:'map'})}NAV.u3.setLngLat([NAV.pos.lng,NAV.pos.lat]).addTo(map3d);const ie=NAV.u3.getElement().firstChild;ie.classList.toggle('has-hd',hd!=null);if(hd!=null)ie.style.setProperty('--hd',hd+'deg')}
 if(NAV.follow&&NAV.preview<0){if(is3dOn()&&has3d())map3d.easeTo({center:[NAV.pos.lng,NAV.pos.lat],zoom:Math.max(map3d.getZoom(),17.4),pitch:58,bearing:hd??map3d.getBearing(),duration:700});else map.setView(ll,Math.max(map.getZoom(),17),{animate:true})}
}
async function navReroute(force){
 if(!NAV.on||(!NAV.pos&&!NAV.origin)||NAV.routing)return;if(!force&&Date.now()-NAV.lastRoute<10000)return;
 NAV.routing=true;NAV.lastRoute=Date.now();if(!force)navPanel();
 try{const st0=NAV.pos||NAV.origin;const r=await navRoute([st0.lat,st0.lng],[NAV.dest.lat,NAV.dest.lng]);if(!NAV.on)return;NAV.route=r.pts;NAV.steps=r.steps;NAV.approx=!!r.approx;NAV.cum=[0];for(let i=1;i<r.pts.length;i++)NAV.cum.push(NAV.cum[i-1]+dist(r.pts[i-1],r.pts[i]));
  NAV.steps.forEach(st=>{st.s=projectOn(NAV.route,NAV.cum,st.at).s});NAV.spoken=new Set();NAV.off=0;
  if(force&&NAV.steps[0])speak('Navigace k zastávce '+NAV.dest.name+'. '+(NAV.steps[0].voice||NAV.steps[0].text));
  navDraw();navUser();navPanel()}
 finally{NAV.routing=false}
}
function navState(){
 const pr=navProgress();if(!pr||!NAV.route)return null;
 const total=NAV.cum.at(-1),rem=Math.max(0,total-pr.s)+(pr.live?Math.min(pr.d,60):0);
 let ni=NAV.steps.findIndex(st=>st.s>pr.s+4);if(ni<0)ni=NAV.steps.length-1;
 if(NAV.preview>=0)ni=NAV.preview;
 const cur=NAV.steps[ni],after=NAV.steps[ni+1]||null,toNext=Math.max(0,(cur?.s??total)-pr.s);
 return{pr,rem,total,ni,cur,after,toNext};
}
function navTopHTML(S){
 if(NAV.arrived)return '<div class="nt41 done"><span class="nt41-ico">'+navIcon('arrive')+'</span><div class="nt41-txt"><b>Jste u zastávky</b><span>'+h(NAV.dest.name)+'</span></div></div>';
 if(NAV.err&&!NAV.origin)return '<div class="nt41 warn"><span class="nt41-ico"><i class="fa-solid fa-location-crosshairs"></i></span><div class="nt41-txt"><b>Poloha</b><span>'+h(NAV.err)+'</span></div></div>';
 if(!S)return '<div class="nt41"><span class="nt41-ico"><i class="fa-solid fa-spinner fa-spin"></i></span><div class="nt41-txt"><b>Hledám trasu…</b><span>'+h(NAV.dest.name)+'</span></div></div>';
 const c=S.cur,pv=NAV.preview>=0;
 const dist0=pv?(c&&NAV.steps[NAV.preview-1]?fmtDist(Math.max(0,c.s-NAV.steps[NAV.preview-1].s)):''):(S.pr.live||NAV.origin?fmtDist(S.toNext):'');
 return '<div class="nt41'+(NAV.routing&&NAV.off?' warn':'')+'"><span class="nt41-ico">'+navIcon(c?.kind)+'</span><div class="nt41-txt">'
  +(NAV.routing&&NAV.off?'<b>Přepočítávám trasu…</b><span>Sešli jste z trasy</span>':'<b>'+(dist0?h(dist0):'')+'</b><span>'+h(c?.text||'')+'</span>')+'</div>'
  +(pv?'<div class="nt41-pv"><button type="button" class="nt41-prev" aria-label="Předchozí krok"'+(NAV.preview<=0?' disabled':'')+'><i class="fa-solid fa-chevron-left"></i></button><small>'+(NAV.preview+1)+'/'+NAV.steps.length+'</small><button type="button" class="nt41-next" aria-label="Další krok"'+(NAV.preview>=NAV.steps.length-1?' disabled':'')+'><i class="fa-solid fa-chevron-right"></i></button></div>':'')
  +'</div>'+(S.after&&!pv&&S.after.kind!=='arrive'?'<div class="nt41-then">Potom <span>'+navIcon(S.after.kind)+'</span> '+h(S.after.street?S.after.street:S.after.text)+'</div>':'');
}
function navPanel(){
 if(!NAV.on){navEl.hidden=true;navTop.hidden=true;return}navEl.hidden=false;navTop.hidden=false;
 const S=navState(),s=D.stop(NAV.dest.name);
 /* živá navigace: příjezd, sejití z trasy, hlasové pokyny */
 if(S&&S.pr.live&&!NAV.arrived){
  if(dist([NAV.pos.lat,NAV.pos.lng],[NAV.dest.lat,NAV.dest.lng])<20||S.rem<12){NAV.arrived=true;speak('Jste u zastávky '+NAV.dest.name+'.');try{navigator.vibrate?.([120,60,120])}catch(_){}}
  else{if(S.pr.d>35){NAV.off++;if(NAV.off>=2)navReroute(false)}else NAV.off=0;
   const c=S.cur;if(c&&!NAV.spoken.has(S.ni)&&S.toNext<40&&S.ni>0){NAV.spoken.add(S.ni);speak((S.toNext>12?'Za '+czM(S.toNext)+' ':'')+(c.voice||c.text))}}
 }
 navTop.innerHTML=navTopHTML(S);
 const min=S?Math.max(1,Math.round(S.rem/WALK_V/60)):null,eta=S?new Date(Date.now()+S.rem/WALK_V*1000).toLocaleTimeString('cs-CZ',{hour:'2-digit',minute:'2-digit'}):'–';
 const steps=NAV.steps.map((st,i)=>'<button type="button" class="nb41-step'+(S&&i===S.ni?' cur':'')+'" data-i="'+i+'"><span>'+navIcon(st.kind)+'</span><em>'+h(st.text)+'</em>'+(i&&NAV.steps[i-1]?'<small>'+fmtDist(Math.max(0,(st.s||0)-(NAV.steps[i-1].s||0)))+'</small>':'')+'</button>').join('');
 navEl.innerHTML=(NAV.arrived
   ?'<div class="nb41-arr"><div><b>'+h(NAV.dest.name)+'</b>'+(s?'<span class="nav41-lines">'+chips(s.lineList.filter(n=>!D.line(n)?.train),10)+'</span>':'')+'</div><button type="button" class="nb41-dep"><i class="fa-regular fa-clock"></i> Odjezdy</button></div>'
   :'<div class="nb41-main"><div class="nb41-time"><b>'+(min==null?'–':min)+'</b><small>min</small></div><div class="nb41-info"><span class="nb41-meta">'+(S?fmtDist(S.rem):'–')+' · příchod '+eta+'</span><strong>'+h(NAV.dest.name)+'</strong>'
    +(NAV.origin&&!(S&&S.pr.live)?'<span class="nav41-from"><i class="fa-solid fa-location-dot"></i> z: '+h(NAV.origin.label||'zadané adresy')+'</span>':(s?'<span class="nav41-lines">'+chips(s.lineList.filter(n=>!D.line(n)?.train),8)+'</span>':''))+'</div></div>'
    +(NAV.approx?'<div class="nav41-note"><i class="fa-solid fa-circle-info"></i> Pěší trasa po ulicích není dostupná – zobrazen přímý směr.</div>':'')
    +'<div class="nb41-steps" hidden>'+steps+'</div>')
  +'<div class="nav41-btns">'
   +(NAV.arrived?'':(NAV.origin&&!(S&&S.pr.live)?'<button type="button" class="nb41-pv'+(NAV.preview>=0?' on':'')+'" title="Projít trasu po krocích"><i class="fa-solid fa-route"></i> '+(NAV.preview>=0?'Přehled':'Projít trasu')+'</button>':'<button type="button" class="nav41-follow'+(NAV.follow?' on':'')+'" title="Sledovat polohu"><i class="fa-solid fa-location-arrow"></i></button>')
   +'<button type="button" class="nb41-voice'+(navVoice?' on':'')+'" title="Hlasové pokyny" aria-pressed="'+navVoice+'"><i class="fa-solid fa-volume-'+(navVoice?'high':'xmark')+'"></i></button>'
   +'<button type="button" class="nb41-list" title="Kudy jít"><i class="fa-solid fa-list-ol"></i></button>')
   +'<button type="button" class="nav41-end"><i class="fa-solid fa-xmark"></i> Ukončit</button></div>';
 const q=c=>navEl.querySelector(c);
 q('.nav41-end').onclick=()=>navStop();
 q('.nav41-follow')&&(q('.nav41-follow').onclick=()=>{NAV.follow=!NAV.follow;navPanel();navUser()});
 q('.nb41-voice')&&(q('.nb41-voice').onclick=()=>{navVoice=!navVoice;try{localStorage.setItem('nav41-voice',navVoice?'1':'0')}catch(_){}if(!navVoice)try{speechSynthesis.cancel()}catch(_){}navPanel()});
 q('.nb41-list')&&(q('.nb41-list').onclick=()=>{const l=q('.nb41-steps');l.hidden=!l.hidden;NAV.listOpen=!l.hidden;q('.nb41-list').classList.toggle('on',!l.hidden)});
 if(NAV.listOpen&&q('.nb41-steps')){q('.nb41-steps').hidden=false;q('.nb41-list')?.classList.add('on')}
 q('.nb41-pv')&&(q('.nb41-pv').onclick=()=>navPreview(NAV.preview>=0?-1:0));
 q('.nb41-dep')&&(q('.nb41-dep').onclick=()=>{try{window.openDeparturesPanel?.(NAV.dest.name)}catch(_){}});
 navEl.querySelectorAll('.nb41-step').forEach(b=>b.onclick=()=>navPreview(Number(b.dataset.i)));
 navTop.querySelector('.nt41-prev')&&(navTop.querySelector('.nt41-prev').onclick=()=>navPreview(NAV.preview-1));
 navTop.querySelector('.nt41-next')&&(navTop.querySelector('.nt41-next').onclick=()=>navPreview(NAV.preview+1));
}
/* náhled trasy po krocích (hlavně u navigace ze zadané adresy) */
function navPreview(i){
 if(!NAV.route)return;NAV.preview=i<0?-1:clamp(i,0,NAV.steps.length-1);NAV.follow=NAV.preview<0&&!!NAV.pos;
 navDraw();navPanel();
 if(NAV.preview>=0){const st=NAV.steps[NAV.preview],nx=NAV.steps[NAV.preview+1],b=nx?brg(st.at,nx.at):null;
  if(is3dOn()&&has3d())map3d.easeTo({center:[st.at[1],st.at[0]],zoom:18,pitch:55,bearing:b??map3d.getBearing(),duration:800});else map.setView(st.at,18,{animate:true});
  speak(st.voice||st.text)}
 else navFit();
}
function navFit(){try{if(NAV.route){const b=L.latLngBounds(NAV.route);if(is3dOn()&&has3d())map3d.fitBounds([[b.getWest(),b.getSouth()],[b.getEast(),b.getNorth()]],{padding:{top:170,bottom:230,left:50,right:50},duration:800,maxZoom:17.5,pitch:40});else map.fitBounds(b,{paddingTopLeft:[40,170],paddingBottomRight:[40,230],maxZoom:17})}}catch(_){}}
function navStart(dest){
 navStop(true);NAV.on=true;NAV.dest=dest;NAV.err=null;NAV.arrived=false;NAV.follow=true;NAV.route=null;NAV.steps=[];NAV.preview=-1;NAV.listOpen=false;NAV.spoken=new Set();NAV.off=0;document.body.classList.add('nav-on');
 /* uvolnit obrazovku jako v navigaci */
 $('network-panel')?.classList.remove('open');try{map.closePopup()}catch(_){}
 NAV.origin=dest.from&&Number.isFinite(dest.from.lat)?dest.from:null;
 navDraw();navPanel();
 /* navigace ze zadané adresy: trasa vede od ní; vlastní poloha se použije, jakmile je uživatel přímo na trase */
 if(NAV.origin){NAV.follow=false;navReroute(true).then(navFit);
  if(navigator.geolocation)NAV.watch=navigator.geolocation.watchPosition(p=>{if(!NAV.route)return;const q=[p.coords.latitude,p.coords.longitude];if(projectOn(NAV.route,NAV.cum,q).d<60){const first=!NAV.pos;NAV.pos={lat:q[0],lng:q[1],acc:p.coords.accuracy};if(first){NAV.preview=-1;NAV.follow=true}navDraw();navUser();navPanel()}},()=>{},{enableHighAccuracy:true,maximumAge:3000,timeout:20000});
  return}
 if(!navigator.geolocation){NAV.err='Toto zařízení nepodporuje zjištění polohy.';navPanel();return}
 NAV.watch=navigator.geolocation.watchPosition(p=>{const first=!NAV.pos,np={lat:p.coords.latitude,lng:p.coords.longitude,acc:p.coords.accuracy};
   if(NAV.pos&&dist([NAV.pos.lat,NAV.pos.lng],[np.lat,np.lng])>4)NAV.heading=brg([NAV.pos.lat,NAV.pos.lng],[np.lat,np.lng]);if(Number.isFinite(p.coords.heading)&&p.coords.speed>0.5)NAV.heading=p.coords.heading;
   NAV.pos=np;NAV.err=null;if(first){navReroute(true).then(()=>{navFit();setTimeout(()=>{if(NAV.on&&NAV.follow)navUser()},1600)})}else{navDraw();navUser();navPanel()}},
  e=>{NAV.err=e.code===1?'Přístup k poloze byl zamítnut – povolte jej v nastavení prohlížeče.':'Polohu se nepodařilo zjistit.';navPanel()},{enableHighAccuracy:true,maximumAge:2000,timeout:20000});
}
function navStop(silent){
 if(NAV.watch!=null)try{navigator.geolocation.clearWatch(NAV.watch)}catch(_){}NAV.watch=null;NAV.on=false;NAV.pos=null;NAV.route=null;NAV.origin=null;NAV.preview=-1;NAV.heading=null;
 try{speechSynthesis.cancel()}catch(_){}
 NAV.layer.clearLayers();try{map.removeLayer(NAV.layer)}catch(_){}NAV.userM=null;
 try{NAV.u3?.remove();NAV.d3?.remove();NAV.o3?.remove();NAV.u3=null;NAV.o3=null;['nav41','nav41-done'].forEach(id=>{const src=map3d?.getSource?.(id);if(src)src.setData({type:'FeatureCollection',features:[]})});if(!silent&&is3dOn()&&has3d())map3d.easeTo({pitch:45,bearing:map3d.getBearing(),duration:600})}catch(_){}
 document.body.classList.remove('nav-on');navEl.hidden=true;navTop.hidden=true;
}
try{map.on('dragstart',()=>{if(NAV.on&&NAV.follow){NAV.follow=false;navPanel()}})}catch(_){}
setInterval(()=>{if(NAV.on&&!NAV.err&&NAV.preview<0)navPanel()},5000);
/* po přepnutí 2D/3D přenést navigaci a hledání do aktuální mapy */
['btn-model-3d','btn-map-2d'].forEach(id=>$(id)?.addEventListener('click',()=>[600,1500].forEach(t=>setTimeout(()=>{if(NAV.on){navDraw();navUser()}},t))));
window.__nav41={start:navStart,stop:navStop,state:NAV,preview:navPreview};

window.__m41={startRide41,planFor,pickVehicle,showVB,push3d,recenter,is3dOn,get state(){return{rideYaw,ridePitch,rideZoom,rideMult,regioOn,trainOn}},applyRegio,TRAIN_NUMS,REGIO_NUMS};

/* ---------- Oficiální polohy nástupišť MHD Opava (mapy.opava-city.cz) ----------
   Stejný zdroj jako mhd-opava-kompletne-opraveno: u každé zastávky 1–3 sloupky. Načítá se za běhu
   (a ukládá do prohlížeče). Sloupky zastávky se nahradí oficiálními a každé lince v každém směru se
   přiřadí ten sloupek, který leží u její trasy na pravé straně ve směru jízdy (ne přes silnici). */
(function(){
 const URL='https://mapy.opava-city.cz/server/rest/services/external/info_bezbarierovemhd_V/MapServer/0/query?where=1%3D1&outFields=*&returnGeometry=true&outSR=4326&f=geojson';
 const KEY='mhd41-official-v1',MAX_AGE=7*864e5;
 const parse=geo=>{const out=[];for(const f of geo.features||[]){const p=f.properties||{},c=f.geometry?.coordinates;if(!c||c.length<2)continue;const raw=String(p.NAZEV||p.nazev||'').trim();const lat=+c[1],lng=+c[0];if(!raw||!Number.isFinite(lat)||!Number.isFinite(lng))continue;out.push([raw,+lat.toFixed(6),+lng.toFixed(6)])}return out};
 const XY=(p,o)=>[(p[1]-o[1])*111320*Math.cos(o[0]*Math.PI/180),(p[0]-o[0])*110540];
 /* průmět bodu na trasu: {d, i, t, side} – side <0 = vpravo ve směru trasy */
 function onPath(pts,p,from=0,to=pts.length-1){let b=null;for(let i=Math.max(0,from);i<Math.min(to,pts.length-1);i++){
   /* rychlé vyřazení vzdálených úseků (> ~450 m) */
   const y0=pts[i][0]-p[0],y1=pts[i+1][0]-p[0],x0=pts[i][1]-p[1],x1=pts[i+1][1]-p[1];if((y0>.004&&y1>.004)||(y0<-.004&&y1<-.004)||(x0>.006&&x1>.006)||(x0<-.006&&x1<-.006))continue;
   const a=XY(pts[i],p),c=XY(pts[i+1],p),vx=c[0]-a[0],vy=c[1]-a[1],L2=vx*vx+vy*vy||1,t=Math.max(0,Math.min(1,-(a[0]*vx+a[1]*vy)/L2)),px=a[0]+vx*t,py=a[1]+vy*t,d=Math.hypot(px,py);
   if(!b||d<b.d)b={d,i,t,side:vx*(-a[1]-vy*t)-vy*(-a[0]-vx*t)}}return b}
 function routeFor(n,arr,k){/* trasa linky, po které vozidlo opravdu projíždí kolem zastávky ve správném pořadí */
  const rs=(typeof gpxRoutes!=='undefined'&&gpxRoutes[n])||[];let best=null;const P=arr[k-1],C=arr[k],N=arr[k+1];
  for(const r of rs){const pts=r.points||[];if(pts.length<2)continue;const pc=onPath(pts,[C.lat,C.lng]);if(!pc||pc.d>90)continue;
   let sc=pc.d;if(P){const pp=onPath(pts,[P.lat,P.lng],0,pc.i+1);if(!pp||pp.d>150)sc+=200}if(N){const pn=onPath(pts,[N.lat,N.lng],pc.i,pts.length-1);if(!pn||pn.d>150)sc+=200}
   if(!best||sc<best.sc)best={sc,pts,pc}}return best}
 let applied=false;
 function apply(list){
  if(applied||!list?.length)return;applied=true;const T0=performance.now();
  const by=new Map();for(const [raw,lat,lng] of list){const k=D.key(raw);if(!D.stops.has(k))continue;if(!by.has(k))by.set(k,[]);const a=by.get(k);if(!a.some(o=>dist([o.lat,o.lng],[lat,lng])<3))a.push({lat,lng})}
  const NP=new Map();let side=0,near=0,stops=0,poles=0;
  for(const [k,offs] of by){const s=D.stops.get(k);stops++;poles+=offs.length;
   NP.set(k,offs.map((o,j)=>{const old=s.plats.reduce((b,p)=>!b||dist([p.lat,p.lng],[o.lat,o.lng])<dist([b.lat,b.lng],[o.lat,o.lng])?p:b,null);
    const np={i:D.plats.length,id:'s41-o'+D.plats.length,name:s.name,key:k,lat:o.lat,lng:o.lng,request:old?old.request:s.request,primary:j===0,lines:new Set(),lineList:[],city:s.city,regional:s.regional,train:s.train,official:true};D.plats.push(np);return np}))}
  for(const l of Object.values(D.lines))for(const arr of [l.fp,l.bp,...(l.variants||[])]){
   const orig=arr.slice();
   for(let k=0;k<arr.length;k++){const cand=NP.get(arr[k].key);if(!cand)continue;
    let pick=null;const R=cand.length>1?routeFor(l.num,orig,k):null;
    if(R){let bs=1e9;for(const o of cand){const pr=onPath(R.pts,[o.lat,o.lng],Math.max(0,R.pc.i-6),R.pc.i+7);if(!pr)continue;const sc=pr.d+(pr.side>0?45:0)+0.25*dist([o.lat,o.lng],[orig[k].lat,orig[k].lng]);if(sc<bs){bs=sc;pick=o}}if(pick)side++}
    if(!pick){pick=cand.reduce((b,o)=>!b||dist([o.lat,o.lng],[orig[k].lat,orig[k].lng])<dist([b.lat,b.lng],[orig[k].lat,orig[k].lng])?o:b,null);near++}
    arr[k]=pick;pick.lines.add(l.num)}}
  for(const [k,np] of NP){const s=D.stops.get(k);s.plats=np;for(const p of np)p.lineList=D.sortLines(p.lines)}
  try{window.__manual41?.(true)}catch(e){console.warn('[ruční polohy]',e)}
  /* délky úseků plánovače, zastávky jízdy vozidlem a značky 2D/3D z nových nástupišť */
  try{for(const P of window.__plan41?.PAT||[]){const c=[0];for(let i=1;i<P.seq.length;i++)c.push(c[i-1]+dist([P.seq[i-1].lat,P.seq[i-1].lng],[P.seq[i].lat,P.seq[i].lng]));P.cum=c}}catch(_){}
  try{for(const v of vehicles())if(v!==rideBus)v._plans41=null}catch(_){}
  try{officialStops.length=0;for(const p of window.__markerPlats41())officialStops.push({id:p.id,name:p.name,rawName:p.name,direction:'',desc:'',lat:p.lat,lng:p.lng,request:p.request,key:p.key,lines:p.lineList});renderOfficialStopMarkers()}catch(e){console.warn('[nástupiště]',e)}
  try{if(has3d())build3dStops();update3dStops()}catch(_){}
  window.__off41={stops,poles,bySide:side,byDistance:near,total:list.length,ms:Math.round(performance.now()-T0)};
 }
 let cached=null;try{cached=JSON.parse(localStorage.getItem(KEY)||'null')}catch(_){}
 /* až po vykreslení stránky, ať start aplikace nezasekne */
 const later=f=>(window.requestIdleCallback?requestIdleCallback(f,{timeout:2500}):setTimeout(f,1200));
 if(cached?.list?.length)later(()=>apply(cached.list));
 if(!cached||Date.now()-(cached.t||0)>MAX_AGE){
  fetch(URL,{cache:'no-cache'}).then(r=>{if(!r.ok)throw Error('HTTP '+r.status);return r.json()}).then(geo=>{const list=parse(geo);if(!list.length)return;try{localStorage.setItem(KEY,JSON.stringify({t:Date.now(),list}))}catch(_){}
   if(!applied)apply(list)}).catch(e=>console.info('[nástupiště] oficiální polohy nejsou dostupné:',e.message));
 }
 window.__official41={apply,parse};
})();

/* ---------- 3D: ikonky východu/západu slunce, počasí jen ikonami, Zataženo (šedá obloha) ---------- */
(function(){
 const sun=up=>'<svg class="fx41-sun" viewBox="0 0 24 24" aria-hidden="true"><path d="M3 21h18M6.5 17.5a5.5 5.5 0 0 1 11 0M1.5 17.5h2M20.5 17.5h2M4.6 12.1l1.4 1.4M19.4 12.1L18 13.5"/><path d="'+(up?'M12 10V2.5M8.8 5.6L12 2.4l3.2 3.2':'M12 2.5V10M8.8 6.9l3.2 3.2 3.2-3.2')+'"/></svg>';
 const dawn=$('fx-time-dawn'),dusk=$('fx-time-dusk');
 if(dawn){dawn.innerHTML=sun(true);dawn.title='Východ slunce';dawn.setAttribute('aria-label','Východ slunce')}
 if(dusk){dusk.innerHTML=sun(false);dusk.title='Západ slunce';dusk.setAttribute('aria-label','Západ slunce')}
 const W={none:$('fx-weather-none'),rain:$('fx-weather-rain'),snow:$('fx-weather-snow')};
 for(const b of Object.values(W))if(b){b.querySelector('span')?.remove();b.setAttribute('aria-label',b.title);b.classList.add('fx41-ico')}
 let cloudy=W.none&&$('fx-weather-cloudy');
 if(W.none&&!cloudy){cloudy=document.createElement('button');cloudy.id='fx-weather-cloudy';cloudy.className=W.none.className;cloudy.title='Zataženo';cloudy.setAttribute('aria-label','Zataženo');cloudy.innerHTML='<i class="fa-solid fa-cloud text-[10px]"></i>';cloudy.classList.remove('fx-active');W.none.after(cloudy)}
 let wx='none',saved;
 const timeNow=()=>['night','dusk','dawn'].find(k=>$('fx-time-'+k)?.classList.contains('fx-active'))||'day';
 function sky(gray){
  if(!has3d())return;
  try{if(gray){if(saved===undefined)saved=map3d.getFog?.()||null;const n=timeNow();
    const pal=n==='night'?['#262a31','#1d2027','#15171c']:n==='dusk'?['#8d8a8c','#6f6e74','#56565c']:['#c4c8cd','#a3a9b0','#8f959c'];
    map3d.setFog({color:pal[0],'high-color':pal[1],'space-color':pal[2],'horizon-blend':.3,'star-intensity':0,range:[0.5,7]});try{map3d.setConfigProperty('basemap','theme','faded')}catch(_){}}
   else if(saved!==undefined){map3d.setFog(saved);saved=undefined;try{map3d.setConfigProperty('basemap','theme','default')}catch(_){}}}catch(e){console.warn('[zataženo]',e)}
 }
 function setW(k){wx=k;for(const [n,b] of Object.entries({...W,cloudy}))b?.classList.toggle('fx-active',n===k);sky(k!=='none')}
 cloudy?.addEventListener('click',()=>{try{map3d?.setRain?.(null);map3d?.setSnow?.(null)}catch(_){}setW('cloudy')});
 for(const k of ['none','rain','snow'])W[k]?.addEventListener('click',()=>setTimeout(()=>setW(k),0));
 /* po změně denní doby nebo nahrání stylu znovu obarvit oblohu */
 ['dawn','day','dusk','night'].forEach(k=>$('fx-time-'+k)?.addEventListener('click',()=>setTimeout(()=>{if(wx!=='none'){saved=undefined;sky(true)}},60)));
 setInterval(()=>{try{if(wx!=='none'&&has3d()&&map3d.__wx41!==map3d){map3d.__wx41=map3d;map3d.on('style.load',()=>{if(wx!=='none'){saved=undefined;sky(true)}})}}catch(_){}},2000);
})();

/* ---------- Jízda vozidlem: tlačítko + s výběrem linky (náhodná jízda zůstává na hlavním tlačítku) ---------- */
(function(){
 const start=$('ride-start-btn');if(!start||$('ride-pick-btn'))return;
 const row=document.createElement('div');row.className='ride41-row';start.before(row);row.appendChild(start);
 const plus=document.createElement('button');plus.id='ride-pick-btn';plus.type='button';plus.className='ride41-plus';plus.title='Vybrat linku pro jízdu';plus.setAttribute('aria-label',plus.title);plus.innerHTML='<i class="fa-solid fa-plus"></i>';row.appendChild(plus);
 const sheet=document.createElement('div');sheet.id='pick41';sheet.hidden=true;sheet.setAttribute('role','dialog');sheet.setAttribute('aria-label','Výběr linky pro jízdu vozidlem');document.body.appendChild(sheet);
 const groups=()=>{const L=Object.values(D.lines);return[
  ['Trolejbusy',L.filter(l=>l.city&&l.mode==='trolleybus')],
  ['Autobusy MHD',L.filter(l=>l.city&&l.mode!=='trolleybus')],
  ['Regionální autobusy',L.filter(l=>!l.city&&!l.train)],
  ['Vlaky',L.filter(l=>l.train)]].map(([t,ls])=>[t,D.sortLines(ls.map(l=>l.num))])};
 const usable=n=>!D.line(n)?.suspended&&!night(n);
 function render(){
  sheet.innerHTML='<div class="pick41-card"><div class="pick41-head"><div><small>Jízda vozidlem</small><strong>Vyberte linku</strong></div><button type="button" class="pick41-x" aria-label="Zavřít"><i class="fa-solid fa-xmark"></i></button></div>'
   +'<div class="pick41-body">'+groups().map(([t,ns])=>'<div class="pick41-grp"><div class="pick41-t">'+h(t)+'</div><div class="pick41-chips">'+ns.map(n=>'<button type="button" class="pick41-l'+(usable(n)?'':' off')+'" data-n="'+h(n)+'" '+(usable(n)?'':'disabled title="'+h(D.line(n)?.suspended||'Linka nemá zakreslenou trasu')+'"')+'>'+chip(n,'big')+'</button>').join('')+'</div></div>').join('')+'</div>'
   +'<button type="button" class="pick41-rand"><i class="fa-solid fa-shuffle"></i> Náhodná linka</button></div>';
  sheet.querySelector('.pick41-x').onclick=close;sheet.onclick=e=>{if(e.target===sheet)close()};
  sheet.querySelector('.pick41-rand').onclick=()=>{close();startRide41()};
  sheet.querySelectorAll('.pick41-l:not(.off)').forEach(b=>b.onclick=()=>{close();rideLine(b.dataset.n)});
 }
 function open(){render();sheet.hidden=false;document.body.classList.add('pick41-on')}
 function close(){sheet.hidden=true;document.body.classList.remove('pick41-on')}
 plus.onclick=e=>{e.preventDefault();open()};
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!sheet.hidden)close()});
 async function rideLine(n){
  try{
   if(!is3dOn())show3D();
   await waitFor(()=>has3d(),60000,'3D mapa se nenačetla. Zkontrolujte připojení a zkuste to znovu.');
   await waitFor(()=>vehicles().some(x=>x.ls&&x.length),15000,'Vozidla ještě nejsou připravena.');
   const all=vehicles().filter(v=>v.line===n&&v.ls&&v.length);
   /* přednost má vozidlo, které právě jede po mapě (jízda z jeho polohy); jinak vozidlo na vyžádání od začátku linky */
   const live=all.filter(v=>!v.hidden41&&!v.pick41&&(planFor(v)?.stops.length||0)>=2);
   const v=live.length?live[Math.floor(Math.random()*live.length)]:all.find(v=>v.pick41)||all[0];
   if(!v)throw Error('Pro linku '+n+' není k dispozici vozidlo.');
   await startRide41(v,live.includes(v)?v.distance:null);
   try{applySpeeds()}catch(_){}
  }catch(e){console.warn('[Výběr linky]',e);rideErr(e)}
 }
 const er=window.endRide;window.endRide=endRide=function(){const r=er.apply(this,arguments);try{applySpeeds()}catch(_){}return r};
 window.__pick41={open,close,rideLine};
})();

/* ---------- Telefon na výšku: dolní lišta záložek, panely jako listy s úchytem (zobáček) ---------- */
(function(){
 const MQ=matchMedia('(max-width:700px) and (orientation:portrait), (max-height:500px) and (orientation:landscape) and (max-width:1100px)');
 const B=document.body;
 /* dolní lišta */
 const tab=document.createElement('nav');tab.id='tab41';tab.setAttribute('aria-label','Hlavní nabídka');
 const T=[['search','fa-magnifying-glass','Hledat'],['dep','fa-clock','Odjezdy'],['net','fa-bus','Síť'],['ride','fa-route','Jízda',1],['more','fa-ellipsis','Více']];
 tab.innerHTML=T.map(([k,i,t,d3])=>'<button type="button" data-t="'+k+'"><i class="fa-solid '+i+'"></i><span>'+t+'</span>'+(d3?'<sup class="b3d41" title="Týká se 3D mapy">3D</sup>':'')+'</button>').join('');
 document.body.appendChild(tab);
 /* nabídka Více */
 const more=document.createElement('div');more.id='more41';more.hidden=true;document.body.appendChild(more);
 const isOpen=id=>!!$(id)?.classList.contains('open');
 const SHEETS=['search-panel','network-panel'];
 function closeAll(except){
  if(except!=='search'&&isOpen('search-panel'))try{closeSearch()}catch(_){$('search-panel')?.classList.remove('open')}
  if(except!=='net'&&isOpen('network-panel'))$('btn-net')?.click();
  if(except!=='dep'&&(isOpen('departures-panel')||window.__dep42?.isOpen()))try{window.closeDeparturesPanel()}catch(_){}
  if(except!=='garage'&&isOpen('garage-panel'))try{setGarage(false)}catch(_){}
  if(except!=='info'&&isOpen('bedekr-panel'))$('btn-bedekr')?.click();
  if(except!=='help')try{window.__help41?.close()}catch(_){}
  if(except!=='more')more.hidden=true;
  try{window.__pick41?.close()}catch(_){}
 }
 function renderMore(){
  const dark=B.classList.contains('dark'),r=$('btn-r')?.classList.contains('regio-active'),v=$('btn-v')?.classList.contains('train-active');
  const it=(k,ic,t,on)=>'<button type="button" data-m="'+k+'" class="'+(on?'on':'')+'"><span>'+ic+'</span><em>'+t+'</em></button>';
  more.innerHTML='<div class="more41-card">'
   +it('fav','<i class="fa-solid fa-star"></i>','Moje místa')
   +it('garage','<i class="fa-solid fa-warehouse"></i>','Garáž')
   +it('info','<i class="fa-solid fa-book-open"></i>','Bedekr')
   +it('help','<b class="more41-i">i</b>','Návod')
   +it('theme','<i class="fa-solid fa-'+(dark?'sun':'moon')+'"></i>',dark?'Světlý režim':'Tmavý režim')
   +it('r',MONO('R','r'),'Regio linky',r)
   +it('v',MONO('V','v'),'Vlaky',v)
   +it('live','<i class="fa-solid fa-tower-broadcast"></i>','Živé polohy',!!window.__live41?.on())
   +it('plus','<i class="fa-solid fa-cubes"></i>','3D PLUS')
   +(window.__ttPos41?it('tt',MONO('JŘ','jr'),'Polohy podle JŘ<sup class="b3d41">3D</sup>',window.__ttPos41.on):'')
   +'</div>';
  more.querySelectorAll('[data-m]').forEach(b=>b.onclick=()=>{const k=b.dataset.m;
   if(k==='dep'){closeAll('dep');window.openDeparturesPanel?.('Divadlo')}
   else if(k==='fav'){closeAll();window.__fav41?.manager()}
   else if(k==='live'){window.__live41?.set(!window.__live41.on())}
   else if(k==='garage'){closeAll('garage');try{setGarage(true)}catch(_){$('btn-garage')?.click()}}
   else if(k==='info'){closeAll('info');$('btn-bedekr')?.click()}
   else if(k==='help'){closeAll('help');window.__help41?.open()}
   else if(k==='theme'){$('btn-theme')?.click()}
   else if(k==='r'){$('btn-r')?.click()}
   else if(k==='v'){$('btn-v')?.click()}
   else if(k==='plus'){closeAll();$('btn-plus3d')?.click()}
   else if(k==='tt'){window.__ttPos41?.setTT(!window.__ttPos41.on)}
   if(k==='theme'||k==='r'||k==='v'||k==='tt'||k==='live')renderMore();else more.hidden=true;sync()});
 }
 tab.addEventListener('click',e=>{const b=e.target.closest('button[data-t]');if(!b)return;const k=b.dataset.t;
  if(k==='search'){if(isOpen('search-panel')){closeAll()}else{closeAll('search');$('btn-search')?.click();setTimeout(()=>sheet('search-panel','half'),30)}}
  else if(k==='net'){if(isOpen('network-panel')){$('btn-net')?.click()}else{closeAll('net');$('btn-net')?.click();setTimeout(()=>sheet('network-panel','half'),30)}}
  else if(k==='dep'){if(window.__dep42?window.__dep42.isOpen():isOpen('departures-panel'))window.closeDeparturesPanel?.();else{closeAll('dep');window.openDeparturesPanel?.('Divadlo')}}
  else if(k==='ride'){if(B.classList.contains('ride-mode'))window.endRide?.();else{closeAll();window.__pick41?.open()}}
  else if(k==='more'){const o=more.hidden;closeAll('more');if(o){renderMore();more.hidden=false}else more.hidden=true}
  sync()});
 document.addEventListener('pointerdown',e=>{if(!more.hidden&&!more.contains(e.target)&&!tab.contains(e.target))more.hidden=true},true);
 function sync(){
  const act={search:isOpen('search-panel'),net:isOpen('network-panel'),dep:isOpen('departures-panel')||!!window.__dep42?.isOpen(),ride:B.classList.contains('ride-mode')||!!(document.getElementById('pick41')&&!document.getElementById('pick41').hidden),more:!more.hidden||isOpen('garage-panel')||isOpen('bedekr-panel')};
  tab.querySelectorAll('button').forEach(b=>b.classList.toggle('on',!!act[b.dataset.t]));
  const rb=tab.querySelector('[data-t="ride"]');if(rb){const on=B.classList.contains('ride-mode');rb.querySelector('i').className='fa-solid '+(on?'fa-xmark':'fa-route');rb.querySelector('span').textContent=on?'Konec jízdy':'Jízda'}
  updateSh();
 }
 /* ---- listy (bottom sheets) ---- */
 const tabH=()=>(MQ.matches||!!window.__forceM41)?(tab.getBoundingClientRect().height||62)+12:0;
 function heights(id){const vh=window.innerHeight,top=(document.querySelector('header')?.getBoundingClientRect().bottom||60)+6;
  const full=Math.max(240,vh-top-tabH()-6);return{peek:Math.min(full,id==='search-panel'?150:118),half:Math.min(full,Math.round(vh*.47)),full}}
 function sheet(id,state){const el=$(id);if(!el||!(MQ.matches||!!window.__forceM41))return;state=state||el.dataset.sheet||'half';el.dataset.sheet=state;el.style.setProperty('--h',heights(id)[state]+'px');
  const c=el.querySelector('.sh41-chev i');if(c)c.className='fa-solid fa-chevron-'+(state==='full'?'down':'up');
  const cb=el.querySelector('.sh41-chev');if(cb)cb.setAttribute('aria-label',state==='full'?'Zmenšit panel':'Zvětšit panel');
  setTimeout(updateSh,280)}
 function updateSh(){let h=0;if((MQ.matches||!!window.__forceM41))for(const id of SHEETS){const el=$(id);if(el?.classList.contains('open')){h=Math.max(h,el.getBoundingClientRect().height)}}B.style.setProperty('--sh41',Math.round(h)+'px')}
 function addHandle(id){const el=$(id);if(!el||el.querySelector('.sh41'))return;
  const hd=document.createElement('div');hd.className='sh41';hd.innerHTML='<span class="sh41-grab"></span><button type="button" class="sh41-chev" aria-label="Zvětšit panel"><i class="fa-solid fa-chevron-up"></i></button>';el.prepend(hd);
  hd.querySelector('.sh41-chev').onclick=e=>{e.stopPropagation();const s=el.dataset.sheet||'half';sheet(id,s==='full'?'peek':s==='half'?'full':'half')};
  let y0=0,h0=0,drag=false,moved=false;
  hd.addEventListener('pointerdown',e=>{if(e.target.closest('.sh41-chev'))return;drag=true;moved=false;y0=e.clientY;h0=el.getBoundingClientRect().height;el.classList.add('sh41-drag');hd.setPointerCapture?.(e.pointerId)});
  hd.addEventListener('pointermove',e=>{if(!drag)return;const dy=e.clientY-y0;if(Math.abs(dy)>4)moved=true;const H=heights(id);el.style.setProperty('--h',Math.max(80,Math.min(H.full,h0-dy))+'px');updateSh()});
  const end=e=>{if(!drag)return;drag=false;el.classList.remove('sh41-drag');const H=heights(id),cur=el.getBoundingClientRect().height;
   if(!moved){const s=el.dataset.sheet||'half';sheet(id,s==='peek'?'half':s==='half'?'full':'half');return}
   const st=Object.entries(H).sort((a,b)=>Math.abs(a[1]-cur)-Math.abs(b[1]-cur))[0][0];sheet(id,st)};
  hd.addEventListener('pointerup',end);hd.addEventListener('pointercancel',end);
 }
 SHEETS.forEach(addHandle);
 /* panel se při psaní roztáhne, po nalezení výsledků zmenší na polovinu (mapa s trasou zůstane vidět) */
 $('search-panel')?.addEventListener('focusin',e=>{if(e.target.matches('input')&&(MQ.matches||!!window.__forceM41))sheet('search-panel','full')});
 /* souhrn hledání spojení (Odkud → Kam) s tlačítkem Upravit; mapa se po zmenšení listu znovu přizpůsobí trase */
 const cv=$('search-connection-view'),sp=$('search-panel');
 const ced=document.createElement('div');ced.className='cedit41';cv?.querySelector('#connection-results')?.before(ced);
 function refit(){setTimeout(()=>{try{if(is3dOn())return;const b=L.latLngBounds([]);searchRouteLayer.eachLayer(l=>{try{if(l.getBounds)b.extend(l.getBounds());else if(l.getLatLng)b.extend(l.getLatLng())}catch(_){}});if(b.isValid())map.fitBounds(b,{...fitPad(),animate:true})}catch(_){}},320)}
 for(const id of ['connection-results','nearest-results']){const box=$(id);if(box)new MutationObserver(()=>{if(!(MQ.matches||!!window.__forceM41)||!isOpen('search-panel'))return;
  const res=id==='connection-results'&&!!box.querySelector('.vars41');if(id==='connection-results'){sp.classList.toggle('res41',res);
   if(res)ced.innerHTML='<div class="cedit41-r"><span><i class="fa-regular fa-circle"></i>'+h($('from-address')?.value||'')+'</span><span><i class="fa-solid fa-location-dot"></i>'+h($('to-address')?.value||'')+'</span></div><button type="button" class="cedit41-e"><i class="fa-solid fa-pen"></i> Upravit</button>';
   ced.querySelector('.cedit41-e')&&(ced.querySelector('.cedit41-e').onclick=()=>{sp.classList.remove('res41');sheet('search-panel','full');setTimeout(()=>$('from-address')?.focus(),50)})}
  if(box.children.length){document.activeElement?.blur?.();sheet('search-panel','half');refit()}}).observe(box,{childList:true})}
 /* úprava vstupu znovu zobrazí formulář */
 ['from-address','to-address'].forEach(id=>$(id)?.addEventListener('focus',()=>sp?.classList.remove('res41')));
 /* stav lišty a listů podle otevřených panelů */
 const mo=new MutationObserver(()=>{for(const id of SHEETS){const el=$(id);if(el?.classList.contains('open')&&!el.dataset.sheet)sheet(id,'half');if(el&&!el.classList.contains('open'))delete el.dataset.sheet}sync()});
 for(const id of [...SHEETS,'departures-panel','garage-panel','bedekr-panel']){const el=$(id);if(el)mo.observe(el,{attributes:true,attributeFilter:['class']})}
 mo.observe(B,{attributes:true,attributeFilter:['class']});
 const pk=document.getElementById('pick41');if(pk)mo.observe(pk,{attributes:true,attributeFilter:['hidden']});
 function apply(){B.classList.toggle('m41',(MQ.matches||!!window.__forceM41));for(const id of SHEETS)if(isOpen(id))sheet(id);sync();setTimeout(()=>{try{map.invalidateSize()}catch(_){}try{map3d?.resize()}catch(_){}},60)}
 MQ.addEventListener?.('change',apply);window.__m41apply=apply;window.addEventListener('resize',()=>{if((MQ.matches||!!window.__forceM41))for(const id of SHEETS)if(isOpen(id))sheet(id);updateSh()});
 apply();
 window.__m41ui={sheet,sync,closeAll};
})();

/* krátká hláška nahoře na mapě */
function toast41(html,ms=4600){let t=$('toast41');if(!t){t=document.createElement('div');t.id='toast41';t.setAttribute('role','status');document.body.appendChild(t)}t.innerHTML=html;t.classList.add('show');clearTimeout(t._h);t._h=setTimeout(()=>t.classList.remove('show'),ms)}
/* monogram písmen (R, V, JŘ) s barevným proužkem */
const MONO_R='<svg class="mono41-svg" viewBox="0 0 24 24" aria-hidden="true"><g fill="none" stroke="currentColor" stroke-width="2.1" stroke-linejoin="miter" stroke-linecap="butt"><path d="M2.8 17.6 L7.6 4.8 H15.2 A4.1 4.1 0 0 1 16.3 12.9 L19.4 20.4 H15.6"/><path d="M4.4 17.6 H6.5 L9.9 8.6 H15.1 A1 1 0 0 1 15.1 10.6"/><path d="M6.6 20.4 H10.3 L12.7 13.9 L15.6 20.4"/></g></svg>';
const MONO_V='<svg class="mono41-svg" viewBox="0 0 24 17.4" aria-hidden="true"><g fill="currentColor"><path d="M0.4 0.7 H3.3 L12.5 16.7 H9.6 Z"/><path d="M4.7 0.7 H12.4 L15.5 5.5 L14.3 7.6 L11.6 3.1 H8.9 L14.1 12 L20.6 0.7 H23.4 L14.1 16.7 Z"/><path d="M15.3 0.7 H18.5 L16.9 3.5 Z"/></g></svg>';
const MONO=(txt,cls)=>txt==='R'?'<span class="mono41 r">'+MONO_R+'</span>':txt==='V'?'<span class="mono41 v">'+MONO_V+'</span>':'<span class="mono41 '+cls+'"><b>'+(txt==='JŘ'?'J<em>Ř</em>':txt)+'</b><i></i></span>';
/* ---------- Polohy vozidel podle jízdních řádů (3D) ---------- */
(function(){
 if(!TT)return;
 let ttOn=false;
 const cache=new Map(),assigned=new Map();
 const cumOf=pts=>{const c=[0];for(let i=1;i<pts.length;i++)c.push(c[i-1]+dist(pts[i-1],pts[i]));return c};
 /* průmět bodu na trasu, jen dopředu od vzdálenosti fromS */
 function proj(pts,cum,p,fromS){let best=null;const kx=Math.cos(p[0]*Math.PI/180)*111320,ky=110540;
  for(let i=0;i<pts.length-1;i++){if(cum[i+1]<fromS-15)continue;if(best&&best.d<30&&cum[i]>best.s+1500)break;
   const a=pts[i],b=pts[i+1],ax=(a[1]-p[1])*kx,ay=(a[0]-p[0])*ky,vx=(b[1]-a[1])*kx,vy=(b[0]-a[0])*ky,L2=vx*vx+vy*vy||1,t=Math.max(0,Math.min(1,-(ax*vx+ay*vy)/L2)),d=Math.hypot(ax+vx*t,ay+vy*t),s=cum[i]+(cum[i+1]-cum[i])*t;
   if(s<fromS-15)continue;if(!best||d<best.d)best={d,s}}return best}
 /* trasa spoje: ze tras linky ta, po které spoj projede svými zastávkami ve správném pořadí */
 function mapTrip(T){const k=T.line+'|'+T.pi;if(cache.has(k))return cache.get(k);
  let routes=((typeof gpxRoutes!=='undefined'&&gpxRoutes[T.line])||[]).map(r=>r.points).filter(p=>p&&p.length>1);
  const xp=XP[T.line];if(xp)routes=routes.concat([xp.f,xp.b,...(xp.v||[])].filter(p=>p&&p.length>1));
  let best=null;
  for(const pts of routes){const cum=pts._cum41||(pts._cum41=cumOf(pts));let s=0,err=0,ok=0;const sd=[];
   for(const key of T.keys){const st=D.stops.get(key);let bp=null;if(st)for(const p of st.plats){const pr=proj(pts,cum,[p.lat,p.lng],s);if(pr&&(!bp||pr.d<bp.d))bp=pr}
    if(bp&&bp.d<160){sd.push(bp.s);s=bp.s;err+=bp.d;ok++}else{sd.push(null);err+=200}}
   const sc=err/T.keys.length;if(ok>=2&&(!best||sc<best.sc))best={sc,pts,sd}}
  if(best){const sd=best.sd;let last=null;for(let i=0;i<sd.length;i++){if(sd[i]==null){let j=i+1;while(j<sd.length&&sd[j]==null)j++;const a=last??0,b=j<sd.length?sd[j]:a;sd[i]=a+(b-a)*(1/(j-i+1))}last=sd[i]}}
  cache.set(k,best);return best}
 function setPath(v,pts){if(v.points===pts)return;v.points=pts;v.coords=pts.map(p=>[p[1],p[0]]);v.ls=turf.lineString(v.coords);v.length=turf.length(v.ls,{units:'meters'});v._plans41=null;v._segReady=false;v.smoothBearing=null;v.smoothTilt=null}
 function target(v,m){const w=TT.where(v._ttT,m),sd=v._ttMap.sd,a=sd[w.i],b=sd[Math.min(w.i+1,sd.length-1)];return w.dwell?a:a+(b-a)*w.f}
 function hide(v,h){v.hidden41=h;v.skip41=h}
 let last=0,info={n:0};
 function tick(){
  if(!has3d()||typeof turf==='undefined')return;const all=vehicles();if(!all.length)return;
  const now=new Date(),on=ttOn&&TT.valid(now);
  if(!on){for(const v of all){if(v.tt41){if(v!==rideBus)hide(v,true);v._ttKey=null}else if(v.ttOff41){v.ttOff41=false;v.skip41=false;if(!v.extra41)v.hidden41=false}}assigned.clear();info={n:0,off:true};return}
  /* simulovaná vozidla schovat, jezdí jen spoje podle jízdního řádu */
  for(const v of all)if(!v.tt41&&!v.pick41&&v!==rideBus&&!v.ttOff41){v.ttOff41=true;hide(v,true)}else if(v.ttOff41&&v!==rideBus)hide(v,true);
  const act=TT.active(now),seen=new Set(),free=new Map();
  for(const v of all)if(v.tt41&&!v._ttKey&&v!==rideBus){if(!free.has(v.line))free.set(v.line,[]);free.get(v.line).push(v)}
  let n=0;
  for(const {T,m,key} of act){seen.add(key);let v=assigned.get(key);
   if(!v){const f=free.get(T.line);if(!f||!f.length)continue;const mp=mapTrip(T);if(!mp)continue;v=f.pop();setPath(v,mp.pts);v._ttKey=key;v._ttT=T;v._ttMap=mp;assigned.set(key,v);v.distance=target(v,m);v._poseLastT=null}
   if(v===rideBus){hide(v,false);continue}
   const l=D.line(T.line),h=(l.train&&!trainOn)||(!l.city&&!l.train&&!regioOn);hide(v,h);if(!h)n++;
   /* rychlost přesně podle jízdního řádu; větší odchylku (např. po uspání karty) srovnat skokem */
   const t0=target(v,m),t1=target(v,m+1/60);if(!(Math.abs(v.distance-t0)<40))v.distance=t0;
   v.speed=Math.max(0,t1-t0)+(t0-v.distance)*0.3;v.effSpeed=null}
  for(const v of all)if(v.tt41&&!v._ttKey&&v!==rideBus)hide(v,true);
  for(const [key,v] of assigned)if(!seen.has(key)){assigned.delete(key);v._ttKey=null;v._ttT=null;if(v!==rideBus){hide(v,true);v.speed=0}}
  info={n,trips:act.length};
 }
 setInterval(tick,1000);
 const aS=applySpeeds;applySpeeds=function(){const r=aS.apply(this,arguments);try{tick()}catch(e){console.warn('[JŘ]',e)}return r};
 /* přepínač JŘ ve 3D panelu a v nabídce Více */
 const anchor=$('ride-start')||$('fx-weather-none')?.parentElement;
 if(anchor&&!$('fx-tt41')){const w=document.createElement('div');w.id='fx-tt41-wrap';const b=document.createElement('button');b.id='fx-tt41';b.type='button';b.title='Polohy vozidel podle jízdního řádu';b.setAttribute('aria-label',b.title);b.setAttribute('aria-pressed','false');
  b.innerHTML=MONO('JŘ','jr')+'<span class="tt41-txt">Jízdní řád</span>';w.appendChild(b);anchor.after(w);b.onclick=()=>setTT(!ttOn)}
 function setTT(v){ttOn=v;const b=$('fx-tt41');b?.classList.toggle('fx-active',v);b?.setAttribute('aria-pressed',String(v));try{applySpeeds()}catch(_){tick()}
  toast41(v?'<i class="fa-regular fa-clock"></i><span><b>Polohy podle jízdního řádu</b>Vozidla jezdí tam, kde mají být podle jízdního řádu – bez aktuálních zpoždění.</span>':'<i class="fa-solid fa-bus"></i><span><b>Simulace provozu</b>Vozidla jezdí plynule po svých trasách.</span>')}
 $('fx-tt41')?.classList.toggle('fx-active',ttOn);
 window.__ttPos41={tick,setTT,get on(){return ttOn},get info(){return info},assigned,mapTrip};
})();

/* ---------- v10: mobil – zkratky vzhledu 2D mapy, kamera při jízdě nad panelem ---------- */
(function(){
 const ids={'layer-basic':()=>'Z','layer-light':()=>document.body.classList.contains('dark')?'T':'S','layer-satellite':()=>'L'};
 const names={'layer-basic':()=>'Základní','layer-light':()=>document.body.classList.contains('dark')?'Tmavá':'Světlá','layer-satellite':()=>'Letecká'};
 const upd=()=>{for(const [id,f] of Object.entries(ids)){const b=$(id);if(b){b.dataset.short=f();b.title=names[id]();b.setAttribute('aria-label',names[id]())}}};
 upd();new MutationObserver(upd).observe(document.body,{attributes:true,attributeFilter:['class']});
 /* při jízdě na telefonu posunout střed kamery nad panel zastávek, ať je vozidlo vidět */
 const MQ=matchMedia('(max-width:700px) and (orientation:portrait), (max-height:500px) and (orientation:landscape) and (max-width:1100px)');
 function pad(){try{if(!has3d())return;const on=document.body.classList.contains('ride-mode')&&(MQ.matches||!!window.__forceM41);const h=on?Math.round(($('ride-panel')?.getBoundingClientRect().height||0)*0.92):0;
  if(map3d.__pad41!==h){map3d.__pad41=h;map3d.setPadding?.({top:on?20:0,bottom:h,left:0,right:0})}}catch(_){}}
 new MutationObserver(()=>setTimeout(pad,380)).observe(document.body,{attributes:true,attributeFilter:['class']});window.addEventListener('resize',()=>setTimeout(pad,200));
})();

/* ---------- v11: monogramy R/V, bez tlačítka Odjezdy, odjezdy v IDOS, logo na mobilu ---------- */
(function(){
 const rb=$('btn-r'),vb=$('btn-v');
 if(rb){rb.innerHTML=MONO('R','r');rb.classList.add('mono41-btn')}
 if(vb){vb.innerHTML=MONO('V','v');vb.classList.add('mono41-btn')}
 /* Odjezdy: hlavní tlačítko pryč, odjezdy konkrétní zastávky v IDOS */
 {const ob=$('btn-departures');if(ob){const nb=ob.cloneNode(true);nb.title='Odjezdy ze zastávek';nb.setAttribute('aria-label','Odjezdy ze zastávek');nb.className=($('btn-search')?.className||'w-9 h-9 rounded-full bg-white/80 flex items-center justify-center text-gray-600 border border-gray-100')+' dep41-btn';nb.innerHTML='<svg viewBox=\"0 0 24 24\" width=\"20\" height=\"20\" aria-hidden=\"true\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M17.1 12.8A7.4 7.4 0 1 0 9.9 17.6\"/><path d=\"M10 5.9v4.5l3.1 2\"/><path d=\"M12.6 18.9h8.4M18 15.9l3 3-3 3\"/></svg>';ob.remove();const bs=$('btn-search');if(bs)bs.after(nb);else document.querySelector('header')?.appendChild(nb);nb.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();if(window.__dep42?.isOpen())window.__dep42.close();else window.openDeparturesPanel?.('Divadlo')})}}
 const TTR=window.MHD41_TT,NM=new Map();if(TTR?.names)TTR.stops.forEach((k,i)=>{if(TTR.names[i])NM.set(k,TTR.names[i])});
 function idosStop(name){const st=D.stop(name),k=st?.key||D.key(name);let n=NM.get(k);if(!n){n=st?.name||name;if(st?.city&&!/^Opava/.test(n))n='Opava, '+n}return n}
 window.openDeparturesPanel=function(name){const url=name?'https://idos.cz/vlakyautobusymhdvse/odjezdy/?f='+encodeURIComponent(idosStop(name))+'&submit=true':'https://idos.cz/vlakyautobusymhdvse/odjezdy/';window.open(url,'_blank','noopener')};
 window.__idosStop41=idosStop;
})();

/* ---------- 204: troleje dolů/nahoru – model i text podle stejných pravidel ----------
   Bez trolejového vedení se jede Divadlo ↔ Ratibořská a Kylešovice, Bílovecká ↔ Kylešovice, škola. */
(function(){
 const RULES={E:{divadlo:true,kylesovicebilovecka:true,ratiborska:false},K:{kylesovicebilovecka:false,ratiborska:true,divadlo:false}};
 const dirOf=st=>/englisova|dostojevskeho/.test(D.key(st[0].name))?'E':'K';
 /* stav po projetí zastávek do vzdálenosti d */
 function polesDown(st,d){const R=RULES[dirOf(st)];let down=dirOf(st)==='K';for(const s of st){if(s.dist>d+2)break;const a=R[D.key(s.name)];if(a!=null)down=a}return down}
 window.__poles41=v=>{if(String(v.line)!=='204')return null;const st=v===rideBus&&v._stopsWithDist?.length?v._stopsWithDist:planFor(v)?.stops;if(!st?.length)return null;return polesDown(st,Number(v.distance)||0)};
 /* akce u zastávky pro text v panelu jízdy */
 window.__poleAction41=(st,i)=>{const R=RULES[dirOf(st)],a=R[D.key(st[i].name)];if(a==null)return null;const before=i?polesDown(st,st[i-1].dist):dirOf(st)==='K';return a===before?null:(a?'down':'up')};
})();

/* Jízda vozidlem + a JŘ stejně široké jako skupiny tlačítek počasí */
(function(){
 function sync(){const g=$('fx-weather-none')?.parentElement,rs=$('ride-start'),tt=$('fx-tt41');if(!g||!g.offsetWidth)return;const w=Math.round(g.getBoundingClientRect().width);
  if(rs){rs.style.width=w+'px';rs.style.boxSizing='border-box'}if(tt&&!document.body.classList.contains('m41')){tt.style.width=w+'px';tt.style.justifyContent='center'}else if(tt){tt.style.width=''}}
 ['btn-model-3d','btn-map-2d'].forEach(id=>$(id)?.addEventListener('click',()=>[300,1200].forEach(t=>setTimeout(sync,t))));window.addEventListener('resize',()=>setTimeout(sync,100));setTimeout(sync,1500);setInterval(sync,4000);
})();
/* Garáž – zajímavosti o modelech vozidel */
(function(){
 const FACTS={
  '26tr':['Za trolejbusem stojí dvě továrny: karoserii vyrábí Solaris v polském Bolechowě, elektrickou výzbroj a konečnou montáž dělá Škoda v Plzni.','Od roku 2009 jich vzniklo přes 300 – jezdí například v Plzni, Ostravě nebo v bulharské Varně.','Jeden nový vůz dnes stojí kolem 16 milionů korun bez DPH (Plzeň platí 16,1 mil., Ostrava v roce 2025 přes 16,7 mil.).','V Opavě jich jezdí 13, první přijely v roce 2010.'],
  '32tr':['Světovou premiéru měl právě v Opavě na konci roku 2018 – Opava byla jeho prvním provozovatelem.','Opava za prvních deset kusů zaplatila 135,6 milionu korun bez DPH, tedy asi 13,6 milionu za vůz.','Karoserie pochází od SOR z Libchav, elektrická výzbroj od Škody. Dnes jich jezdí přes 150 v Česku i v zahraničí.','Lithium-titanátové baterie mu dovolí ujet kolem 12 km bez trolejí – proto může linka 204 jezdit i tam, kde trolejové vedení není.'],
  '36tr':['Nejlevnější nové trolejbusy v Česku: Opava je koupila za rekordních 8,49 milionu korun za vůz, tři kusy za 25,5 milionu.','Karoserii vyrábí turecká TEMSA (patří do stejné skupiny jako Škoda), elektrickou výzbroj montuje Škoda v Plzni. Vůz vychází z elektrobusu Temsa Avenue Electron.','Opavské vozy nemají pomocné baterie – jezdí jen pod trolejí, proto je uvidíte na linkách 201–203.','Do Opavy dorazily 9. srpna 2023 (evidenční čísla 329–331), cestující vozí od září 2023.'],
  'irisbus':['Citelis nahradil starší typ Agora. Vyráběl se ve Francii (Annonay), v Itálii a od roku 2010 i ve Vysokém Mýtě, v bývalé Karose.','Jen ve Vysokém Mýtě jich do konce výroby v roce 2014 vzniklo 593.','V Opavě jezdí od roku 2011. Jeho nástupcem je Iveco Urbanway, který v Opavě jezdí také.'],
  'iveco12m':['Urbanway se vyrábí mimo jiné ve Vysokém Mýtě – tamní závod v roce 2024 vyrobil 4 644 autobusů všech typů.','Dvanáctimetrový Urbanway na CNG stojí kolem 7,4 milionu korun bez DPH (Karlovy Vary koupily šest kusů za 44,1 milionu).','Jezdí na stlačený zemní plyn, který proti naftě vypouští výrazně méně pevných částic.'],
  'iveco10m':['Zkrácená verze Urbanwayu, dlouhá 10,5 metru – obratnější v úzkých ulicích a vhodná pro méně vytížené linky.','Vzniká ve stejném závodě jako dvanáctimetrová verze a také jezdí na CNG.','Ve Francii výroba 10,5m verze v roce 2024 skončila, takže jde o stále vzácnější typ.'],
  'sorbus':['Vyrábí ho rodinná firma SOR Libchavy u Ústí nad Orlicí. Verze NSG 12 na stlačený zemní plyn se vyrábí od roku 2020.','Městský dopravní podnik Opava provozuje pět CNG autobusů SOR od roku 2021.','Naftová verze NS 12 stojí kolem 5,3–6 milionů korun bez DPH (Hradec Králové a Plzeň, 2023).'],
  'sorelektro':['Osm elektrobusů SOR NS 12 electric stálo i s nabíjením 106,6 milionu korun bez DPH, tedy asi 12,3 milionu za vůz.','První dva vyjely v únoru 2026, všech osm je v provozu od září 2026.','Nabíjejí se v Kylešovicích na osmi nabíjecích bodech o celkovém výkonu 540 kW.','Do března 2028 má přibýt dalších 11 elektrobusů SOR ENS 12 se Škodou za 161 milionů korun (asi 14,7 milionu za vůz), nabíjených pantografem.']
 };
 window.__garageFacts41=id=>{
  const host=document.getElementById('garage-detail');if(!host)return;
  let box=host.querySelector('.garage-detail-facts');
  if(!box){box=document.createElement('div');box.className='garage-detail-facts';host.appendChild(box)}
  const f=FACTS[id];box.hidden=!f;if(!f)return;
  box.innerHTML='<div class="garage-stat-label"><i class="fa-solid fa-lightbulb"></i> Zajímavosti</div><ul>'+f.map(t=>'<li>'+t+'</li>').join('')+'</ul>';
  box.scrollTop=0;
 };
})();
/* Mapové náležitosti: směrovka severu (2D i 3D) a legenda */
(function(){
 const info=$('complete-map-info');if(!info)return;
 const box=document.createElement('div');box.className='mapx41';
 box.innerHTML='<button type="button" id="compass41" title="Sever – kliknutím natočíte mapu na sever" aria-label="Směrovka severu"><svg viewBox="0 0 24 24" aria-hidden="true"><path class="n" d="M12 2.5 L15.6 12 H8.4 Z"/><path class="s" d="M12 21.5 L8.4 12 H15.6 Z"/></svg><b>S</b></button>'
  +'<button type="button" id="legend41-btn" title="Legenda mapy" aria-label="Legenda mapy" aria-expanded="false"><i class="fa-solid fa-list-ul"></i></button>';
 info.appendChild(box);
 const leg=document.createElement('div');leg.id='legend41';leg.hidden=true;
 leg.innerHTML='<div class="legend41-head">Legenda<button type="button" aria-label="Zavřít legendu"><i class="fa-solid fa-xmark"></i></button></div>'
  +'<div class="legend41-row"><i class="ln mhd"></i>Linky MHD (trolejbusy a autobusy)</div>'
  +'<div class="legend41-row"><i class="ln regio"></i>Regionální autobusy</div>'
  +'<div class="legend41-row"><i class="ln train"></i>Železnice (vlaky)</div>'
  +'<div class="legend41-row"><i class="ln nad"></i>Náhradní doprava za vlak (NAD)</div>'
  +'<div class="legend41-row"><i class="ln walk"></i>Pěší úsek vyhledaného spojení</div>'
  +'<div class="legend41-row"><i class="pt stop"></i>Zastávka / nástupiště</div>'
  +'<div class="legend41-row"><i class="pt veh"></i>Vozidlo (poloha a směr jízdy)</div>'
  +'<div class="legend41-note">Regionální linky zapneš tlačítkem R, vlaky a NAD tlačítkem V. Měřítko a čas vlevo dole, sever ukazuje směrovka. Podklad © OpenStreetMap, Mapbox.</div>';
 document.querySelector('.map-shell')?.appendChild(leg)||document.body.appendChild(leg);
 const lb=$('legend41-btn'),cp=$('compass41'),arrow=cp.querySelector('svg');
 const setLeg=o=>{leg.hidden=!o;lb.setAttribute('aria-expanded',o?'true':'false');lb.classList.toggle('on',o)};
 lb.onclick=e=>{e.stopPropagation();setLeg(leg.hidden)};
 leg.querySelector('button').onclick=()=>setLeg(false);
 cp.onclick=e=>{e.stopPropagation();if(is3dOn()&&typeof map3d!=='undefined'&&map3d){try{map3d.easeTo({bearing:0,duration:600})}catch(_){}}};
 let last=null;
 function upd(){let b=0;if(is3dOn()&&typeof map3d!=='undefined'&&map3d){try{b=map3d.getBearing()||0}catch(_){}}
  if(b===last)return;last=b;arrow.style.transform='rotate('+(-b)+'deg)';cp.classList.toggle('rot',Math.abs(b)>0.5)}
 setInterval(upd,200);upd();
 window.__mapx41={upd,setLeg};
})();
/* ---------- Odjezdy ze zastávky podle jízdních řádů (vlastní tabule v aplikaci) ---------- */
(function(){
 const TT=window.__tt41;if(!TT)return;
 const R=TT.R,NM=new Map();if(R.names)R.stops.forEach((k,i)=>{if(R.names[i])NM.set(k,R.names[i])});
 let IDX=null;
 function index(){if(IDX)return IDX;IDX=new Map();
  for(const T of TT.trips)for(let p=0;p<T.keys.length-1;p++){const k=T.keys[p];let a=IDX.get(k);if(!a)IDX.set(k,a=[]);a.push([T,p])}
  return IDX}
 const nameOf=k=>{const s=D.stops.get(k);if(s)return s.name;const n=NM.get(k)||k;return n.replace(/^Opava,\s*/,'')};
 const hhmm=m=>{m=((Math.round(m)%1440)+1440)%1440;return String(Math.floor(m/60)).padStart(2,'0')+':'+String(m%60).padStart(2,'0')};
 const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
 function departures(k,date,max){
  const list=index().get(k)||[],di=TT.dayIdx(date),m=TT.mins(date),out=[],LD=window.__live41?.on()&&window.__live41.state()==='ok'&&Math.abs(date-Date.now())<120000?window.__live41.delays():null;
  for(const [T,p] of list)for(const off of [-1440,0,1440]){
   const d=di+off/1440;if(!TT.on(T.si,d))continue;const t=T.dep[p]+off;
   const ld=LD&&LD.get(T.id+'@'+off),tx=ld?t+ld.dm:t;
   if(tx>=m-0.5&&t<=m+1440)out.push({t,T,p,last:T.keys.at(-1),dm:ld?ld.dm:null})}
  out.sort((a,b)=>a.t-b.t);
  const seen=new Set(),res=[];for(const x of out){const id=x.T.line+'|'+Math.round(x.t)+'|'+x.last;if(seen.has(id))continue;seen.add(id);res.push(x);if(res.length>=max)break}
  return res}
 let el=null,cur=null,filter=null,when=null,timer=null,expanded=null,list0=null;
 function build(){
  el=document.createElement('aside');el.id='dep42';el.setAttribute('aria-hidden','true');
  el.innerHTML='<div class="dep42-head"><div class="dep42-ic"><i class="fa-solid fa-clock"></i></div><div class="dep42-tt"><div class="dep42-eb">Odjezdy podle jízdního řádu</div><div class="dep42-name"></div></div><button type="button" class="dep42-x" aria-label="Zavřít odjezdy"><i class="fa-solid fa-xmark"></i></button></div>'
   +'<div class="dep42-pick"><i class="fa-solid fa-magnifying-glass"></i><input type="search" class="dep42-stop" placeholder="Vyberte zastávku…" autocomplete="off" aria-label="Zastávka"><div class="dep42-sug" role="listbox" hidden></div></div>'
   +'<div class="dep42-bar"><button type="button" class="dep42-now on">Nyní</button><input type="time" class="dep42-time" aria-label="Čas odjezdu"><input type="date" class="dep42-date" aria-label="Den"></div>'
   +'<div class="dep42-lines"></div><div class="dep42-list" role="list"></div>'
   +'<div class="dep42-foot"><span>Bez aktuálních zpoždění.</span><a class="dep42-idos" target="_blank" rel="noopener">Ověřit v IDOS <i class="fa-solid fa-arrow-up-right-from-square"></i></a></div>';
  document.body.appendChild(el);
  el.querySelector('.dep42-x').onclick=close;
  const nowB=el.querySelector('.dep42-now'),ti=el.querySelector('.dep42-time'),da=el.querySelector('.dep42-date');
  nowB.onclick=()=>{when=null;render()};
  const setWhen=()=>{const [h,mi]=(ti.value||'00:00').split(':').map(Number),[y,mo,dd]=(da.value||'').split('-').map(Number);const d=y?new Date(y,mo-1,dd,h||0,mi||0):new Date();if(!y)d.setHours(h||0,mi||0,0,0);when=d;render()};
  ti.onchange=setWhen;da.onchange=setWhen;
  const si=el.querySelector('.dep42-stop'),sg=el.querySelector('.dep42-sug');
  const CAND=[...D.stops.values()].filter(s=>index().has(s.key)).map(s=>({s,f:D.fold(s.name)}));
  const pick=s=>{cur={key:s.key,name:s.name};filter=null;expanded=null;si.value='';sg.hidden=true;si.blur();render()};
  si.oninput=()=>{const q=D.fold(si.value.trim());if(!q){sg.hidden=true;return}
   const hits=CAND.filter(x=>x.f.includes(q)).sort((a,b)=>(a.f.startsWith(q)?0:1)-(b.f.startsWith(q)?0:1)||(b.s.city-a.s.city)||a.f.length-b.f.length).slice(0,8);
   sg.innerHTML=hits.length?hits.map((x,i)=>'<button type="button" data-i="'+i+'">'+esc(x.s.name)+'<small>'+esc((x.s.lineList||[...x.s.lines]).slice(0,8).join(' · '))+'</small></button>').join(''):'<div class="dep42-none">Zastávku neznáme</div>';
   sg.hidden=false;sg.querySelectorAll('button').forEach(b=>b.onclick=()=>pick(hits[+b.dataset.i].s))};
  si.onkeydown=e=>{if(e.key==='Enter'){const b=sg.querySelector('button');if(b){e.preventDefault();b.click()}}else if(e.key==='Escape'){sg.hidden=true}};
  si.onblur=()=>setTimeout(()=>{sg.hidden=true},180);
  list0=el.querySelector('.dep42-list');
  list0.addEventListener('click',e=>{const row=e.target.closest('.dep42-row');if(!row||e.target.closest('.dep42-sub'))return;expanded=expanded===row.dataset.id?null:row.dataset.id;render(true)});
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&isOpen())close()});
 }
 const isOpen=()=>!!el&&el.classList.contains('open');
 function render(keep){
  if(!el||!cur)return;const sc=list0?list0.scrollTop:0,subSc=el.querySelector('.dep42-sub')?.scrollTop||0;
  const date=when||new Date(),k=cur.key;
  el.querySelector('.dep42-name').textContent=cur.name;
  el.querySelector('.dep42-now').classList.toggle('on',!when);
  const p2=n=>String(n).padStart(2,'0'),ti=el.querySelector('.dep42-time'),da=el.querySelector('.dep42-date');
  if(document.activeElement!==ti)ti.value=p2(date.getHours())+':'+p2(date.getMinutes());
  if(document.activeElement!==da)da.value=date.getFullYear()+'-'+p2(date.getMonth()+1)+'-'+p2(date.getDate());
  try{el.querySelector('.dep42-idos').href='https://idos.cz/vlakyautobusymhdvse/odjezdy/?f='+encodeURIComponent(window.__idosStop41?window.__idosStop41(cur.name):cur.name)+'&submit=true'}catch(_){}
  const list=el.querySelector('.dep42-list'),chips=el.querySelector('.dep42-lines');
  if(!TT.valid(date)){chips.innerHTML='';list.innerHTML='<div class="dep42-empty">Jízdní řády v aplikaci platí do '+TT.until.toLocaleDateString('cs-CZ')+'. Pro jiný den použijte IDOS.</div>';return}
  const all=departures(k,date,400);
  const lines=[...new Set(all.map(x=>x.T.line))];const sorted=D.sortLines?D.sortLines(lines):lines.sort();
  if(filter&&!lines.includes(filter))filter=null;
  chips.innerHTML=lines.length>1?'<button type="button" class="dep42-chip'+(filter?'':' on')+'" data-l="">Vše</button>'+sorted.map(l=>'<button type="button" class="dep42-chip'+(filter===l?' on':'')+'" data-l="'+esc(l)+'" style="--c:'+esc(D.color(l)||'#C1784F')+'">'+esc(l)+'</button>').join(''):'';
  chips.querySelectorAll('.dep42-chip').forEach(b=>b.onclick=()=>{filter=b.dataset.l||null;render()});
  const rows=all.filter(x=>!filter||x.T.line===filter).slice(0,40),m=TT.mins(date);
  if(!rows.length){list.innerHTML='<div class="dep42-empty">'+(index().has(k)?'V následujících 24 hodinách odtud nic nejede.':'Pro tuto zastávku nemáme jízdní řád.')+'</div>';return}
  let lastDay=null;
  list.innerHTML=rows.map(x=>{const day=x.t>=1440?'zítra':x.t<0?'':'dnes';let sep='';if(day!==lastDay&&day==='zítra')sep='<div class="dep42-sep">Zítra</div>';lastDay=day;
   const inM=Math.round(x.t+(x.dm>0?x.dm:0)-m),rel=!when&&inM<=0?'<b class="now">teď</b>':!when&&inM<60?'za '+inM+' min':'';
   const off=x.t-x.T.dep[x.p],id=x.T.id+'@'+Math.round(off),open=expanded===id;
   let sub='';if(open){const rows2=[];for(let j=x.p+1;j<x.T.keys.length;j++)rows2.push('<div class="dep42-st"><span class="dep42-sd"></span><span class="dep42-sn">'+esc(nameOf(x.T.keys[j]))+'</span><b>'+hhmm(x.T.arr[j]+off)+'</b></div>');sub='<div class="dep42-sub" role="list">'+rows2.join('')+'</div>'}
   return sep+'<div class="dep42-row'+(open?' open':'')+'" role="listitem" data-id="'+id+'" tabindex="0" aria-expanded="'+(open?'true':'false')+'"><div class="dep42-main"><span class="dep42-ln" style="--c:'+esc(D.color(x.T.line)||'#C1784F')+'">'+esc(x.T.line)+'</span><span class="dep42-dir"><i class="fa-solid fa-arrow-right"></i> '+esc(nameOf(x.last))+'</span><span class="dep42-t"><b>'+hhmm(x.t)+'</b><small>'+rel+'</small></span><i class="fa-solid fa-chevron-down dep42-chev"></i></div>'+sub+'</div>'}).join('');
  if(list0){list0.scrollTop=sc;const sb=list0.querySelector('.dep42-sub');if(sb&&!keep)sb.scrollTop=subSc;if(keep&&sb){const r=sb.parentElement;const top=r.offsetTop-list0.offsetTop,bot=top+r.offsetHeight;if(bot>list0.scrollTop+list0.clientHeight)list0.scrollTop=bot-list0.clientHeight+6}}
 }
 function open(name){
  if(!name&&cur){if(!el)build();el.classList.add('open');el.setAttribute('aria-hidden','false');render();clearInterval(timer);timer=setInterval(()=>{if(isOpen()&&!when)render()},20000);return}
  if(!name){/* bez zastávky: nejbližší zastávka středu mapy, jinak IDOS */
   try{const c=map.getCenter();let best=null;for(const s of D.stops.values()){if(!s.city||!index().has(s.key))continue;const d=dist([c.lat,c.lng],[s.lat,s.lng]);if(!best||d<best.d)best={s,d}}if(best)name=best.s.name}catch(_){}
   if(!name){window.open('https://idos.cz/vlakyautobusymhdvse/odjezdy/','_blank','noopener');return}}
  if(!el)build();
  const s=D.stop(name);cur={key:s?.key||D.key(name),name:s?.name||D.canon(name)};filter=null;when=null;expanded=null;
  el.classList.add('open');el.setAttribute('aria-hidden','false');render();
  clearInterval(timer);timer=setInterval(()=>{if(isOpen()&&!when)render()},20000);
 }
 function close(){if(!el)return;el.classList.remove('open');el.setAttribute('aria-hidden','true');clearInterval(timer)}
 window.openDeparturesPanel=n=>{try{open(n)}catch(e){console.warn('[odjezdy]',e);try{window.open('https://idos.cz/vlakyautobusymhdvse/odjezdy/?f='+encodeURIComponent(n||'')+'&submit=true','_blank','noopener')}catch(_){}}};
 window.closeDeparturesPanel=close;
 window.__dep42={departures,open,close,isOpen,index};
})();
/* ---------- Stabilita 3D: ztráta WebGL kontextu (mobil na pozadí, málo paměti) → mapa se sama obnoví ---------- */
(function(){
 let lostAt=0;
 function rebuild(){try{if(typeof map3d!=='undefined'&&map3d){try{map3d.remove()}catch(_){}}map3d=null;map3dReady=false;threeLayer=null;stopMeshes=[];stop3d=[];hookedMap=null;if(is3dOn())initMapbox3D()}catch(e){window.__report41?.('obnova 3D',e)}}
 setInterval(()=>{try{
  if(typeof map3d==='undefined'||!map3d||!map3d.getCanvas)return;const c=map3d.getCanvas();if(!c||c.__guard41)return;c.__guard41=true;
  c.addEventListener('webglcontextlost',e=>{e.preventDefault();lostAt=Date.now();window.__report41?.('3D','WebGL kontext ztracen')});
  c.addEventListener('webglcontextrestored',()=>{setTimeout(rebuild,300)});
 }catch(_){}},2000);
 /* když se kontext do 4 s sám neobnoví a 3D je vidět, postavíme mapu znovu */
 setInterval(()=>{if(lostAt&&Date.now()-lostAt>4000){lostAt=0;try{const gl=map3d?.getCanvas?.().getContext('webgl2')||map3d?.getCanvas?.().getContext('webgl');if(!gl||gl.isContextLost())rebuild()}catch(_){rebuild()}}},1000);
 /* návrat do aplikace z pozadí: přepočítat velikosti map */
 document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')setTimeout(()=>{try{map.invalidateSize()}catch(_){}try{map3d?.resize();map3d?.triggerRepaint()}catch(_){}},200)});
})();
/* ---------- Odbočky jen některých spojů: 217 přes Otice, 202 do Malých Hoštic ---------- */
(function(){try{
 /* 217: úsek přes Otice plnou čarou (dříve přerušovaně) */
 try{routeLayers['217']?.eachLayer(p=>{if(p.options?.dashArray)p.setStyle({dashArray:null})})}catch(_){}
 /* 202: Kateřinky → Malé Hoštice, restaurace → Malé Hoštice (geometrie ze stejné ulice jako 219) */
 const src=(gpxRoutes['219']||[]).find(d=>!d.noDrive&&dist(d.points.at(-1),[49.9375,17.9438])<150);
 const kat=D.stop('Kateřinky');
 if(src&&kat&&!(gpxRoutes['202']||[]).some(d=>d.file==='202-male-hostice')){
  const kp=kat.plats.reduce((a,p)=>{const i=src.points.reduce((b,q,j)=>{const dd=dist(q,[p.lat,p.lng]);return dd<b.d?{i:j,d:dd}:b},{i:0,d:1e9});return !a||i.d<a.d?i:a},null);
  if(kp&&kp.d<120){
   const pts=XP['202MH']?.f?.length>1?XP['202MH'].f:src.points.slice(kp.i);
   const add=(points,dir)=>{gpxRoutes['202'].push({file:'202-male-hostice',direction:dir,points,noDrive:true});(routePoints['202']=routePoints['202']||[]).push(points);
    const g=routeLayers['202'];if(g){const pl=L.polyline(points,{color:ROUTE_COLOR,weight:4,opacity:.92,interactive:false,lineCap:'round',lineJoin:'round'});pl.addTo(g);routeLinePolylines.push(pl)}};
   add(pts,'MH');
   /* opačný směr: Malé Hoštice → restaurace → Švédská kaple (bez Kateřinek), po trase 219 */
   const fw=(gpxRoutes['219']||[]).find(d=>!d.noDrive&&dist(d.points[0],[49.9375,17.9438])<150),sk=D.stop('Švédská kaple');
   let back=null;if(fw&&sk){let bi=-1,bd=1e9;fw.points.forEach((q,j)=>{for(const pl of sk.plats){const dd=dist(q,[pl.lat,pl.lng]);if(dd<bd){bd=dd;bi=j}}});if(bi>5&&bd<120)back=fw.points.slice(0,bi+1)}
   if(XP['202MH']?.b?.length>1)back=XP['202MH'].b;
   add(back||[...pts].reverse(),'MH_B');
   try{refreshRouteLineWidths()}catch(_){}
   try{const s=map3d?.getSource?.('routes-3d');if(s)s.setData(geojsonRoutes())}catch(_){}
  }
 }
 /* Síť: zastávky, kam jezdí jen některé spoje – odsazené, v závorce, s mezerou (jako v JŘ) */
 const OPT={'217':{f:[{after:'Psychiatrická léčebna',stops:['Otice, kaple','Otice, Slavkovská','Otice, statek']}],b:[{after:'Slavkov, Latarna',stops:['Otice, statek','Otice, Slavkovská','Otice, kaple']}]},
  '202':{f:[{before:'Kateřinky',stops:['Malé Hoštice','Malé Hoštice, restaurace']}],b:[{after:'Kateřinky',stops:['Malé Hoštice, restaurace','Malé Hoštice']}]},
  '219':{b:[{after:'Kateřinky',stops:['Kaufland'],replace:true}]}};
 window.__opt41=OPT;
 const prevFill=window.fillStops;
 if(typeof prevFill==='function'){
  window.fillStops=fillStops=function(item,line,rev){
   const r=prevFill.apply(this,arguments);
   try{const o=OPT[String(line)];if(o){const list=item.querySelector('.stop-list');if(list&&!list.querySelector('.opt41-row')){
    const rows=[...list.querySelectorAll('.stop-row')];
    for(const g of o[rev?'b':'f']||[]){
     if(g.replace)for(const n of g.stops){const ks=D.key(n);rows.filter(x=>D.key(x.children[1]?.textContent||'')===ks).forEach(x=>x.remove())}
     const want=D.key(g.after||g.before),anchor=rows.find(x=>D.key(x.children[1]?.textContent||'')===want);if(!anchor)continue;
     const frag=document.createDocumentFragment();
     g.stops.forEach((n,i)=>{const s=D.stop(n),req=!!s?.plats?.some(p=>p.request);const row=document.createElement('div');row.className='opt41-row'+(i===0?' first':'')+(i===g.stops.length-1?' last':'');
      row.innerHTML='<span class="opt41-dot"></span><span class="opt41-name">('+h(n)+')</span>'+(req?'<span class="request-icon" title="Zastávka na znamení"><i class="fa-solid fa-thumbs-up"></i></span>':'')+(i===0?'<span class="opt41-note">jen některé spoje</span>':'');
      if(s)row.onclick=e=>{e.stopPropagation();try{focusStop(s)}catch(_){}};frag.appendChild(row)});
     if(g.after)anchor.after(frag);else anchor.before(frag);
    }}}}catch(e){window.__report41?.('síť',e)}
   return r};
  try{renderNetwork()}catch(_){}
 }
}catch(e){window.__report41?.('odbočky',e)}})();
/* ---------- Plynulé trasy ve 2D: plátno kreslí i okolí výřezu, překreslí se dřív, než okraj dojede;
   při sevření prsty (pinch) se trasy překreslují průběžně, ne až po skončení ---------- */
(function(){try{
 const rs=new Set();const collect=()=>{rs.clear();for(const id in map._layers){const l=map._layers[id];if(l instanceof L.Renderer)rs.add(l)}if(map._renderer)rs.add(map._renderer)};
 const pad=()=>{const s=map.getSize(),dpr=Math.min(3,window.devicePixelRatio||1),px=s.x*s.y*dpr*dpr;return Math.max(.15,Math.min(.75,(Math.sqrt(11e6/Math.max(1,px))-1)/2))};
 function tune(){collect();const p=pad();rs.forEach(r=>{if(r instanceof L.Canvas){if(Math.abs((r.options.padding||0)-p)>.01){r.options.padding=p;try{r._update()}catch(_){}}}else if(r.options.padding<.5){r.options.padding=.5;try{r._update()}catch(_){}}})}
 tune();setInterval(tune,3000);map.on('resize',tune);
 let raf=0;
 map.on('move',()=>{if(raf||map._animatingZoom)return;raf=requestAnimationFrame(()=>{raf=0;const s=map.getSize(),a=map.containerPointToLayerPoint([0,0]),b=map.containerPointToLayerPoint([s.x,s.y]),m=Math.min(s.x,s.y)*.08;
  rs.forEach(r=>{const B=r._bounds;if(!B)return;if(a.x<B.min.x+m||a.y<B.min.y+m||b.x>B.max.x-m||b.y>B.max.y-m){try{r._update()}catch(_){}}})})});
 /* (průběžné překreslování při pinch zoomu odstraněno – zaokrouhlování na celé pixely způsobovalo „vrtění“ tras;
    plátno se během gesta plynule škáluje a ostře se překreslí po jeho skončení) */
}catch(e){window.__report41?.('plynulé trasy',e)}})();
/* ---------- Úvodní obrazovka: schovat, až je mapa opravdu připravená (podklad + trasy) ---------- */
(function(){const S=window.__splash41;if(!S)return;
 let tiles=false;
 const check=()=>{if(!tiles)return;if(document.readyState==='loading'){document.addEventListener('DOMContentLoaded',check,{once:true});return}requestAnimationFrame(()=>requestAnimationFrame(S.hide))};
 try{let tl=null;map.eachLayer(l=>{if(l instanceof L.TileLayer&&!tl)tl=l});
  if(!tl||!tl._loading&&Object.keys(tl._tiles||{}).length){tiles=true}else{tl.once('load',()=>{tiles=true;check()});setTimeout(()=>{tiles=true;check()},4500)}}catch(_){tiles=true}
 check();
})();

/* ---------- Podklad bez šedých míst: pod hlavní mapou leží předem načtená hrubší kopie stejného stylu,
   takže při oddálení/posunu je hned vidět mapa (rozmazaně) a ostré dlaždice se dočtou nad ní ---------- */
(function(){try{
 if(!map.getPane('bd41')){const p=map.createPane('bd41');p.style.zIndex=150;p.style.pointerEvents='none'}
 let bd=null,src=null;
 function sync(){let base=null;map.eachLayer(l=>{if(l instanceof L.TileLayer&&l.options.pane!=='bd41'&&!base)base=l});if(!base||base===src)return;src=base;
  if(bd){map.removeLayer(bd);bd=null}
  const o=base.options;bd=L.tileLayer(base._url,{tileSize:o.tileSize,zoomOffset:o.zoomOffset,maxZoom:20,maxNativeZoom:11,minZoom:0,crossOrigin:o.crossOrigin,pane:'bd41',keepBuffer:10,updateWhenIdle:false,updateWhenZooming:false,attribution:'',bounds:L.latLngBounds([49.55,17.3],[50.35,18.55])});
  bd.addTo(map)}
 sync();map.on('layeradd',e=>{if(e.layer instanceof L.TileLayer&&e.layer.options.pane!=='bd41')setTimeout(sync,0)});
 const tint=()=>{const c=map.getContainer();c.style.background=document.body.classList.contains('dark')?'#2b2a28':'#ece7e1'};tint();
 new MutationObserver(tint).observe(document.body,{attributes:true,attributeFilter:['class']});
}catch(e){window.__report41?.('podklad mapy',e)}})();
/* ---------- Noční linky 228/229: trasa v mapě (2D i 3D) ---------- */
(function(){try{
 /* trasa skládaná z úseků denních linek (GPS záznamy), které jedou mezi stejnými zastávkami – i otáčení na točnách
    a průjezdy kruhovými objezdy pak odpovídají skutečnosti; jen kde žádná denní linka nejede, použije se trasa po silnicích */
 const PAT=window.__plan41?.PAT||[],RS=window.__plan41?.routeSlice;
 const near=(pts,p)=>{let b=0,bd=1e18;for(let i=0;i<pts.length;i++){const d=(pts[i][0]-p.lat)**2+((pts[i][1]-p.lng)*.643)**2;if(d<bd){bd=d;b=i}}return b};
 function compose(seq,fallback){const out=[];
  for(let k=1;k<seq.length;k++){const A=seq[k-1],Bp=seq[k];let seg=null;
   if(RS)for(const gap of [1,2]){for(const P of PAT){if(P.line==='228'||P.line==='229'||!D.line(P.line)?.city||!(gpxRoutes[P.line]||[]).some(r=>!r.noDrive))continue;
     for(let i=0;i+gap<P.keys.length;i++){if(P.keys[i]!==A.key||P.keys[i+gap]!==Bp.key)continue;try{const r=RS(P.line,P.seq.slice(i,i+gap+1));if(r&&r.length>1){seg=r;break}}catch(_){}}if(seg)break}if(seg)break}
   (window.__night41=window.__night41||{gps:0,road:[]});if(seg)window.__night41.gps++;else window.__night41.road.push(A.name+'→'+Bp.name);
   if(!seg&&fallback?.length>1){const a=near(fallback,A),b=near(fallback,Bp);seg=a<=b?fallback.slice(a,b+1):[[A.lat,A.lng],[Bp.lat,Bp.lng]]}
   if(!seg)seg=[[A.lat,A.lng],[Bp.lat,Bp.lng]];
   for(const p of seg){const q=Array.isArray(p)?p:[p.lat,p.lng];if(!out.length||Math.abs(out.at(-1)[0]-q[0])+Math.abs(out.at(-1)[1]-q[1])>1e-7)out.push(q)}}
  return out}
 for(const n of ['228','229']){const p=XP[n],l=D.line(n);if(!l||(gpxRoutes[n]||[]).length)continue;
  let f=null,b=null;try{f=compose(l.fp,p?.f);b=l.hasBackward?compose(l.bp,p?.b):null}catch(e){window.__report41?.('noční trasa',e)}
  f=f&&f.length>1?f:p?.f;b=b&&b.length>1?b:p?.b;if(!f||f.length<2)continue;
  gpxRoutes[n]=[{file:n+'-A',direction:'A',points:f,noDrive:true,_night:true}];if(b&&b.length>1)gpxRoutes[n].push({file:n+'-B',direction:'B',points:b,noDrive:true,_night:true});
  routePoints[n]=gpxRoutes[n].map(d=>d.points);
  const g=L.layerGroup(),hit=L.layerGroup();
  for(const d of gpxRoutes[n]){const pl=L.polyline(d.points,{color:ROUTE_COLOR,weight:4,opacity:.92,interactive:false,lineCap:'round',lineJoin:'round'});pl.addTo(g);routeLinePolylines.push(pl);
   const h=L.polyline(d.points,{color:'#000',weight:14,opacity:0,interactive:true});h.on('click',e=>{const lines=nearestRouteLines(e.latlng);if(lines.length)L.popup({maxWidth:280}).setLatLng(e.latlng).setContent(routePopup(lines)).openOn(map)});h.addTo(hit)}
  routeLayers[n]=g;routeHitLayers[n]=hit;g.addTo(map);hit.addTo(map)}
 try{refreshRouteLineWidths()}catch(_){}
 try{const s=map3d?.getSource?.('routes-3d');if(s)s.setData(geojsonRoutes())}catch(_){}
}catch(e){window.__report41?.('noční linky',e)}})();

/* ---------- Ruční polohy zastávek (mají přednost i před oficiálními polohami nástupišť) ---------- */
(function(){
 const M=[
  {name:'Kateřinky',lat:49.944264,lng:17.925841,lines:{'202':'*'}},                                     /* konečná 202 – točna na Hlučínské */
  {name:'Kateřinky',lat:49.944461,lng:17.925922,lines:{'219':'*','251':'*','252':'*','254':'*'}},     /* Hlučínská – bez zajížďky na točnu */
  {name:'Zem. tech. škola',lat:49.930385,lng:17.881537,lines:{'201':'Kylešovice, Bílovecká','204':'*'}}
 ];
 window.__manual41=function(fromOfficial){
  const touched=new Set();
  for(const m of M){const k=D.key(m.name),s=D.stops.get(k);if(!s)continue;
   let np=s.plats.find(p=>dist([p.lat,p.lng],[m.lat,m.lng])<4);
   if(!np){const ref=s.plats[0]||{};np={i:D.plats.length,id:'s41-m'+D.plats.length,name:s.name,key:k,lat:m.lat,lng:m.lng,request:!!ref.request,primary:false,lines:new Set(),lineList:[],city:s.city,regional:s.regional,train:s.train,manual:true};D.plats.push(np);s.plats.push(np)}
   for(const [n,dir] of Object.entries(m.lines)){const l=D.line(n);if(!l)continue;
    const arrs=[l.fp,l.bp,...(l.variants||[])].filter(a=>a&&a.length&&(dir==='*'||D.key(a[0].name)===D.key(dir)));
    for(const arr of arrs)for(let i=0;i<arr.length;i++)if(arr[i].key===k)arr[i]=np}
   touched.add(k)}
  /* linky u nástupišť znovu podle tras; nepoužitá nástupiště zastávky pryč */
  for(const k of touched){const s=D.stops.get(k);for(const p of s.plats){p.lines=new Set()}
   for(const l of Object.values(D.lines))for(const arr of [l.fp,l.bp,...(l.variants||[])])for(const p of arr||[])if(p.key===k)p.lines.add(l.num);
   s.plats=s.plats.filter(p=>p.lines.size);for(const p of s.plats)p.lineList=D.sortLines(p.lines)}
  try{for(const P of window.__plan41?.PAT||[]){const c=[0];for(let i=1;i<P.seq.length;i++)c.push(c[i-1]+dist([P.seq[i-1].lat,P.seq[i-1].lng],[P.seq[i].lat,P.seq[i].lng]));P.cum=c}}catch(_){}
  if(!fromOfficial){try{officialStops.length=0;for(const p of window.__markerPlats41())officialStops.push({id:p.id,name:p.name,rawName:p.name,direction:'',desc:'',lat:p.lat,lng:p.lng,request:p.request,key:p.key,lines:p.lineList});renderOfficialStopMarkers()}catch(_){}
   try{if(has3d())build3dStops();update3dStops()}catch(_){}}
 };
 try{window.__manual41(false)}catch(e){console.warn('[ruční polohy]',e)}

})();
/* ---------- Jízda vozidlem: klik na zastávku v panelu = přesun vozidla na tu zastávku (dopředu i zpět) ---------- */
document.addEventListener('click',e=>{const row=e.target.closest?.('#r41-list .r41-stop');if(!row||!rideActive||!rideBus)return;
 if(e.target.closest('.l41,button,a'))return;
 const stops=rideBus._stopsWithDist||[],i=Number(row.dataset.i);const s=stops[i];if(!s)return;
 const d0=Number(rideBus.distance)||0,target=Math.max(0,s.dist-1);if(Math.abs(target-d0)<8){toast41('<i class="fa-solid fa-location-dot"></i> Vozidlo už stojí na zastávce <b>'+h(s.name)+'</b>.',2600);return}
 const fwd=target>d0;
 rideBus.distance=target;rideBus._terminalReached=false;rideBus.effSpeed=null;rideBus._poseLastT=performance.now();rideBus.currentStopIndex=i;delete rideBus._smoothBearing;
 try{if(i===stops.length-1){rideBus._terminalReached=false}}catch(_){}
 panelSig='';try{renderPanel(true)}catch(_){}
 toast41('<i class="fa-solid '+(fwd?'fa-forward':'fa-backward')+'"></i> '+(fwd?'Přeskočeno':'Vráceno')+' na zastávku <b>'+h(s.name)+'</b>'+(fwd?' – zastávky mezi tím vozidlo vynechalo.':' – jízda pokračuje odtud znovu.'),3400);
},true);
/* ---------- Hlavní panel: OpavaGO, podtitul podle zapnutých vrstev, Bedekr (knížka), i = návod, nepřetékání ---------- */
(function(){try{
 const hd=document.querySelector('header');if(!hd)return;
 const h1=hd.querySelector('h1'),sub=h1?.nextElementSibling;
 if(h1)h1.innerHTML='Opava<span class="go41">GO</span>';
 function subUpd(){if(!sub)return;const t=!regioOn&&!trainOn?'Současná síť MHD Opava':regioOn&&!trainOn?'MHD Opava + regionální linky':!regioOn&&trainOn?'MHD Opava + vlaky':'MHD, regionální linky a vlaky';if(sub.textContent!==t)sub.textContent=t}
 subUpd();setInterval(subUpd,400);
 /* Bedekr na vlastní tlačítko s knížkou, „i“ otevře návod */
 const info=$('btn-info');
 if(info&&!$('btn-bedekr')){
  const bk=info.cloneNode(true);bk.id='btn-bedekr';bk.title='Bedekr – průvodce po Opavě';bk.setAttribute('aria-label',bk.title);bk.innerHTML='<i class="fa-solid fa-book-open"></i>';
  bk.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();try{window.__help41?.close()}catch(_){}try{setBedekr(!document.getElementById('bedekr-panel').classList.contains('open'))}catch(_){}});
  info.before(bk);
  const ni=info.cloneNode(true);ni.title='Návod – jak aplikaci používat';ni.setAttribute('aria-label',ni.title);info.replaceWith(ni);
  ni.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();window.__help41?.toggle()})}
 /* když se ikony nevejdou: nejdřív bez textů, a když ani to nestačí, mobilní rozložení */
 let forcedAt=0;
 function fit(){
  if(document.body.classList.contains('m41')&&!window.__forceM41)return;
  if(window.__forceM41){if(innerWidth>forcedAt+60){window.__forceM41=false;hd.classList.remove('hd41-compact');window.__m41apply?.();requestAnimationFrame(fit)}return}
  hd.classList.remove('hd41-compact');
  const over=()=>hd.scrollWidth>hd.clientWidth+2||[...hd.children].some(c=>c.scrollWidth>c.clientWidth+2);
  if(!over())return;hd.classList.add('hd41-compact');
  if(over()){window.__forceM41=true;forcedAt=innerWidth;window.__m41apply?.()}}
 let ft=null;window.addEventListener('resize',()=>{clearTimeout(ft);ft=setTimeout(fit,120)});setTimeout(fit,300);setTimeout(fit,1500);
}catch(e){window.__report41?.('hlavní panel',e)}})();
/* ---------- Návod k aplikaci (tlačítko i) ---------- */
(function(){
 const SECT=[
  ['fa-map','Mapa 2D, Model 3D a 3D PLUS','Vpravo nahoře přepínáte mezi plochou mapou (2D), 3D modelem města s jedoucími vozidly a 3D PLUS. Ve 2D mapě měníte podklad (základní, světlá/tmavá, letecká). Dole vlevo jsou hodiny, měřítko, směrovka severu (ve 3D klikem natočí mapu na sever) a legenda. Tlačítko s terčem vycentruje mapu na Opavu.',[['Otevřít 3D model',()=>window.show3D?.()],['Zpět na 2D',()=>window.show2D?.()]]],
  ['fa-bus','Dopravní síť a linky','Tlačítko Síť zobrazí všechny linky – trolejbusy, autobusy, regionální linky a vlaky. Po rozkliknutí linky uvidíte její trasu (vybraná linka svítí ve své barvě, ostatní se ztlumí), zastávky (na znamení s ikonou ruky), odkaz na jízdní řád a tlačítko Otočit směr. Zastávky v závorce obsluhují jen některé spoje. Tlačítky R a V zapnete na mapě regionální linky a vlaky (včetně náhradní dopravy).',[['Otevřít síť',()=>{try{toggleNetworkPanel()}catch(_){}}]]],
  ['fa-magnifying-glass','Hledání zastávek a spojení','V Hledání najdete zastávku, adresu nebo místo a zastávky v okolí. Na kartě Spojení zadejte Odkud a Kam (zastávku i adresu, šipkou se zaměří vaše poloha). „Odjezd teď“ můžete kliknutím změnit na jiný čas a den. Ve výsledcích jsou časy podle jízdního řádu, pěší úseky s navigací, Dřívější/Další spoje a u každé linky šipky « », kterými spoj posunete na předchozí nebo následující. Zvonkem si nastavíte upozornění na odjezd.',[['Otevřít hledání',()=>$('btn-search')?.click()]]],
  ['dep','Odjezdy ze zastávek','Ikona hodin se šipkou otevře odjezdovou tabuli (nejdřív zastávka Divadlo). Nahoře vyberete jinou zastávku, čas a den, filtrujete linky. Klik na spoj rozbalí jeho další zastávky s časy příjezdu. Odjezdy otevřete i z bubliny každé zastávky na mapě.',[['Otevřít odjezdy',()=>window.openDeparturesPanel?.('Divadlo')]]],
  ['fa-star','Moje místa','Uložte si místa, kam často jezdíte – Domů, Práce, Škola, Taneční nebo cokoli s vlastním názvem a ikonou. Místa jsou nahoře v Hledání i v Odjezdech: klepnutím máte odjezdy z dané zastávky (na kartě Spojení rovnou spojení tam z vaší polohy), tři tečky nabídnou Spojení sem/odtud, Upravit a Smazat. Místa zůstávají jen ve vašem zařízení.',[['Přidat místo',()=>window.__fav41?.editor(null)],['Moje místa',()=>window.__fav41?.manager()]]],
  ['fa-tower-broadcast','Živé polohy a zpoždění','Tlačítko s anténou dole vlevo (nebo Více → Živé polohy) načte polohy vozidel z veřejné mapy ODIS. Vozidla se ukážou na mapě s číslem linky a zpožděním a v Odjezdech přibude u spojů „+N min“. Když data nejsou dostupná, aplikace to oznámí a dál ukazuje polohy podle jízdního řádu.',[['Zapnout živé polohy',()=>window.__live41?.set(true)]]],
  ['fa-route','Jízda vozidlem (3D)','Tlačítko Jízda vozidlem spustí jízdu náhodným vozidlem, tlačítkem + si vyberete linku. Během jízdy vidíte zastávky trasy; klikem na zastávku vozidlo na ni přeskočí (dopředu i zpět). Klik na jiné vozidlo ukáže jeho linku a tlačítko Jet – jízda se přepne na něj. Rychlost a pohled kamery měníte ovládáním na obrazovce.',[]],
  ['jr','Polohy podle jízdního řádu (3D)','Tlačítko JŘ ve 3D zobrazí vozidla tam, kde mají být podle jízdního řádu (bez aktuálních zpoždění).',[]],
  ['fa-cloud-sun','Počasí a denní doba (3D)','Ve 3D si zvolíte východ či západ slunce, den, noc a počasí – jasno, zataženo, déšť nebo sníh.',[]],
  ['fa-warehouse','Garáž','Přehled vozidel MHD Opava s 3D modely a zajímavostmi. Tlačítkem Na 3D mapu vozidlo najdete v provozu.',[['Otevřít garáž',()=>$('btn-garage')?.click()]]],
  ['fa-book-open','Bedekr','Průvodce po památkách, kultuře, rekordech a tradicích Opavy a okolí. Tlačítkem Na mapě (nebo ikonou památky dole vlevo) se památky objeví na mapě jako špendlíky; u každé je „Jak se tam dostanu“, které rovnou vyhledá spojení.',[['Otevřít Bedekr',()=>$('btn-bedekr')?.click()],['Památky na mapě',()=>{window.__bdk41?.set(true);window.__bdk41?.all()}]]],
  ['fa-mobile-screen','Na mobilu','Dole je lišta Hledat, Odjezdy, Síť, Jízda a Více (Moje místa, Garáž, Bedekr, Návod, Živé polohy, tmavý režim, R, V, 3D PLUS, polohy podle JŘ). Panely se otevírají zdola – úchytem je vytáhnete výš nebo stáhnete dolů.',[]],
 ];
 let el=null;
 const icon=k=>k==='dep'?'<i class="dep41-i"></i>':k==='jr'?MONO('JŘ','jr'):'<i class="fa-solid '+k+'"></i>';
 function build(){el=document.createElement('aside');el.id='help41';el.setAttribute('role','dialog');el.setAttribute('aria-label','Návod k aplikaci');
  el.innerHTML='<div class="help41-head"><div class="help41-logo"></div><div class="help41-tt"><div class="help41-eb">Návod</div><div class="help41-name">Jak používat Opava<span class="go41">GO</span></div></div><button type="button" class="help41-x" aria-label="Zavřít"><i class="fa-solid fa-xmark"></i></button></div>'
   +'<div class="help41-body">'+SECT.map((s,i)=>'<details class="help41-sec"'+(i===0?' open':'')+'><summary><span class="help41-ic">'+icon(s[0])+'</span><span>'+h(s[1])+'</span><i class="fa-solid fa-chevron-down"></i></summary><p>'+h(s[2])+'</p>'+(s[3].length?'<div class="help41-acts">'+s[3].map((a,j)=>'<button type="button" data-s="'+i+'" data-a="'+j+'"><i class="fa-solid fa-play"></i> '+h(a[0])+'</button>').join('')+'</div>':'')+'</details>').join('')
   +'<p class="help41-note">Časy vycházejí z jízdních řádů (bez aktuálních zpoždění). Data: CIS JŘ, KODIS, MDPO, OpenStreetMap, Mapbox.</p></div>';
  const lg=document.querySelector('.app-route-icon img');if(lg)el.querySelector('.help41-logo').innerHTML='<img alt="" src="'+lg.src+'">';
  document.body.appendChild(el);el.querySelector('.help41-x').onclick=close;
  el.querySelectorAll('.help41-acts button').forEach(b=>b.onclick=()=>{close();try{SECT[+b.dataset.s][3][+b.dataset.a][1]()}catch(_){}});
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&el.classList.contains('open'))close()})}
 function open(){if(!el)build();try{setBedekr(false)}catch(_){}el.classList.add('open')}
 function close(){el?.classList.remove('open')}
 window.__help41={open,close,toggle:()=>{if(el?.classList.contains('open'))close();else open()}};
})();
/* ---------- Hledání: tlačítka vymazat, vymazání po zavření panelu ---------- */
(function(){try{
 const IDS={stops:['stop-address'],conn:['from-address','to-address']};
 function clearInputs(ids){for(const id of ids){const el=$(id);if(!el)continue;el.value='';for(const k of ['lat','lng','stop','idos'])delete el.dataset[k];el.dispatchEvent(new Event('input',{bubbles:true}));el.closest('.search-field')?.querySelector('.sug41')?.setAttribute('hidden','');syncX(el)}}
 function clearResults(which){
  if(which!=='conn'){const b=$('nearest-results');if(b)b.innerHTML='';const s=$('nearest-status');if(s)s.textContent=''}
  if(which!=='stops'){const b=$('connection-results');if(b)b.innerHTML='';const s=$('connection-status');if(s)s.textContent='';try{lastPlan=null}catch(_){}}
  try{searchRouteLayer.clearLayers()}catch(_){}try{clearHighlights()}catch(_){}try{clear3dSearch()}catch(_){}try{window.restoreBaseNetworkAfterSearch?.()}catch(_){}}
 const clearAll=()=>{clearInputs([...IDS.stops,...IDS.conn]);clearResults('all')};
 function syncX(el){const x=el.closest('.search-field')?.querySelector('.clr41');if(x)x.hidden=!el.value}
 for(const id of [...IDS.stops,...IDS.conn]){const el=$(id),f=el?.closest('.search-field');if(!el||!f||f.querySelector('.clr41'))continue;
  const x=document.createElement('button');x.type='button';x.className='clr41';x.title='Vymazat';x.setAttribute('aria-label','Vymazat');x.innerHTML='<i class="fa-solid fa-xmark"></i>';x.hidden=true;
  x.onmousedown=e=>e.preventDefault();x.onclick=e=>{e.preventDefault();clearInputs([id]);el.focus()};
  el.after(x);el.addEventListener('input',()=>syncX(el));el.addEventListener('change',()=>syncX(el));setInterval(()=>syncX($(id)||el),800)}
 const sw=$('swap-search');if(sw&&!$('clear-conn41')){const b=document.createElement('button');b.type='button';b.id='clear-conn41';b.className='search-secondary';b.innerHTML='<i class="fa-solid fa-eraser"></i> Vymazat';b.onclick=e=>{e.preventDefault();clearInputs(IDS.conn);clearResults('conn')};sw.after(b);sw.parentElement?.classList.add('row41-btns')}
 const fn=$('find-nearest');if(fn&&!$('clear-stops41')){const b=document.createElement('button');b.type='button';b.id='clear-stops41';b.className='search-secondary clear41-stops';b.innerHTML='<i class="fa-solid fa-eraser"></i> Vymazat';b.onclick=e=>{e.preventDefault();clearInputs(IDS.stops);clearResults('stops')};fn.before(b)}
 /* po zavření panelu hledání vše smazat */
 const p=$('search-panel');if(p){let was=p.classList.contains('open');new MutationObserver(()=>{const now=p.classList.contains('open');if(was&&!now)setTimeout(clearAll,0);was=now}).observe(p,{attributes:true,attributeFilter:['class']})}
 window.__clearSearch41=clearAll;
}catch(e){window.__report41?.('vymazat hledání',e)}})();
/* ---------- Zvonek: upozornění na odjezd spoje (odpočet minut) ---------- */
(function(){
 const TT=window.__tt41;let alert=null,timer=null,lastMin=null,pop=null;
 const KEY='opavago-alert';
 const absMs=(c,mins)=>{const [y,m,d]=TT.R.base.split('-').map(Number);const day=new Date(y,m-1,d);day.setDate(day.getDate()+(c.di??TT.dayIdx(new Date())));return day.getTime()+mins*60000};
 const fmt=ms=>{const d=new Date(ms);return d.getHours()+':'+String(d.getMinutes()).padStart(2,'0')};
 function describe(c){const g=c.legs[0],L=c.legs.at(-1),from=g.P.seq[g.a].name,head=g.trip?(D.stops.get(g.trip.keys.at(-1))?.name||g.P.seq.at(-1).name):g.P.seq.at(-1).name,to=L.P.seq[L.b].name;
  return{line:g.P.line,from,head,dep:absMs(c,g.dep),arr:absMs(c,L.arr),to,transfers:c.legs.length-1,sig:c.sig}}
 function text(a,min){const when=min<=0?'odjíždí právě teď':min===1?'odjíždí za 1 minutu':'odjíždí za '+min+' '+(min<5?'minuty':'minut');
  return{title:'Linka '+a.line+' '+when,body:'Ze zastávky '+a.from+' směr '+a.head+' v '+fmt(a.dep)+'. Příjezd do '+a.to+' v '+fmt(a.arr)+(a.transfers?' ('+a.transfers+'× přestup)':'')+'.'}}
 let banner=null;
 function showBanner(t){if(!banner){banner=document.createElement('div');banner.id='bell41-banner';banner.setAttribute('role','status');document.body.appendChild(banner)}
  banner.innerHTML='<i class="fa-solid fa-bell"></i><div><b>'+h(t.title)+'</b><small>'+h(t.body)+'</small></div><button type="button" aria-label="Zrušit upozornění">×</button>';banner.hidden=false;banner.querySelector('button').onclick=()=>cancel()}
 function notify(t){let shown=false;
  try{if('Notification' in window&&Notification.permission==='granted'){new Notification(t.title,{body:t.body,tag:'opavago-odjezd',renotify:false,silent:false,icon:document.querySelector('link[rel=icon]')?.href});shown=true}}catch(_){}
  showBanner(t);return shown}
 function tick(){if(!alert)return;const left=alert.dep-Date.now(),min=Math.ceil(left/60000);
  if(left<-60000){cancel(true);return}
  if(min>alert.lead){if(banner)banner.hidden=true;return}
  const m=Math.max(0,min);if(m!==lastMin){lastMin=m;notify(text(alert,m));if((m===alert.lead||m===1||m===0)&&navigator.vibrate)try{navigator.vibrate([180,80,180])}catch(_){}}}
 function start(c,lead){alert={...describe(c),lead};lastMin=null;try{localStorage.setItem(KEY,JSON.stringify(alert))}catch(_){}
  clearInterval(timer);timer=setInterval(tick,5000);tick();
  if('Notification' in window&&Notification.permission==='default')try{Notification.requestPermission().then(()=>tick())}catch(_){}
  toast41('<i class="fa-solid fa-bell"></i> Upozorníme vás '+lead+' min před odjezdem linky <b>'+h(alert.line)+'</b> ze zastávky '+h(alert.from)+' ('+fmt(alert.dep)+').',3600);refresh()}
 function cancel(silent){alert=null;clearInterval(timer);timer=null;if(banner)banner.hidden=true;try{localStorage.removeItem(KEY)}catch(_){}if(!silent)toast41('<i class="fa-regular fa-bell-slash"></i> Upozornění zrušeno.',2200);refresh()}
 function refresh(){document.querySelectorAll('.bell41-btn').forEach(b=>{const on=!!alert;b.classList.toggle('on',on);b.querySelector('i').className='fa-'+(on?'solid':'regular')+' fa-bell'})}
 function panel(c,btn){pop?.remove();const a=describe(c);let lead=Number(localStorage.getItem('opavago-lead'))||15;
  pop=document.createElement('div');pop.className='bell41-pop';pop.innerHTML='<div class="bell41-h"><i class="fa-solid fa-bell"></i> Upozornit na odjezd</div><div class="bell41-s">Linka <b>'+h(a.line)+'</b> ze zastávky '+h(a.from)+' v '+fmt(a.dep)+'</div>'
   +'<label class="bell41-l">Kolik minut předem: <b class="bell41-v">'+lead+' min</b><input type="range" min="1" max="60" step="1" value="'+lead+'"></label>'
   +'<div class="bell41-a">'+(alert&&alert.sig===a.sig?'<button type="button" class="bell41-off">Zrušit upozornění</button>':'')+'<button type="button" class="bell41-on">'+(alert&&alert.sig===a.sig?'Uložit':'Zapnout upozornění')+'</button></div>'
   +'<div class="bell41-n">Upozornění se odpočítává po minutách. Systémové oznámení se zobrazí, pokud ho prohlížeč povolí; jinak se odpočet ukáže v aplikaci (musí zůstat otevřená).</div>';
  btn.closest('.plan41').querySelector('.plan41-head').after(pop);
  const r=pop.querySelector('input'),v=pop.querySelector('.bell41-v');r.oninput=()=>{v.textContent=r.value+' min'};
  pop.querySelector('.bell41-on').onclick=()=>{lead=Number(r.value);try{localStorage.setItem('opavago-lead',lead)}catch(_){}pop.remove();pop=null;start(c,lead)};
  pop.querySelector('.bell41-off')?.addEventListener('click',()=>{pop.remove();pop=null;cancel()})}
 try{const s=JSON.parse(localStorage.getItem(KEY)||'null');if(s&&s.dep>Date.now()-60000){alert=s;timer=setInterval(tick,5000);tick()}}catch(_){}
 window.__bell41={panel,cancel,isFor:c=>!!alert&&alert.sig===c?.sig};
})();
/* ---------- Moje místa: Domů, Práce, Škola… (vlastní název a ikona, odjezdy na jeden klik) ---------- */
(function(){try{
 const KEY='opavago-places',ICONS=['house','briefcase','graduation-cap','music','dumbbell','futbol','heart','cart-shopping','hospital','person-swimming','tree','star'];
 const PRESET=[['Domů','house'],['Práce','briefcase'],['Škola','graduation-cap'],['Taneční','music'],['Trénink','dumbbell'],['Babička','heart']];
 const load=()=>{try{const a=JSON.parse(localStorage.getItem(KEY)||'[]');return Array.isArray(a)?a.filter(p=>p&&p.name&&(p.stop||Number.isFinite(p.lat))):[]}catch(_){return[]}};
 let P=load();
 const save=()=>{try{localStorage.setItem(KEY,JSON.stringify(P))}catch(_){}renderAll()};
 const stopOf=p=>p.stop&&D.stops.get(p.stop)||null;
 const DEP=()=>window.__dep42;
 const hasTT=k=>{try{return !!DEP()?.index().has(k)}catch(_){return false}};
 function nearestStop(lat,lng){let b=null;for(const s of D.stops.values()){if(!s.lines||!s.lines.size||!hasTT(s.key))continue;const d=dist([lat,lng],[s.lat,s.lng]);if(!b||d<b.d)b={s,d}}return b?.s||null}
 const label=p=>stopOf(p)?.name||p.stopName||'';
 /* akce */
 function departures(p){const s=stopOf(p)||(Number.isFinite(p.lat)?nearestStop(p.lat,p.lng):null);if(!s){toast41('Pro místo „'+h(p.name)+'“ neznáme zastávku.');return}
  try{if($('search-panel')?.classList.contains('open'))closeSearch()}catch(_){}window.openDeparturesPanel?.(s.name)}
 function fill(id,p){const el=$(id);if(!el)return;for(const k of ['lat','lng','stop','idos'])delete el.dataset[k];
  if(Number.isFinite(p.lat)&&!p.stop){el.value=p.name;el.dataset.lat=p.lat;el.dataset.lng=p.lng}
  else{const s=stopOf(p);if(!s)return;el.value=s.name;el.dataset.stop=s.key;el.dataset.lat=s.lat;el.dataset.lng=s.lng}
  el.dispatchEvent(new Event('change',{bubbles:true}))}
 function route(p,dir){/* dir: 'to' = spojení sem, 'from' = spojení odtud */
  try{window.closeDeparturesPanel?.()}catch(_){}try{if(!$('search-panel')?.classList.contains('open'))$('btn-search')?.click()}catch(_){}
  try{setSearchTab('connection')}catch(_){$('search-tab-connection')?.click()}
  const me=dir==='to'?'from-address':'to-address',it=dir==='to'?'to-address':'from-address';fill(it,p);
  const go=()=>{try{window.runConnectionSearch()}catch(_){$('find-connection')?.click()}};
  if($(me)?.value.trim()){go();return}
  if(!navigator.geolocation){$(me)?.focus();return}
  toast41('<i class="fa-solid fa-location-crosshairs"></i> Zjišťuji vaši polohu…',2500);
  navigator.geolocation.getCurrentPosition(pos=>{try{setLocationToInput(me,pos.coords.latitude,pos.coords.longitude,'Moje poloha')}catch(_){}go()},
   ()=>{toast41('Poloha není povolená – doplňte '+(dir==='to'?'Odkud':'Kam')+'.');$(me)?.focus()},{enableHighAccuracy:true,timeout:9000,maximumAge:60000})}
 /* lišta míst */
 function strip(ctx){
  const chips=P.map((p,i)=>'<span class="fav41-chip" data-i="'+i+'"><button type="button" class="fav41-go" title="'+(ctx==='conn'?'Spojení sem':'Odjezdy')+' – '+h(label(p))+'"><i class="fa-solid fa-'+h(p.icon||'star')+'"></i><span>'+h(p.name)+'</span></button><button type="button" class="fav41-more" aria-label="Další možnosti pro '+h(p.name)+'"><i class="fa-solid fa-ellipsis"></i></button></span>').join('');
  const empty=P.length?'':PRESET.slice(0,2).map(([n,ic])=>'<button type="button" class="fav41-add ghost" data-n="'+n+'" data-ic="'+ic+'"><i class="fa-solid fa-'+ic+'"></i><span>'+n+'</span><i class="fa-solid fa-plus fav41-plus"></i></button>').join('');
  return chips+empty+'<button type="button" class="fav41-add" title="Přidat místo" aria-label="Přidat místo"><i class="fa-solid fa-plus"></i>'+(P.length?'':'<span>Jiné</span>')+'</button>'}
 function mount(host,ctx,where){if(!host)return null;let s=host.querySelector(':scope > .fav41-strip');if(!s){s=document.createElement('div');s.className='fav41-strip';s.dataset.ctx=ctx;s.setAttribute('aria-label','Moje místa');where(s)}return s}
 function strips(){const out=[];const sp=$('search-panel'),tabs=sp?.querySelector('.search-tabs');if(tabs)out.push(mount(sp,'search',s=>tabs.after(s)));
  const dp=$('dep42'),pick=dp?.querySelector('.dep42-pick');if(pick)out.push(mount(dp,'dep',s=>pick.after(s)));return out.filter(Boolean)}
 function renderAll(){for(const s of strips()){const ctx=s.dataset.ctx==='search'&&$('search-connection-view')?.style.display!=='none'?'conn':s.dataset.ctx;s.dataset.mode=ctx;s.innerHTML='<span class="fav41-lab"><i class="fa-solid fa-star"></i></span>'+strip(ctx)}if(mg&&!mg.hidden)renderMgr()}
 document.addEventListener('click',e=>{const s=e.target.closest('.fav41-strip');if(!s)return;
  const add=e.target.closest('.fav41-add');if(add){e.preventDefault();editor(null,add.dataset.n?{name:add.dataset.n,icon:add.dataset.ic}:null);return}
  const c=e.target.closest('.fav41-chip');if(!c)return;const p=P[+c.dataset.i];if(!p)return;e.preventDefault();
  if(e.target.closest('.fav41-more')){menu(p,c);return}
  if(s.dataset.mode==='conn')route(p,'to');else departures(p)});
 /* malé menu u místa */
 let mn=null;
 function menu(p,anchor){mn?.remove();mn=document.createElement('div');mn.className='fav41-menu';mn.setAttribute('role','menu');
  const i=P.indexOf(p),s=stopOf(p);
  mn.innerHTML='<div class="fav41-mh"><i class="fa-solid fa-'+h(p.icon||'star')+'"></i><div><b>'+h(p.name)+'</b><small>'+h(label(p)||'vlastní poloha')+'</small></div></div>'
   +'<button type="button" data-a="dep"><i class="fa-solid fa-clock"></i>Odjezdy odtud</button>'
   +'<button type="button" data-a="to"><i class="fa-solid fa-route"></i>Spojení sem</button>'
   +'<button type="button" data-a="from"><i class="fa-solid fa-arrow-right-from-bracket"></i>Spojení odtud</button>'
   +(s||Number.isFinite(p.lat)?'<button type="button" data-a="map"><i class="fa-solid fa-map-location-dot"></i>Ukázat na mapě</button>':'')
   +'<div class="fav41-msep"></div>'
   +'<button type="button" data-a="edit"><i class="fa-solid fa-pen"></i>Upravit</button>'
   +(i>0?'<button type="button" data-a="up"><i class="fa-solid fa-arrow-left"></i>Posunout dopředu</button>':'')
   +'<button type="button" data-a="del" class="danger"><i class="fa-solid fa-trash"></i>Smazat</button>';
  document.body.appendChild(mn);const r=anchor.getBoundingClientRect(),w=mn.offsetWidth,hh=mn.offsetHeight;
  mn.style.left=Math.max(8,Math.min(innerWidth-w-8,r.left))+'px';mn.style.top=(r.bottom+6+hh>innerHeight?Math.max(8,r.top-hh-6):r.bottom+6)+'px';
  mn.onclick=e=>{const a=e.target.closest('[data-a]')?.dataset.a;if(!a)return;mn.remove();mn=null;
   if(a==='dep')departures(p);else if(a==='to'||a==='from')route(p,a);
   else if(a==='map'){const q=s||p;try{if(is3dOn()&&has3d())map3d.flyTo({center:[q.lng,q.lat],zoom:16.2,duration:900});else map.flyTo([q.lat,q.lng],17,{duration:.8})}catch(_){}}
   else if(a==='edit')editor(p);else if(a==='up'){P.splice(i,1);P.splice(i-1,0,p);save()}
   else if(a==='del'){if(confirm('Smazat místo „'+p.name+'“?')){P.splice(i,1);save();toast41('Místo „'+h(p.name)+'“ smazáno.')}}};
  setTimeout(()=>document.addEventListener('click',function off(e){if(mn&&!mn.contains(e.target)){mn.remove();mn=null}if(!mn)document.removeEventListener('click',off,true)},true),0)}
 /* editor místa */
 let ed=null;
 function editor(p,preset){ed?.remove();const cur=p?{...p}:{name:preset?.name||'',icon:preset?.icon||'star'};
  ed=document.createElement('div');ed.id='fav41-ed';ed.className='fav41-ov';ed.setAttribute('role','dialog');ed.setAttribute('aria-modal','true');ed.setAttribute('aria-label',p?'Upravit místo':'Nové místo');
  ed.innerHTML='<div class="fav41-dlg"><div class="fav41-dh"><div class="fav41-ic"><i class="fa-solid fa-'+h(cur.icon)+'"></i></div><div><small>Moje místa</small><b>'+(p?'Upravit místo':'Nové místo')+'</b></div><button type="button" class="fav41-x" aria-label="Zavřít"><i class="fa-solid fa-xmark"></i></button></div>'
   +'<label class="fav41-l">Název<input class="fav41-name" maxlength="24" placeholder="např. Domů, Škola, Taneční…" value="'+h(cur.name)+'"></label>'
   +'<div class="fav41-pre">'+PRESET.map(([n,ic])=>'<button type="button" data-n="'+n+'" data-ic="'+ic+'"><i class="fa-solid fa-'+ic+'"></i>'+n+'</button>').join('')+'</div>'
   +'<div class="fav41-l">Ikona<div class="fav41-icons">'+ICONS.map(ic=>'<button type="button" data-ic="'+ic+'" class="'+(ic===cur.icon?'on':'')+'" aria-label="'+ic+'"><i class="fa-solid fa-'+ic+'"></i></button>').join('')+'</div></div>'
   +'<label class="fav41-l">Zastávka nebo místo<div class="fav41-sw"><input class="fav41-stop" placeholder="Začněte psát název zastávky…" autocomplete="off" value="'+h(stopOf(cur)?.name||(Number.isFinite(cur.lat)&&!cur.stop?'Moje poloha':''))+'"><div class="fav41-sug" hidden></div></div></label>'
   +'<div class="fav41-locs"><button type="button" class="fav41-me"><i class="fa-solid fa-location-crosshairs"></i>Moje poloha</button><button type="button" class="fav41-ctr"><i class="fa-solid fa-crosshairs"></i>Střed mapy</button></div>'
   +'<div class="fav41-hint"></div>'
   +'<div class="fav41-btns"><button type="button" class="fav41-cancel">Zrušit</button><button type="button" class="fav41-save"><i class="fa-solid fa-check"></i>Uložit</button></div></div>';
  document.body.appendChild(ed);
  const q=c=>ed.querySelector(c),nm=q('.fav41-name'),si=q('.fav41-stop'),sg=q('.fav41-sug'),hint=q('.fav41-hint');
  const setIc=ic=>{cur.icon=ic;q('.fav41-ic').innerHTML='<i class="fa-solid fa-'+ic+'"></i>';ed.querySelectorAll('.fav41-icons button').forEach(b=>b.classList.toggle('on',b.dataset.ic===ic))};
  const showHint=()=>{const s=stopOf(cur);hint.innerHTML=s?'<i class="fa-solid fa-circle-check"></i> Odjezdy ze zastávky <b>'+h(s.name)+'</b>':Number.isFinite(cur.lat)?'<i class="fa-solid fa-circle-info"></i> Odjezdy z nejbližší zastávky'+(nearestStop(cur.lat,cur.lng)?' <b>'+h(nearestStop(cur.lat,cur.lng).name)+'</b>':''):''};
  showHint();
  ed.querySelectorAll('.fav41-pre button').forEach(b=>b.onclick=()=>{nm.value=b.dataset.n;setIc(b.dataset.ic)});
  ed.querySelectorAll('.fav41-icons button').forEach(b=>b.onclick=()=>setIc(b.dataset.ic));
  const CAND=[...D.stops.values()].filter(s=>s.lines&&s.lines.size).map(s=>({s,f:D.fold(s.name)}));
  si.oninput=()=>{const t=D.fold(si.value.trim());if(!t){sg.hidden=true;return}
   const hits=CAND.filter(x=>x.f.includes(t)).sort((a,b)=>(a.f.startsWith(t)?0:1)-(b.f.startsWith(t)?0:1)||(b.s.city-a.s.city)||a.f.length-b.f.length).slice(0,7);
   sg.innerHTML=hits.length?hits.map((x,i)=>'<button type="button" data-i="'+i+'">'+h(x.s.name)+'<small>'+h([...x.s.lines].slice(0,8).join(' · '))+'</small></button>').join(''):'<div class="fav41-none">Zastávku neznáme</div>';sg.hidden=false;
   sg.querySelectorAll('button').forEach(b=>b.onclick=()=>{const s=hits[+b.dataset.i].s;cur.stop=s.key;cur.stopName=s.name;delete cur.lat;delete cur.lng;si.value=s.name;sg.hidden=true;showHint()})};
  si.onkeydown=e=>{if(e.key==='Enter'){const b=sg.querySelector('button');if(b){e.preventDefault();b.click()}}};
  const setPt=(lat,lng,txt)=>{cur.lat=lat;cur.lng=lng;const s=nearestStop(lat,lng);if(s&&dist([lat,lng],[s.lat,s.lng])<120){cur.stop=s.key;cur.stopName=s.name;si.value=s.name}else{delete cur.stop;cur.stopName=s?.name||'';si.value=txt}showHint()};
  q('.fav41-me').onclick=()=>{if(!navigator.geolocation){hint.textContent='Zařízení nepodporuje polohu.';return}hint.textContent='Zjišťuji polohu…';
   navigator.geolocation.getCurrentPosition(pos=>setPt(pos.coords.latitude,pos.coords.longitude,'Moje poloha'),()=>{hint.textContent='Poloha není povolená. Vyberte zastávku.'},{enableHighAccuracy:true,timeout:9000})};
  q('.fav41-ctr').onclick=()=>{try{const c=is3dOn()&&has3d()?map3d.getCenter():map.getCenter();setPt(c.lat,c.lng,'Bod na mapě')}catch(_){}};
  const close=()=>{ed?.remove();ed=null};
  q('.fav41-x').onclick=close;q('.fav41-cancel').onclick=close;ed.onclick=e=>{if(e.target===ed)close()};
  ed.addEventListener('keydown',e=>{if(e.key==='Escape')close()});
  q('.fav41-save').onclick=()=>{const name=nm.value.trim();if(!name){nm.focus();hint.textContent='Doplňte název místa.';return}
   if(!cur.stop&&!Number.isFinite(cur.lat)){si.focus();hint.textContent='Vyberte zastávku nebo použijte polohu.';return}
   const rec={id:cur.id||('p'+Date.now().toString(36)),name,icon:cur.icon||'star'};if(cur.stop){rec.stop=cur.stop;rec.stopName=cur.stopName||stopOf(cur)?.name}if(Number.isFinite(cur.lat)){rec.lat=+cur.lat.toFixed(6);rec.lng=+cur.lng.toFixed(6)}
   const i=p?P.indexOf(p):-1;if(i>=0)P[i]=rec;else P.push(rec);save();close();toast41('<i class="fa-solid fa-'+h(rec.icon)+'"></i> Místo „'+h(name)+'“ uloženo.')};
  setTimeout(()=>(cur.name?si:nm).focus(),50)}
 /* správa (z nabídky Více) */
 let mg=null;
 function renderMgr(){mg.querySelector('.fav41-list').innerHTML=P.length?P.map((p,i)=>'<div class="fav41-row" data-i="'+i+'"><span class="fav41-ic"><i class="fa-solid fa-'+h(p.icon||'star')+'"></i></span><span class="fav41-rt"><b>'+h(p.name)+'</b><small>'+h(label(p)||'vlastní poloha')+'</small></span><button type="button" data-a="dep" title="Odjezdy"><i class="fa-solid fa-clock"></i></button><button type="button" data-a="to" title="Spojení sem"><i class="fa-solid fa-route"></i></button><button type="button" data-a="more" title="Další"><i class="fa-solid fa-ellipsis"></i></button></div>').join(''):'<div class="fav41-emp"><i class="fa-regular fa-star"></i><p>Uložte si místa, kam často jezdíte – domov, práci, školu, taneční… Odjezdy pak máte na jeden klik.</p></div>'}
 function manager(){if(!mg){mg=document.createElement('div');mg.id='fav41-mgr';mg.className='fav41-ov';mg.hidden=true;
   mg.innerHTML='<div class="fav41-dlg"><div class="fav41-dh"><div class="fav41-ic"><i class="fa-solid fa-star"></i></div><div><small>OpavaGO</small><b>Moje místa</b></div><button type="button" class="fav41-x" aria-label="Zavřít"><i class="fa-solid fa-xmark"></i></button></div><div class="fav41-list"></div><div class="fav41-btns"><button type="button" class="fav41-save fav41-new"><i class="fa-solid fa-plus"></i>Přidat místo</button></div></div>';
   document.body.appendChild(mg);mg.querySelector('.fav41-x').onclick=()=>mg.hidden=true;mg.onclick=e=>{if(e.target===mg)mg.hidden=true};
   mg.querySelector('.fav41-new').onclick=()=>editor(null);
   mg.querySelector('.fav41-list').onclick=e=>{const b=e.target.closest('[data-a]'),r=e.target.closest('.fav41-row');if(!b||!r)return;const p=P[+r.dataset.i];
    if(b.dataset.a==='more'){menu(p,b);return}mg.hidden=true;if(b.dataset.a==='dep')departures(p);else route(p,'to')}}
  renderMgr();mg.hidden=false}
 /* překreslit lištu při přepnutí záložky hledání a při otevření odjezdů */
 for(const id of ['search-tab-stops','search-tab-connection'])$(id)?.addEventListener('click',()=>setTimeout(renderAll,0));
 new MutationObserver(()=>{if($('dep42')&&!$('dep42').querySelector('.fav41-strip'))renderAll()}).observe(document.body,{childList:true});
 window.addEventListener('storage',e=>{if(e.key===KEY){P=load();renderAll()}});
 renderAll();
 window.__fav41={key:n=>D.stop(n)?.key,list:()=>P,add:r=>{P.push(r);save()},editor,manager,departures,route,render:renderAll};
}catch(e){window.__report41?.('moje místa',e)}})();
/* ---------- Vybraná linka vyniká v barvě linky, ostatní trasy zůstávají ztlumené (2D i 3D) ---------- */
(function(){try{
 const so=window.showOnlyLineOnMap,sa=window.showAllLinesOnMap;if(typeof so!=='function'||typeof sa!=='function')return;
 let sel=null,p3=null;
 const polys=(g,f)=>g&&g.eachLayer&&g.eachLayer(l=>{if(l.setStyle)f(l);else if(l.eachLayer)polys(l,f)});
 const dark=()=>document.body.classList.contains('dark');
 function undim2d(){for(const g of Object.values(routeLayers))polys(g,l=>{if(l.__o41){l.setStyle(l.__o41);delete l.__o41}})}
 function dim2d(n){undim2d();
  const col=D.color?.(n)||lineBadgeColor?.(n)||'#C1784F',ghost=dark()?'#77706a':'#a39c95';
  for(const [k,g] of Object.entries(routeLayers)){
   if(k!==n){try{map.addLayer(g)}catch(_){}if(!map.hasLayer(g))continue}
   polys(g,l=>{const o=l.options||{};l.__o41={color:o.color,opacity:o.opacity,weight:o.weight};
    if(k===n){const white=/^#?fff/i.test(String(o.color||''));l.setStyle(white?{opacity:.95}:{color:col,opacity:1,weight:(o.weight||4)+1.5})}
    else l.setStyle({color:/^#?fff/i.test(String(o.color||''))?'#ffffff':ghost,opacity:/^#?fff/i.test(String(o.color||''))?0:.28,weight:Math.max(2,(o.weight||4)-1)})})}
  polys(routeLayers[n],l=>{try{l.bringToFront()}catch(_){}})}
 function dim3d(n){try{if(typeof map3d==='undefined'||!map3d||!map3d.getLayer('routes-3d-line'))return;
  if(!p3)p3={c:map3d.getPaintProperty('routes-3d-line','line-color'),o:map3d.getPaintProperty('routes-3d-line','line-opacity')};
  const col=D.color?.(n)||'#C1784F',ghost=dark()?'#6f6862':'#a39c95',is=['==',['get','line'],n];
  map3d.setFilter('routes-3d-line',null);if(map3d.getLayer('routes-3d-hit'))map3d.setFilter('routes-3d-hit',is);
  map3d.setPaintProperty('routes-3d-line','line-color',['case',is,col,ghost]);
  map3d.setPaintProperty('routes-3d-line','line-opacity',['case',is,1,.3]);
  map3d.setLayoutProperty('routes-3d-line','line-sort-key',['case',is,10,0])}catch(_){}}
 function undim3d(){try{if(!p3||typeof map3d==='undefined'||!map3d||!map3d.getLayer('routes-3d-line'))return;
  const dk=dark();map3d.setPaintProperty('routes-3d-line','line-color',typeof p3.c==='string'?(dk?'#E39A70':'#C1784F'):p3.c);
  map3d.setPaintProperty('routes-3d-line','line-opacity',p3.o??.92);p3=null}catch(_){}}
 window.showOnlyLineOnMap=showOnlyLineOnMap=function(n){const r=so.apply(this,arguments);sel=String(n);try{dim2d(sel);dim3d(sel)}catch(e){console.warn('[zvýraznění]',e)}return r};
 window.showAllLinesOnMap=showAllLinesOnMap=function(){sel=null;try{undim2d();undim3d()}catch(_){}return sa.apply(this,arguments)};
 /* přepnutí tmavého režimu nebo 3D přebarví trasy – vybranou linku pak zvýraznit znovu */
 new MutationObserver(()=>{if(sel)setTimeout(()=>{if(sel){dim2d(sel);p3=null;dim3d(sel)}},60)}).observe(document.body,{attributes:true,attributeFilter:['class']});
 window.__hl41={get:()=>sel};
}catch(e){window.__report41?.('zvýraznění linky',e)}})();
/* ---------- Bedekr na mapě: špendlíky památek, „Jak se tam dostanu“ ----------
   Polohy: Overture Maps / OpenStreetMap (Opava), Wikipedie a turistika.cz (okolí). */
(function(){try{
 const POS={hlaska:[49.938678,17.901962],hradec:[49.8712,17.8757],muzeum:[49.937283,17.908527],konkatedrala:[49.93835,17.90055],radun:[49.892873,17.943243],
  hrabyne:[49.8822,18.0535],arboretum:[49.9367,17.7806],divadlo:[49.939028,17.901071],kravare:[49.932,18.005],darkovicky:[49.9252,18.2213],
  breda:[49.940273,17.8995],sibenice:[49.9435,17.7905],'sv-hedvika':[49.941384,17.89249],'dvorakovy-sady':[49.938022,17.899249],
  minorite:[49.936188,17.90385],'sv-vojtech':[49.93925,17.90598],'sv-vaclav':[49.9403,17.9032],bezruc:[49.936419,17.901882],
  'svedska-kaple':[49.945107,17.921156],'horni-namesti':[49.93905,17.9027],tradice:[49.93915,17.9019]};
 const KEY='opavago-bdkmap';
 const places=()=>(window.__places41||[]).filter(p=>POS[p.id]);
 let on=false,grp=null,mk3=[];
 const esc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
 const thumb=p=>String(p.thumbnail||'').replace(/width=\d+/,'width=160');
 function pinEl(p){const d=document.createElement('div');d.className='bdk41-pin';d.title=p.title;d.innerHTML='<span class="bdk41-ph"><img alt="" loading="lazy" src="'+esc(thumb(p))+'" onerror="this.remove()"><i class="fa-solid fa-landmark"></i></span><b>'+esc(p.title.replace(/\s*\(.*\)$/,''))+'</b>';return d}
 function popHTML(p){return '<div class="bdk41-pop"><div class="bdk41-pi" style="--bg:url(\''+esc(thumb(p).replace('width=160','width=480'))+'\')"></div><div class="bdk41-pb"><small>'+esc(p.type)+'</small><strong>'+esc(p.title)+'</strong><p>'+esc(p.shortDesc)+'</p>'
  +'<div class="bdk41-pa"><button type="button" class="bdk41-go" data-id="'+esc(p.id)+'"><i class="fa-solid fa-route"></i>Jak se tam dostanu</button><button type="button" class="bdk41-det" data-id="'+esc(p.id)+'"><i class="fa-solid fa-book-open"></i>Více</button></div></div></div>'}
 function howTo(id){const p=places().find(x=>x.id===id);if(!p)return;const [lat,lng]=POS[id];
  try{map.closePopup()}catch(_){}document.querySelectorAll('.mapboxgl-popup').forEach(x=>x.remove());
  try{if(typeof setBedekr==='function')setBedekr(false)}catch(_){}
  window.__fav41?.route({name:p.title.replace(/\s*\(.*\)$/,''),lat,lng},'to')}
 function detail(id){try{map.closePopup()}catch(_){}document.querySelectorAll('.mapboxgl-popup').forEach(x=>x.remove());try{setBedekr(true)}catch(_){$('btn-bedekr')?.click()}setTimeout(()=>{try{window.showDetail(id)}catch(_){}},60)}
 document.addEventListener('click',e=>{const g=e.target.closest('.bdk41-go,.bdk41-det,.bdk41-dgo,.bdk41-dmap');if(!g)return;e.preventDefault();const id=g.dataset.id;
  if(g.matches('.bdk41-go,.bdk41-dgo'))howTo(id);else if(g.matches('.bdk41-det'))detail(id);else{try{setBedekr(false)}catch(_){}set(true);focus(id)}});
 function build2d(){if(grp)return grp;grp=L.layerGroup();
  for(const p of places()){const [lat,lng]=POS[p.id];const m=L.marker([lat,lng],{icon:L.divIcon({className:'bdk41-icon',html:pinEl(p).outerHTML,iconSize:[44,44],iconAnchor:[22,44],popupAnchor:[0,-40]}),zIndexOffset:900,title:p.title,keyboard:true});
   m.bindPopup(popHTML(p),{className:'bdk41-lp',maxWidth:280,minWidth:240,autoPanPadding:[24,90]});m.__id=p.id;grp.addLayer(m)}return grp}
 function sync3d(){mk3.forEach(m=>m.remove());mk3=[];if(!on||typeof map3d==='undefined'||!map3d||typeof mapboxgl==='undefined')return;
  for(const p of places()){const [lat,lng]=POS[p.id];const el=pinEl(p);el.classList.add('bdk41-3d');
   const m=new mapboxgl.Marker({element:el,anchor:'bottom'}).setLngLat([lng,lat]).setPopup(new mapboxgl.Popup({offset:44,maxWidth:'280px',className:'bdk41-mp'}).setHTML(popHTML(p))).addTo(map3d);m.__id=p.id;mk3.push(m)}}
 function set(v,quiet){on=!!v;try{localStorage.setItem(KEY,on?'1':'0')}catch(_){}
  try{if(on)build2d().addTo(map);else if(grp)map.removeLayer(grp)}catch(_){}
  try{sync3d()}catch(_){}document.body.classList.toggle('bdk41-on',on);
  document.querySelectorAll('.bdk41-tg').forEach(b=>{b.classList.toggle('on',on);b.setAttribute('aria-pressed',on?'true':'false')});
  if(!quiet)toast41(on?'<i class="fa-solid fa-landmark"></i> Památky z Bedekru jsou na mapě. Klepněte na špendlík.':'Památky skryty z mapy.',2600)}
 function focus(id){const ll=POS[id];if(!ll)return;
  try{if(is3dOn()&&has3d()){map3d.flyTo({center:[ll[1],ll[0]],zoom:16,duration:900});setTimeout(()=>mk3.find(m=>m.__id===id)?.togglePopup(),950)}
   else{map.flyTo(ll,16,{duration:.8});setTimeout(()=>{grp?.eachLayer(m=>{if(m.__id===id)m.openPopup()})},850)}}catch(_){}}
 function all(){const pts=places().map(p=>POS[p.id]);try{if(is3dOn()&&has3d()){const b=L.latLngBounds(pts);map3d.fitBounds([[b.getWest(),b.getSouth()],[b.getEast(),b.getNorth()]],{padding:70,duration:900})}else map.fitBounds(L.latLngBounds(pts),{padding:[60,60]})}catch(_){}}
 /* přepínač v mapových ovládacích prvcích (vedle legendy) */
 const lb=$('legend41-btn');if(lb&&!document.querySelector('.bdk41-tg')){const b=document.createElement('button');b.type='button';b.className='bdk41-tg';b.id='bdk41-btn';b.title='Památky z Bedekru na mapě';b.setAttribute('aria-label','Památky z Bedekru na mapě');b.setAttribute('aria-pressed','false');b.innerHTML='<i class="fa-solid fa-landmark"></i>';lb.after(b);b.onclick=e=>{e.stopPropagation();set(!on);if(on)all()}}
 /* v Bedekru: tlačítko Na mapě v hlavičce a akce v detailu */
 const bx=document.querySelector('#bedekr-panel .garage-close, #bedekr-panel [aria-label*="Zavřít"]');
 if(bx&&!document.querySelector('.bdk41-headmap')){const b=document.createElement('button');b.type='button';b.className='bdk41-headmap bdk41-tg';b.innerHTML='<i class="fa-solid fa-map-location-dot"></i><span>Na mapě</span>';b.onclick=()=>{try{setBedekr(false)}catch(_){}set(true);all()};bx.before(b)}
 const sd=window.showDetail;if(typeof sd==='function')window.showDetail=function(id){const r=sd.apply(this,arguments);try{
   const t=$('detail-title');if(t&&POS[id]){let a=document.querySelector('.bdk41-dact');if(!a){a=document.createElement('div');a.className='bdk41-dact';t.after(a)}
    a.innerHTML='<button type="button" class="bdk41-dgo" data-id="'+esc(id)+'"><i class="fa-solid fa-route"></i>Jak se tam dostanu</button><button type="button" class="bdk41-dmap" data-id="'+esc(id)+'"><i class="fa-solid fa-map-location-dot"></i>Ukázat na mapě</button>'}
   else document.querySelector('.bdk41-dact')?.remove()}catch(_){}return r};
 /* 3D: znovu po načtení / přepnutí mapy */
 for(const id of ['btn-model-3d','btn-map-2d'])$(id)?.addEventListener('click',()=>setTimeout(()=>{if(on)sync3d()},900));
 try{if(localStorage.getItem(KEY)==='1')setTimeout(()=>set(true,true),1500)}catch(_){}
 window.__bdk41={set,focus,all,howTo,pos:POS,on:()=>on};
}catch(e){window.__report41?.('bedekr na mapě',e)}})();
/* ---------- Živé polohy a zpoždění (mapa ODIS / KODIS) ----------
   Zdroj: veřejná mapa vozidel ODIS (mpvnet.cz/odis/map). Prohlížeč ji smí číst jen tehdy, když to server dovolí (CORS);
   jinak lze zadat vlastní adresu (proxy), která vrací stejná data. Bez dat aplikace ukazuje polohy podle jízdního řádu. */
(function(){try{
 const KEY='opavago-live',ODIS='https://mpvnet.cz/odis/map/mapData',BODY=JSON.stringify({w:17.55,s:49.72,e:18.35,n:50.12,zoom:13,showStops:false,mapFilterId:null});
 const CONF=window.OPAVAGO_CONFIG||{};
 const cfg=(()=>{let st=null;try{st=JSON.parse(localStorage.getItem(KEY)||'null')}catch(_){}return Object.assign({on:!!CONF.liveUrl,url:''},st||{})})();
 const srcUrl=()=>cfg.url||CONF.liveUrl||'';
 const store=()=>{try{localStorage.setItem(KEY,JSON.stringify(cfg))}catch(_){}};
 const TT=window.__tt41;
 let V=new Map(),delays=new Map(),state='off',last=0,timer=null,grp=null,m3=new Map(),err='';
 const fold=s=>D.fold(String(s||'')).replace(/^opava\s*,?\s*/,'').replace(/[^a-z0-9]+/g,' ').trim();
 const same=(a,b)=>{a=fold(a);b=fold(b);if(!a||!b)return false;if(a===b)return true;const [s,l]=a.length<b.length?[a,b]:[b,a];return s.length>=4&&(l.startsWith(s+' ')||l.endsWith(' '+s)||l.includes(' '+s+' '))};
 const NM=new Map();try{const R=TT?.R;if(R?.names)R.stops.forEach((k,i)=>NM.set(k,R.names[i]))}catch(_){}
 const nameOf=k=>D.stops.get(k)?.name||NM.get(k)||k;
 const lineLabel=r=>{r=String(r??'');const m=/^\d{3}(\d{3})$/.exec(r);return m?String(Number(m[1])):r};
 const parseDelay=ds=>{const m=/\$([zp])-?(\d+)~min\.~(\d+)~s/.exec(ds||'');if(!m)return null;const s=Number(m[2])*60+Number(m[3]);return m[1]==='p'?-s:s};
 function parse(list){const out=new Map();
  for(const t of list||[]){if(!t||t.cat===1||(t.t&&t.t!=='H')||!Number.isFinite(t.x)||!Number.isFinite(t.y))continue;
   const f=String(t.cn??'').split('|');if(!f[1])continue;const line=lineLabel(f[1]);if(!D.line(line))continue;
   const ang=/a_(\d+)\.png/.exec(t.ico||''),delay=parseDelay(t.ds),plate=(f[11]||'').replace(/^Ev\.\s*č\.\s*/i,'').trim();
   const id=plate||(f[0]+'-'+f[2]);
   out.set(id,{id,line,lat:t.x,lng:t.y,bearing:ang?Number(ang[1]):null,delay,dm:delay==null?null:Math.round(delay/60),next:f[5]||'',stop:f[3]||'',from:f[8]||'',head:f[9]||'',low:f[10]==='1',plate,carrier:t.cr||'',stand:/stoji/.test(t.ico||'')})}
  return out}
 /* přiřazení vozu ke spoji jízdního řádu: stejná linka, cíl a nejbližší plánovaná poloha */
 function match(){delays=new Map();if(!TT)return;const now=new Date(),act=TT.active(now),m0=TT.mins(now);
  for(const v of V.values()){if(v.dm==null)continue;let best=null;
   for(const {T,m} of act){if(T.line!==v.line||!same(nameOf(T.keys.at(-1)),v.head))continue;
    let idx=-1;if(v.next)for(let j=0;j<T.keys.length;j++)if(same(nameOf(T.keys[j]),v.next)){idx=j;break}
    const w=TT.where(T,m-v.dm),exp=w.i+(w.dwell?0:1),sc=idx<0?5:Math.abs(exp-idx);
    if(sc<=3&&(!best||sc<best.sc))best={T,sc,off:Math.round(m0-m)}}
   if(best){const k=best.T.id+'@'+(best.off===0?0:best.off);delays.set(k,{dm:v.dm,v})}}}
 async function fetchLive(){
  const ctl=new AbortController(),to=setTimeout(()=>ctl.abort(),9000);
  try{let r;const u=srcUrl();if(u)r=await fetch(u,{signal:ctl.signal,cache:'no-store'});
   else r=await fetch(ODIS,{method:'POST',headers:{'Content-Type':'application/json; charset=utf-8'},body:BODY,signal:ctl.signal,cache:'no-store'});
   if(!r.ok)throw Error('HTTP '+r.status);const j=await r.json();return Array.isArray(j)?j:(j.transmitters||j.odis||j.vehicles||[])}
  finally{clearTimeout(to)}}
 const dCls=dm=>dm==null?'':dm<=0?'ok':dm<=3?'mid':'bad';
 const dTxt=dm=>dm==null?'':dm<=0?(dm<0?dm+' min':'včas'):'+'+dm+' min';
 function html(v){return '<span class="live41-l" style="--c:'+(D.color(v.line)||'#C1784F')+'">'+h(v.line)+'</span>'+(v.dm!=null?'<span class="live41-d '+dCls(v.dm)+'">'+(v.dm<=0?'✓':'+'+v.dm)+'</span>':'')}
 function pop(v){return '<div class="live41-pop"><div class="live41-ph"><span class="live41-l big" style="--c:'+(D.color(v.line)||'#C1784F')+'">'+h(v.line)+'</span><div><b>→ '+h(v.head||'?')+'</b><small>'+(v.dm!=null?'<span class="live41-d '+dCls(v.dm)+'">'+dTxt(v.dm)+'</span>':'zpoždění neznámé')+'</small></div></div>'
  +(v.next?'<div class="live41-r"><i class="fa-solid fa-location-arrow"></i>Příští zastávka: <b>'+h(v.next.replace(/^Opava,\s*/,''))+'</b></div>':'')
  +(v.from?'<div class="live41-r"><i class="fa-solid fa-flag"></i>Ze zastávky '+h(v.from.replace(/^Opava,\s*/,''))+'</div>':'')
  +'<div class="live41-r"><i class="fa-solid fa-wheelchair"></i>'+(v.low?'Nízkopodlažní vůz':'Nízkopodlažnost neuvedena')+(v.plate?' · ev. č. '+h(v.plate):'')+'</div>'
  +'<div class="live41-src"><i class="fa-solid fa-tower-broadcast"></i> Živá data ODIS · '+new Date(last).toLocaleTimeString('cs-CZ')+'</div></div>'}
 function draw(){
  if(!grp)grp=L.layerGroup();if(cfg.on&&state==='ok'&&!map.hasLayer(grp))grp.addTo(map);
  const seen=new Set();
  for(const v of V.values()){seen.add(v.id);let m=null;grp.eachLayer(x=>{if(x.__id===v.id)m=x});
   const icon=L.divIcon({className:'live41-ic',html:'<div class="live41">'+html(v)+'</div>',iconSize:[0,0]});
   if(m){m.setLatLng([v.lat,v.lng]);m.setIcon(icon);m.setPopupContent(pop(v))}
   else{m=L.marker([v.lat,v.lng],{icon,zIndexOffset:1200,keyboard:false});m.__id=v.id;m.bindPopup(pop(v),{className:'live41-lp',maxWidth:270});grp.addLayer(m)}}
  grp.eachLayer(x=>{if(!seen.has(x.__id))grp.removeLayer(x)});
  /* 3D */
  if(typeof map3d!=='undefined'&&map3d&&typeof mapboxgl!=='undefined'){
   for(const v of V.values()){let mk=m3.get(v.id);if(!mk){const el=document.createElement('div');el.className='live41 live41-3d';mk=new mapboxgl.Marker({element:el}).setLngLat([v.lng,v.lat]).setPopup(new mapboxgl.Popup({offset:16,className:'live41-mp',maxWidth:'270px'})).addTo(map3d);m3.set(v.id,mk)}
    mk.getElement().innerHTML=html(v);mk.setLngLat([v.lng,v.lat]);mk.getPopup().setHTML(pop(v))}
   for(const [id,mk] of m3)if(!V.has(id)){mk.remove();m3.delete(id)}}}
 function clear(){try{grp&&map.removeLayer(grp);grp?.clearLayers()}catch(_){}for(const mk of m3.values())mk.remove();m3.clear();V=new Map();delays=new Map();annotate()}
 async function tick(){if(!cfg.on)return;if(document.hidden)return;
  try{const list=await fetchLive();V=parse(list);last=Date.now();const was=state;state='ok';err='';match();draw();try{if(window.__dep42?.isOpen())window.__dep42.open()}catch(_){}annotate();ui();
   if(was!=='ok')toast41('<i class="fa-solid fa-tower-broadcast"></i> Živé polohy zapnuty – '+V.size+' vozů MHD a regio na mapě.',3200)}
  catch(e){const was=state;state='fail';err=String(e?.message||e);clear();ui();
   if(was!=='fail')toast41('<i class="fa-solid fa-tower-broadcast"></i> Živá data ODIS teď nejsou dostupná (server je prohlížeči nepovolil nebo neodpověděl). Polohy ukazuji podle jízdního řádu. <button type="button" class="live41-cfg">Nastavit zdroj</button>',9000)}}
 function set(on){cfg.on=!!on;store();clearInterval(timer);
  if(cfg.on){state='load';ui();tick();timer=setInterval(tick,15000)}else{state='off';clear();ui()}}
 /* tabule odjezdů: zpoždění u spojů, které právě jedou */
 function annotate(){const box=document.querySelector('#dep42 .dep42-list');if(!box)return;
  box.querySelectorAll('.live41-dep').forEach(x=>x.remove());
  if(cfg.on&&state==='ok')for(const r of box.querySelectorAll('.dep42-row')){const d=delays.get(r.dataset.id);if(!d)continue;
   const t=r.querySelector('.dep42-t');if(t)t.insertAdjacentHTML('beforeend','<em class="live41-dep '+dCls(d.dm)+'" title="Podle živé polohy vozu">'+(d.dm<=0?'včas':'+'+d.dm+' min')+'</em>')}
  const f=document.querySelector('#dep42 .dep42-foot span');if(f)f.innerHTML=cfg.on&&state==='ok'?'<i class="fa-solid fa-tower-broadcast" style="color:#2e8b57"></i> Zpoždění živě z ODIS · '+new Date(last).toLocaleTimeString('cs-CZ',{hour:'2-digit',minute:'2-digit'}):'Podle jízdního řádu, bez zpoždění.'}
 new MutationObserver(()=>{const b=document.querySelector('#dep42 .dep42-list');if(b&&!b.__live41){b.__live41=1;new MutationObserver(()=>{if(!b.__busy){b.__busy=1;annotate();b.__busy=0}}).observe(b,{childList:true});annotate()}}).observe(document.body,{childList:true});
 /* ovládání: tlačítko u legendy, položka v nabídce Více, nastavení zdroje */
 function ui(){document.querySelectorAll('.live41-tg').forEach(b=>{b.classList.toggle('on',cfg.on);b.classList.toggle('fail',cfg.on&&state==='fail');b.classList.toggle('load',cfg.on&&state==='load');b.setAttribute('aria-pressed',cfg.on?'true':'false');
  b.title=!cfg.on?'Živé polohy vozidel (ODIS)':state==='ok'?'Živé polohy: '+V.size+' vozů · klepnutím vypnout':state==='fail'?'Živá data nedostupná · klepnutím vypnout':'Načítám živé polohy…'})}
 const lb=$('legend41-btn');if(lb&&!$('live41-btn')){const b=document.createElement('button');b.type='button';b.id='live41-btn';b.className='live41-tg';b.setAttribute('aria-label','Živé polohy vozidel');b.innerHTML='<i class="fa-solid fa-tower-broadcast"></i>';lb.after(b);b.onclick=e=>{e.stopPropagation();set(!cfg.on)}}
 function settings(){let d=$('live41-set');d?.remove();d=document.createElement('div');d.id='live41-set';d.className='fav41-ov';
  d.innerHTML='<div class="fav41-dlg"><div class="fav41-dh"><div class="fav41-ic"><i class="fa-solid fa-tower-broadcast"></i></div><div><small>Živé polohy</small><b>Zdroj dat</b></div><button type="button" class="fav41-x" aria-label="Zavřít"><i class="fa-solid fa-xmark"></i></button></div>'
   +'<p class="live41-p">Aplikace čte veřejnou mapu vozidel ODIS. Pokud ji prohlížeč nesmí načíst přímo, zadejte adresu vlastní proxy, která vrací stejná data (JSON s polem <code>transmitters</code>).</p>'
   +'<label class="fav41-l">Adresa zdroje (prázdné = '+(CONF.liveUrl?'proxy z config.js':'přímo mapa ODIS')+')<input class="live41-url" placeholder="'+h(CONF.liveUrl||'https://…')+'" value="'+h(cfg.url)+'"></label>'
   +'<div class="fav41-hint">'+(state==='fail'?'Poslední pokus: '+h(err):state==='ok'?'Připojeno · '+V.size+' vozů':'')+'</div>'
   +'<div class="fav41-btns"><button type="button" class="fav41-cancel">Zrušit</button><button type="button" class="fav41-save"><i class="fa-solid fa-plug"></i>Uložit a připojit</button></div></div>';
  document.body.appendChild(d);const close=()=>d.remove();d.querySelector('.fav41-x').onclick=close;d.querySelector('.fav41-cancel').onclick=close;d.onclick=e=>{if(e.target===d)close()};
  d.querySelector('.fav41-save').onclick=()=>{const u=d.querySelector('.live41-url').value.trim();if(u&&!/^https:\/\//i.test(u)){d.querySelector('.fav41-hint').textContent='Adresa musí začínat https://';return}cfg.url=u;store();close();state='off';set(true)}}
 document.addEventListener('click',e=>{if(e.target.closest('.live41-cfg')){e.preventDefault();settings()}});
 document.addEventListener('visibilitychange',()=>{if(!document.hidden&&cfg.on)tick()});
 if(cfg.on)setTimeout(()=>set(true),2500);
 window.__live41={set,settings,on:()=>cfg.on,state:()=>state,vehicles:()=>[...V.values()],delays:()=>delays,_inject:list=>{V=parse(list);last=Date.now();state='ok';match();draw();annotate();ui()}};
}catch(e){window.__report41?.('živé polohy',e)}})();

})();
