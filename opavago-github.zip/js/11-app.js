
/* ---------- ODJEZDY V REÁLNÉM ČASE (mpvnet.cz / ODIS) ----------
   mpvnet.cz nemá veřejné JSON API (jen HTML tabuli pro prohlížeč) a jejich
   robots.txt zakazuje automatizovaný přístup, takže tabuli nelze stahovat
   na pozadí - vkládáme proto jejich oficiální odjezdovou stránku do rámce (iframe),
   přesně jak ODIS doporučuje přes QR kódy na zastávkách. Pár centrálních
   zastávek má napárované konkrétní číslo zastávky pro přímý odkaz; ostatní
   otevřou obecné vyhledávání přímo na mpvnet.cz. */
(function(){
 const MPVNET_STOPS_RAW={
  'Horovo náměstí':50995,
  'Komárov,Balakom':50987,
  'Rooseveltova':51459,
  'Olbrichova':24946,
  'Jaktař,mrazírny':56755,
  'Stará silnice':51003,
  'Podvihov,Na Nové':24973
 };
 const MPVNET_STOPS={};
 try{ Object.entries(MPVNET_STOPS_RAW).forEach(([k,v])=>{ MPVNET_STOPS[normalizeStopName(k)]=v; }); }catch(e){}

 function findMpvnetId(name){
  try{
   const key=normalizeStopName(name);
   if(MPVNET_STOPS[key])return MPVNET_STOPS[key];
   let best=null,bestLen=-1;
   for(const k in MPVNET_STOPS){ if(k.length>3&&(key.includes(k)||k.includes(key))&&k.length>bestLen){best=k;bestLen=k.length} }
   return best?MPVNET_STOPS[best]:null;
  }catch(e){ return null; }
 }

 window.openDeparturesPanel=function(stopName){
  const panel=document.getElementById('departures-panel');
  const frame=document.getElementById('departures-frame');
  const sub=document.getElementById('departures-subtitle');
  const ext=document.getElementById('departures-external');
  let url='https://mpvnet.cz/odis', subtitle='Zdroj dat: mpvnet.cz (ODIS) · CHAPS spol. s r.o.';
  if(stopName){
   const id=findMpvnetId(stopName);
   const cleanName=(typeof clean==='function')?clean(stopName):stopName;
   if(id){
    url='https://m.odis.mpvnet.cz/ODIS/tab?cat=2&subCat=0&stopNum='+id+'&departures=true';
    subtitle='Zastávka: '+cleanName+' · mpvnet.cz (ODIS)';
   }else{
    subtitle='Zastávku "'+cleanName+'" zatím nemáme spárovanou - vyhledejte ji přímo v tabuli níže.';
   }
  }
  if(frame)frame.src=url;
  if(sub)sub.textContent=subtitle;
  if(ext)ext.href=url;
  document.getElementById('network-panel')?.classList.remove('open');
  document.getElementById('search-panel')?.classList.remove('open');
  document.body.classList.add('network-open');
  panel?.classList.add('open');panel?.setAttribute('aria-hidden','false');
  resizeMapsAfterPanel();
 };
 document.getElementById('departures-stop-go')?.addEventListener('click',()=>{
   const n=document.getElementById('departures-stop-input')?.value.trim();
   if(n)openDeparturesPanel(n);
  });
  document.getElementById('departures-stop-input')?.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();document.getElementById('departures-stop-go')?.click();}});
  window.closeDeparturesPanel=function(){
  const panel=document.getElementById('departures-panel');
  panel?.classList.remove('open');panel?.setAttribute('aria-hidden','true');
  document.body.classList.remove('network-open');
  resizeMapsAfterPanel();
  const frame=document.getElementById('departures-frame');
  if(frame)frame.src='about:blank';
 };
 document.getElementById('btn-departures')?.addEventListener('click',()=>{const p=document.getElementById('departures-panel');if(p?.classList.contains('open'))closeDeparturesPanel();else openDeparturesPanel();});
 document.getElementById('departures-close')?.addEventListener('click',closeDeparturesPanel);
})();
